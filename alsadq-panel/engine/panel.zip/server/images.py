"""images — a client's picture, read safely and made into exactly the files the site already serves.

A site's panel.json describes each picture slot: the files it is served as (paths and widths), its shape, whether it
keeps a transparent background, and the most each file may weigh (B2B's check refuses an image over 140 kB). The
client never thinks about any of that: they choose a photo, move it inside the frame, and the panel writes every size,
in WebP, under the weight, with the camera's location and every other tag removed.
"""
import io
import json
import os
import secrets
import time

from PIL import Image, ImageOps

Image.MAX_IMAGE_PIXELS = 60_000_000          # a decompression bomb is refused, not opened

MAX_BYTES = 30 * 1024 * 1024
FORMATS = {"JPEG", "PNG", "WEBP", "MPO", "AVIF", "GIF", "TIFF", "BMP", "HEIF"}

try:                                          # iPhone photos, where the server has the decoder installed
    import pillow_heif
    pillow_heif.register_heif_opener()
    HEIF = True
except Exception:                             # pragma: no cover — depends on the machine
    HEIF = False


class ImageError(ValueError):
    def __init__(self, code, **details):
        super().__init__(code)
        self.code = code
        self.details = details


def slots(manifest):
    """every picture slot: id → {group, files [{path, width, max_kb}], fit, alpha, alt}"""
    out = {}
    for g in manifest.get("images", []):
        for item in g["items"]:
            iid = item if isinstance(item, str) else item["id"]
            files = [{"path": f["path"].format(id=iid), "width": f["width"], "max_kb": f.get("max_kb", g.get("max_kb", 300))}
                     for f in g["files"]]
            out[iid] = {"id": iid, "group": g["group"], "label": g.get("label", {}), "files": files,
                        "fit": g.get("fit", "cover"), "alpha": bool(g.get("alpha")),
                        "alt": g["alt"].format(id=iid) if g.get("alt") else None, "hint": g.get("hint", {})}
    return out


def shape(work, slot):
    """the slot's width : height, read from the largest file it serves today"""
    big = max(slot["files"], key=lambda f: f["width"])
    with Image.open(os.path.join(work, big["path"])) as im:
        return im.width / im.height, big["width"]


def receive(upload_dir, data, filename):
    """a file as sent → a verified picture kept for cropping; returns its description"""
    if len(data) > MAX_BYTES:
        raise ImageError("too_big", mb=MAX_BYTES // (1024 * 1024))
    if len(data) < 64:
        raise ImageError("not_image")
    head = data[:512].lstrip()
    if head[:5].lower() == b"<?xml" or b"<svg" in head[:256].lower():
        raise ImageError("svg")
    ext = os.path.splitext(filename or "")[1].lower()
    if ext in (".heic", ".heif") and not HEIF:
        raise ImageError("heic")
    try:
        with Image.open(io.BytesIO(data)) as probe:
            probe.verify()
        im = Image.open(io.BytesIO(data))
        if im.width * im.height > Image.MAX_IMAGE_PIXELS:   # Pillow only warns below twice its limit; we refuse
            raise ImageError("huge")
        fmt = im.format
        if fmt not in FORMATS:
            raise ImageError("format", format=fmt)
        if getattr(im, "n_frames", 1) > 1 and fmt in ("GIF", "WEBP", "PNG"):
            raise ImageError("animated")
        im = ImageOps.exif_transpose(im)
        im.load()
    except ImageError:
        raise
    except Image.DecompressionBombError:
        raise ImageError("huge")
    except Exception:
        raise ImageError("not_image")
    alpha = im.mode in ("RGBA", "LA", "PA") or (im.mode == "P" and "transparency" in im.info)
    if alpha:
        im = im.convert("RGBA")
        lo, _ = im.getchannel("A").getextrema()
        alpha = lo < 250
    else:
        im = im.convert("RGB")
    uid = secrets.token_hex(12)
    os.makedirs(upload_dir, exist_ok=True)
    keep = os.path.join(upload_dir, uid + ".png")
    im.save(keep, "PNG", compress_level=1)             # the decoded picture, no metadata of any kind
    thumb = im.copy()
    thumb.thumbnail((1400, 1400), Image.LANCZOS)
    tb = io.BytesIO()
    (thumb if alpha else thumb.convert("RGB")).save(tb, "WEBP", quality=82)
    open(os.path.join(upload_dir, uid + ".thumb.webp"), "wb").write(tb.getvalue())
    meta = {"id": uid, "w": im.width, "h": im.height, "alpha": alpha, "format": fmt, "bytes": len(data),
            "name": os.path.basename(filename or "")[:120], "at": int(time.time())}
    json.dump(meta, open(os.path.join(upload_dir, uid + ".json"), "w"))
    return meta


def assess(meta, ratio, need_w, slot):
    """what the client should know before using this picture in this slot"""
    warn = []
    w, h = meta["w"], meta["h"]
    if slot["fit"] == "cover":
        usable_w = min(w, h * ratio)            # the widest crop of the slot's shape the photo can give
    else:
        usable_w = max(w, h * ratio)            # contained: the picture's own width, padded to the slot
    if usable_w < need_w * 0.6:
        raise ImageError("small", need=need_w, have=int(usable_w))
    if usable_w < need_w:
        warn.append({"code": "soft", "need": need_w, "have": int(usable_w)})
    if slot["alpha"] and not meta["alpha"]:
        warn.append({"code": "no_alpha"})
    return warn


def apply(work, upload_dir, uid, slot, crop):
    """crop (fractions of the upload: x, y, w, h) → every file of the slot, written into the working copy"""
    meta_p = os.path.join(upload_dir, uid + ".json")
    if not os.path.exists(meta_p) or not uid.isalnum():
        raise ImageError("expired")
    meta = json.load(open(meta_p))
    im = Image.open(os.path.join(upload_dir, uid + ".png"))
    im.load()
    ratio, need_w = shape(work, slot)
    W, H = im.size
    if slot["fit"] == "cover":
        x, y, cw, ch = (float(crop.get(k, d)) for k, d in (("x", 0), ("y", 0), ("w", 1), ("h", 1)))
        box = [x * W, y * H, (x + cw) * W, (y + ch) * H]
        # the box must be the slot's shape and inside the picture; repair rounding, refuse nonsense
        bw, bh = box[2] - box[0], box[3] - box[1]
        if bw <= 4 or bh <= 4:
            raise ImageError("crop")
        if abs(bw / bh - ratio) > 0.02 * ratio:
            bh = bw / ratio
            box[3] = box[1] + bh
        box = _inside(box, W, H)
        im = im.crop(tuple(round(v) for v in box))
    else:                                       # contain: the whole picture inside the slot's shape
        tw, th = (W, round(W / ratio)) if W / H > ratio else (round(H * ratio), H)
        canvas = Image.new("RGBA" if (slot["alpha"] or meta["alpha"]) else "RGB", (tw, th),
                           (0, 0, 0, 0) if (slot["alpha"] or meta["alpha"]) else (255, 255, 255))
        canvas.paste(im, ((tw - W) // 2, (th - H) // 2), im if im.mode == "RGBA" else None)
        im = canvas
    keep_alpha = slot["alpha"] and im.mode == "RGBA"
    if not keep_alpha:
        im = im.convert("RGB")
    written = []
    for f in slot["files"]:
        tw = f["width"]
        th = round(tw / ratio)
        out = im.resize((tw, th), Image.LANCZOS, reducing_gap=3.0) if im.size != (tw, th) else im
        data, q = _encode(out, f["max_kb"] * 1024, keep_alpha)
        dest = os.path.join(work, f["path"])
        tmp = dest + ".panel-tmp"
        open(tmp, "wb").write(data)
        os.replace(tmp, dest)
        written.append({"path": f["path"], "w": tw, "h": th, "kb": round(len(data) / 1024, 1), "quality": q})
    return written


def _inside(box, W, H):
    x0, y0, x1, y1 = box
    bw, bh = x1 - x0, y1 - y0
    if bw > W:
        s = W / bw
        bw, bh = W, bh * s
    if bh > H:
        s = H / bh
        bw, bh = bw * s, H
    x0 = min(max(0, x0), W - bw)
    y0 = min(max(0, y0), H - bh)
    return [x0, y0, x0 + bw, y0 + bh]


def _encode(im, limit, alpha):
    """WebP at the best quality that fits under the slot's weight"""
    best = None
    for q in (86, 82, 78, 74, 70, 66, 62, 58, 54, 50):
        b = io.BytesIO()
        im.save(b, "WEBP", quality=q, method=6, **({"exact": False, "alpha_quality": 90} if alpha else {}))
        best = (b.getvalue(), q)
        if len(best[0]) <= limit:
            return best
    smaller = im.resize((max(1, im.width), max(1, im.height)))
    b = io.BytesIO()
    smaller.save(b, "WEBP", quality=45, method=6)
    if len(b.getvalue()) <= limit:
        return b.getvalue(), 45
    raise ImageError("heavy", kb=round(len(best[0]) / 1024), limit=round(limit / 1024))
