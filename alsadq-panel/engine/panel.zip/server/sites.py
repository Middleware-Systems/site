"""sites — the registry of clients and their sites, and everything that happens to one site: its draft, its preview,
its publishing and its history.

The draft is the working copy's uncommitted state. Every edit writes the site's own files straight away (nothing is
lost if a browser closes); the review list is the difference between the working copy and the last published
version, computed, never kept by hand. Publishing builds a snapshot, runs every check, deploys it, and only then
commits it: a version in the history is always a version that went live.
"""
import hashlib
import json
import os
import re
import secrets
import shutil
import threading
import time

from . import builds, gitw, images, records, social
from .content import Content, FieldError, resolve
from .jsonspan import ptr, unptr

COPY_SKIP = ("dist*", "docs/screens", "out", "node_modules", "__pycache__", ".git", ".DS_Store", ".cache", "*.pyc")


class Registry:
    def __init__(self, data_dir):
        self.data = data_dir
        self.path = os.path.join(data_dir, "registry.json")
        self.reg = json.load(open(self.path, encoding="utf-8"))
        self.users = {e.lower(): u for e, u in self.reg.get("users", {}).items()}
        self.clients = self.reg["clients"]
        self._sites = {}
        self.builds = {}                         # build id → (site, dir)
        self.lock = threading.Lock()
        self.base_dir = self.reg.get("_base", data_dir)

    def site(self, cid, sid):
        c = self.clients.get(cid)
        if not c or sid not in c["sites"]:
            return None
        with self.lock:
            key = (cid, sid)
            if key not in self._sites:
                self._sites[key] = Site(self, cid, sid, c["sites"][sid])
            return self._sites[key]

    def sites_of(self, cid):
        return [self.site(cid, sid) for sid in self.clients.get(cid, {}).get("sites", {})]

    def save_users(self):
        reg = json.load(open(self.path, encoding="utf-8"))
        reg["users"] = self.users
        tmp = self.path + ".tmp"
        json.dump(reg, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)


class Busy(RuntimeError):
    pass


class _Hold:
    """stands in for a publish job until the site is released: steps pass through, the ending waits"""

    def __init__(self, job):
        self.job, self.end = job, None

    def step(self, name):
        self.job.step(name)

    def report(self, progress):
        self.job.progress = progress

    def fail(self, code, **details):
        self.end = ("fail", code, details)
        return self

    def done(self, **details):
        self.end = ("done", None, details)
        return self


class Site:
    def __init__(self, reg, cid, sid, cfg):
        self.reg, self.cid, self.sid, self.cfg = reg, cid, sid, cfg
        self.root = os.path.join(reg.data, "sites", cid, sid)
        self.work = os.path.join(self.root, "work")
        self.builds_dir = os.path.join(self.root, "builds")
        self.uploads = os.path.join(self.root, "uploads")
        self.state_path = os.path.join(self.root, "state.json")
        self.lock = threading.RLock()
        self.busy = None                         # "publishing" while a publish holds the site
        self._content = None
        self._timer = None
        self._building = False
        self._dirty = False
        self.ensure()
        self.manifest = json.load(open(os.path.join(self.work, "panel.json"), encoding="utf-8"))
        self.langs = [l["code"] for l in self.manifest["languages"]]
        self.slots = images.slots(self.manifest)
        self.records = records.Schema(self.manifest)     # a wrong declaration stops here, loudly, naming the field
        self._owned_list = []
        self.state = self._load_state()
        pv = self.state.get("preview")
        if pv and os.path.isdir(os.path.join(self.builds_dir, pv["id"])):
            reg.builds[pv["id"]] = (self, os.path.join(self.builds_dir, pv["id"], "src", "dist"))

    # ── the working copy ─────────────────────────────────────────────────────────────────────────────────────────
    def ensure(self):
        if os.path.isdir(os.path.join(self.work, ".git")):
            return
        src = self.cfg["source"]
        os.makedirs(self.root, exist_ok=True)
        if "paths" in src:                                   # the first that exists and holds a panel.json
            path = next((p for p in self._candidates(src["paths"]) if os.path.exists(os.path.join(p, "panel.json"))), None)
            if not path:
                raise ValueError(f"{self.cid}/{self.sid}: none of {src['paths']} holds a panel.json")
            src = {"path": path}
        if "path" in src:
            path = os.path.normpath(os.path.join(self.reg.base_dir, src["path"]))
            for alt in self.reg.reg.get("_also", []):       # e.g. a git worktree, whose clients/ is the main checkout's
                if not os.path.isdir(path):
                    path = os.path.normpath(os.path.join(alt, src["path"]))
            extra = []
            mpath = os.path.join(path, "panel.json")
            if os.path.exists(mpath):
                extra = json.load(open(mpath, encoding="utf-8")).get("workspace_exclude", [])
            skip = COPY_SKIP + tuple(extra)

            def ignore(d, names):
                rel = os.path.relpath(d, path)
                out = set()
                for n in names:
                    p = n if rel == "." else os.path.join(rel, n)
                    if any(builds._glob(n, s) or builds._glob(p, s) for s in skip):
                        out.add(n)
                return out
            shutil.copytree(path, self.work, ignore=ignore)
            gitw.init(self.work, "Starting point")
        else:
            raise ValueError(f"{self.cid}/{self.sid}: unknown source {src}")

    def _candidates(self, paths):
        for rel in paths:
            for base in [self.reg.base_dir] + list(self.reg.reg.get("_also", [])):
                yield os.path.normpath(os.path.join(base, rel))

    def _load_state(self):
        try:
            return json.load(open(self.state_path, encoding="utf-8"))
        except Exception:
            return {"labels": {}, "draft_by": {}, "history": {}}

    def save_state(self):
        tmp = self.state_path + ".tmp"
        json.dump(self.state, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
        os.replace(tmp, self.state_path)

    def name(self, lang):
        n = self.manifest.get("name", {})
        return n.get(lang) or n.get("en") or self.sid

    # ── what may be edited ───────────────────────────────────────────────────────────────────────────────────────
    def hidden_keys(self, read=None):
        """fields edited elsewhere than on the page: search titles, picture descriptions, social targets"""
        out = set()
        seo = self.manifest.get("seo", {})
        for refs in seo.get("pages", {}).values():
            out.update(refs.values())
        for s in self.manifest["text"]:
            if s.get("role") == "seo":
                out.add(s["id"] + ":*")
        for sl in self.slots.values():
            if sl["alt"]:
                out.add(sl["alt"])
        out |= self.social_keys()
        return out

    def content(self, rev=None):
        if rev is None and self._content is not None:
            return self._content
        read = (lambda rel: open(os.path.join(self.work, rel), encoding="utf-8").read()) if rev is None \
            else (lambda rel: gitw.show(self.work, rev, rel))
        hid = self.hidden_keys(read)
        c = Content(self.work, self.manifest, read=read, skip=())
        c.skip = {k for k in c.order if k in hid or any(h.endswith(":*") and k.startswith(h[:-1]) for h in hid)}
        if rev is None:
            self._content = c
        return c

    def invalidate(self):
        self._content = None

    def managed_paths(self):
        out = set()
        for s in self.manifest["text"]:
            if s["kind"] == "parallel":
                out.update(s["files"].values())
            else:
                out.add(s["file"])
        out.update(social.files(self.manifest))
        for sl in self.slots.values():
            out.update(f["path"] for f in sl["files"])
        out.update(self.records.written_files())
        return sorted(out)

    def is_managed(self, path, managed=None):
        """a file the panel may commit: one it edits, or a picture inside a records folder"""
        if path in (managed if managed is not None else set(self.managed_paths())):
            return True
        return any(path.startswith(d.rstrip("/") + "/") and "/" not in path[len(d.rstrip("/")) + 1:]
                   for d in self.records.folders())

    def book(self, rev=None):
        return records.Book(self.records, self._reader_or_none(rev))

    def _reader_or_none(self, rev):
        if rev is None:
            def read(rel):
                try:
                    return open(os.path.join(self.work, rel), encoding="utf-8").read()
                except FileNotFoundError:
                    return None
            return read
        return lambda rel: gitw.show(self.work, rev, rel)

    def _owned(self, f):
        """a text inside a records list or settings object: its change is told as the record's, not as a text"""
        for L, (file, p) in f.loc.items():
            for of, op in self._owned_list:
                if file == of and (p == op or p.startswith(op + "/")):
                    return True
        return False

    def _records_hash(self):
        if not self.records:
            return None
        h = hashlib.sha1()
        for rel in self.records.files():
            p = os.path.join(self.work, rel)
            h.update(rel.encode() + b"\0" + (open(p, "rb").read() if os.path.exists(p) else b"-"))
        for d in self.records.folders():
            full = os.path.join(self.work, d)
            for n in sorted(os.listdir(full)) if os.path.isdir(full) else []:
                h.update(f"{d}/{n}:{os.path.getsize(os.path.join(full, n))}".encode())
        return h.hexdigest()

    # ── the difference between two states (None = the draft) ─────────────────────────────────────────────────────
    def diff(self, a="HEAD", b=None):
        ca, cb = self.content(a), self.content(b)
        out = []
        keys = list(cb.order) + [k for k in ca.order if k not in cb.fields]
        social_keys = self.social_keys()
        self._owned_list = self.records.owned()
        for k in keys:
            if k in social_keys:                  # a social link is one change, not its handle and address apart
                continue
            fa, fb = ca.fields.get(k), cb.fields.get(k)
            if self._owned_list and self._owned(fb or fa):
                continue                          # told below, as a change to that record
            for L in self.langs:
                va = fa.values.get(L) if fa else None
                vb = fb.values.get(L) if fb else None
                if (va or "") != (vb or ""):
                    out.append({"type": "text", "key": k, "lang": L, "before": va, "after": vb,
                                "id": f"text:{k}:{L}", "hidden": k in cb.skip})
        for sid, sl in self.slots.items():
            ha = [self._hash(f["path"], a) for f in sl["files"]]
            hb = [self._hash(f["path"], b) for f in sl["files"]]
            if ha != hb:
                out.append({"type": "image", "slot": sid, "id": f"image:{sid}"})
        if self.manifest.get("social"):
            ra = {l["network"]: l for l in social.read(self.manifest, self._reader(a))}
            rb = {l["network"]: l for l in social.read(self.manifest, self._reader(b))}
            for n in list(rb) + [l for l in ra if l not in rb]:
                ua, ub = (ra.get(n) or {}).get("url"), (rb.get(n) or {}).get("url")
                if ua != ub:
                    out.append({"type": "social", "network": n, "before": ua, "after": ub, "id": f"social:{n}"})
            if list(ra) != list(rb) and set(ra) == set(rb):
                out.append({"type": "social", "network": "", "order": True, "id": "social:order"})
        if self.records:
            out += records.diff(self.book(a), self.book(b))
        return out

    def social_keys(self):
        """the text fields a fixed social link writes into (Indomie's handle in its claims)"""
        cfg = self.manifest.get("social")
        if not cfg or cfg["kind"] != "fixed":
            return set()
        out = set()
        for n in cfg["networks"]:
            for t in n["targets"]:
                src = next((s for s in self.manifest["text"] if s.get("file") == t["file"]), None)
                if not src:
                    continue
                data = json.loads(open(os.path.join(self.work, t["file"]), encoding="utf-8").read())
                p = resolve(data, t["pointer"])
                out.add(f"{src['id']}:{p.rsplit('/', 1)[0]}")
        return out

    def _reader(self, rev):
        if rev is None:
            return lambda rel: open(os.path.join(self.work, rel), encoding="utf-8").read()
        return lambda rel: gitw.show(self.work, rev, rel)

    def _hash(self, rel, rev):
        if rev is None:
            p = os.path.join(self.work, rel)
            return hashlib.sha1(open(p, "rb").read()).hexdigest() if os.path.exists(p) else None
        b = gitw.show(self.work, rev, rel, binary=True)
        return hashlib.sha1(b).hexdigest() if b is not None else None

    # ── editing the draft ────────────────────────────────────────────────────────────────────────────────────────
    def guard(self):
        if self.busy:
            raise Busy(self.busy)

    def set_text(self, edits, user):
        with self.lock:
            self.guard()
            c = self.content()
            done = c.set_many(edits)
            for k, L, _ in done:
                self.state["draft_by"][f"text:{k}:{L}"] = {"name": user["name"], "at": int(time.time())}
            self.save_state()
            self.schedule_preview()
            return done

    def set_image(self, slot_id, upload_id, crop, user):
        with self.lock:
            self.guard()
            slot = self.slots[slot_id]
            written = images.apply(self.work, self.uploads, upload_id, slot, crop)
            self.state["draft_by"][f"image:{slot_id}"] = {"name": user["name"], "at": int(time.time())}
            self.save_state()
            self.schedule_preview()
            return written

    def set_social(self, links, user):
        with self.lock:
            self.guard()
            before = {l["network"]: l["url"] for l in social.read(self.manifest, self._reader(None))}
            saved = social.write(self.manifest, self.work, links)
            self.invalidate()
            for l in saved:
                if before.get(l["network"]) != l["url"]:
                    self.state["draft_by"][f"social:{l['network']}"] = {"name": user["name"], "at": int(time.time())}
            self.save_state()
            self.schedule_preview()
            return saved

    def record_op(self, op, user, *args):
        """add · edit · duplicate · delete · reorder · settings, on the draft; refused whole or written whole"""
        with self.lock:
            self.guard()
            fn = {"add": records.add, "edit": records.edit, "duplicate": records.duplicate, "delete": records.delete,
                  "reorder": records.reorder, "settings": records.set_settings}[op]
            out = fn(self, *args)
            if op in ("add", "duplicate"):
                cid, rid = args[0], out[0]
            elif op == "settings":
                cid, rid = "settings", args[0]
            elif op == "reorder":
                cid, rid = args[0], "~order"
            else:
                cid, rid = args[0], args[1]
            self.state["draft_by"][f"record:{cid}:{rid}"] = {"name": user["name"], "at": int(time.time())}
            if op == "delete":
                records.sweep(self)
            self.save_state()
            self.schedule_preview()
            return out

    def revert(self, change_ids, to="HEAD"):
        """put these draft changes (or every change, with None) back as they were at `to`"""
        with self.lock:
            self.guard()
            changes = self.diff(to, None)
            pick = [c for c in changes if change_ids is None or c["id"] in change_ids]
            self._apply_from(to, pick)
            for c in pick:
                self.state["draft_by"].pop(c["id"], None)
            self.save_state()
            self.schedule_preview()
            return len(pick)

    def _apply_from(self, rev, picks):
        recs = [c for c in picks if c["type"] in ("record", "settings")]
        if recs:                                  # first, and whole: a refusal here leaves everything as it was
            records.undo_changes(self, recs, rev)
        texts = [(c["key"], c["lang"], c["before"] or "") for c in picks if c["type"] == "text" and c["before"] is not None]
        if texts:
            self.content().set_many(texts)
        paths = []
        for c in picks:
            if c["type"] == "image":
                paths += [f["path"] for f in self.slots[c["slot"]]["files"]]
        if paths:
            gitw.checkout(self.work, rev, paths)
        if any(c["type"] == "social" for c in picks):
            want = social.read(self.manifest, self._reader(rev))
            social.write(self.manifest, self.work, want)
        self.invalidate()
        records.sweep(self)

    def undo(self, version, change_id):
        """one change of a published version, taken back: the draft gets the value it had before that version"""
        with self.lock:
            self.guard()
            v = next((r for r in gitw.log(self.work) if r["id"] == version), None)
            if not v or not v["parent"]:
                raise FieldError("no_version")
            changes = self.diff(v["parent"], version)
            pick = [c for c in changes if c["id"] == change_id]
            if not pick:
                raise FieldError("no_change")
            self._apply_from(v["parent"], pick)
            self.state["draft_by"][change_id] = {"name": "undo", "at": int(time.time())}
            self.save_state()
            self.schedule_preview()
            return pick[0]

    def restore(self, version):
        """the whole site back to how it was at that version, as a draft to preview and publish"""
        with self.lock:
            self.guard()
            v = next((r for r in gitw.log(self.work) if r["id"] == version), None)
            if not v:
                raise FieldError("no_version")
            paths = [p for p in self.managed_paths() if gitw.show(self.work, version, p, binary=True) is not None]
            gitw.checkout(self.work, version, paths)
            self.invalidate()
            records.sweep(self)
            self.schedule_preview()
            return len(self.diff())

    # ── history ──────────────────────────────────────────────────────────────────────────────────────────────────
    def history(self, limit=60):
        rows = gitw.log(self.work, limit)
        cache = self.state.setdefault("history", {})
        out = []
        for r in rows:
            if r["parent"] and r["id"] not in cache:
                cache[r["id"]] = self.diff(r["parent"], r["id"])
            meta = {}
            m = re.search(r"Panel-Live: (.+)", r["body"])
            if m:
                meta["live"] = m.group(1).strip()
            out.append({**r, "changes": cache.get(r["id"], []), "first": not r["parent"], **meta})
        self.save_state()
        return out

    # ── previews ─────────────────────────────────────────────────────────────────────────────────────────────────
    def schedule_preview(self, delay=1.6):
        if self._timer:
            self._timer.cancel()
        self._timer = threading.Timer(delay, self.preview)
        self._timer.daemon = True
        self._timer.start()

    def preview(self):
        """a marked build of the draft as it stands; the canvas and the Preview step both read the newest"""
        with self.lock:
            if self._building:
                self._dirty = True
                return None
            content = self.content()
            values = {f"{k}|{L}": content.fields[k].values.get(L) for k in content.order for L in self.langs}
            img_hash = {sid: [self._hash(f["path"], None) for f in sl["files"]] for sid, sl in self.slots.items()}
            rec_hash = self._records_hash()
            cur = self.preview_meta()
            if cur and cur.get("values") == values and cur.get("images") == img_hash and cur.get("records") == rec_hash:
                return cur                          # nothing changed since the newest preview
            self._building = True
            self._dirty = False
            bid = secrets.token_urlsafe(18)
            dest = os.path.join(self.builds_dir, bid)
            src = os.path.join(dest, "src")
            try:
                os.makedirs(dest)
                # the snapshot is copied under the lock, so no edit lands half way into it
                builds.snapshot(self.work, src, self.manifest.get("workspace_exclude", []))
            except Exception:
                self._building = False
                shutil.rmtree(dest, ignore_errors=True)
                raise
        try:
            res = builds.build(self, dest, content, marked=True, base=f"/b/{bid}/")
            if not res["ok"]:                     # a marked build that fails falls back to the plain one
                shutil.rmtree(src, ignore_errors=True)
                with self.lock:
                    builds.snapshot(self.work, src, self.manifest.get("workspace_exclude", []))
                res = builds.build(self, dest, content, marked=False, base=f"/b/{bid}/")
            pv = {"id": bid, "at": time.time(), "ok": res["ok"], "marked": res["marked"], "seconds": res["seconds"],
                  "error": res.get("error"), "ids": res["ids"], "values": values, "images": img_hash, "records": rec_hash}
            if res["ok"]:
                pv["pages"] = builds.pages(res["out"], self.manifest)
                self.reg.builds[bid] = (self, res["out"])
            json.dump(pv, open(os.path.join(dest, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False)
            with self.lock:
                if res["ok"]:
                    old = self.state.get("preview")
                    self.state["preview"] = {"id": bid, "at": pv["at"]}
                    self.state.pop("preview_error", None)
                    self.save_state()
                    self._prune(keep={bid, (old or {}).get("id")})
                else:
                    self.state["preview_error"] = {"at": pv["at"], "error": pv["error"]}
                    self.save_state()
            return pv
        finally:
            with self.lock:
                self._building = False
                again = self._dirty
            if again:
                self.schedule_preview(0.2)

    def preview_now(self, wait=180):
        """the Preview step: whatever is pending is built now, and the caller waits for it"""
        if self._timer:
            self._timer.cancel()
        t0 = time.time()
        while self._building and time.time() - t0 < wait:
            time.sleep(0.15)
        return self.preview()

    def preview_meta(self):
        pv = self.state.get("preview")
        if not pv:
            return None
        p = os.path.join(self.builds_dir, pv["id"], "meta.json")
        if not os.path.exists(p):
            return None
        return json.load(open(p, encoding="utf-8"))

    def preview_fresh(self):
        """the newest preview reflects the draft exactly"""
        pv = self.preview_meta()
        if not pv:
            return False
        c = self.content()
        vals = {f"{k}|{L}": c.fields[k].values.get(L) for k in c.order for L in self.langs}
        imgs = {sid: [self._hash(f["path"], None) for f in sl["files"]] for sid, sl in self.slots.items()}
        return vals == pv["values"] and imgs == pv.get("images") and self._records_hash() == pv.get("records")

    def _prune(self, keep):
        if not os.path.isdir(self.builds_dir):
            return
        for d in os.listdir(self.builds_dir):
            if d not in keep:
                self.reg.builds.pop(d, None)
                shutil.rmtree(os.path.join(self.builds_dir, d), ignore_errors=True)

    # ── publishing ───────────────────────────────────────────────────────────────────────────────────────────────
    def publish(self, user, job):
        with self.lock:
            if self.busy:
                raise Busy(self.busy)
            self.busy = "publishing"
            if self._timer:
                self._timer.cancel()
        real, job = job, _Hold(job)          # the outcome is told only after the site is free again (see finally)
        try:
            with self.lock:
                records.sweep(self)                # an upload no record kept is not part of what goes live
            changes = self.diff()
            if not changes:
                return job.fail("nothing")
            dep = self.cfg.get("deploy", {"kind": "folder"})
            dest = os.path.join(self.root, "publish-" + secrets.token_hex(6))
            job.step("build")
            res = builds.build(self, dest, self.content(), marked=False, base=dep.get("base", "/"),
                               origin=dep.get("origin", ""))
            try:
                if not res["ok"]:
                    return job.fail("build", error=res.get("error"), log=res["log"])
                job.step("checks")
                report = builds.checks(self, res, lang=user.get("lang", "ar"), progress=job.report)
                failed = [r for r in report if not r["ok"]]
                if failed:
                    return job.fail("checks", failures=self.explain(failed), log=[l for r in report for l in r["log"]])
                job.step("deploy")
                live = deploy(self, res["out"], dep)
                job.step("record")
                managed = set(self.managed_paths())
                paths = [p for p in gitw.changed(self.work) if self.is_managed(p, managed)]
                stray = [p for p in gitw.changed(self.work) if not self.is_managed(p, managed)]
                if stray:
                    return job.fail("stray", paths=stray)
                n = len(changes)
                body = "\n".join(_line(c, self) for c in changes[:40])
                msg = f"Published {n} change{'s' if n != 1 else ''}\n\n{body}\n\nPanel-User: {user['email']}\nPanel-Live: {live}"
                rev = gitw.commit(self.work, msg, user["name"], user["email"], paths)
                for c in changes:
                    self.state["draft_by"].pop(c["id"], None)
                self.state["live"] = {"version": rev, "at": int(time.time()), "by": user["name"], "url": live}
                self.save_state()
                self.invalidate()
                return job.done(version=rev, url=live, changes=n)
            finally:
                shutil.rmtree(dest, ignore_errors=True)
        finally:
            with self.lock:
                self.busy = None
            self.schedule_preview(0.1)
            if job.end:                       # a client who sees "done" can act on the site at once: it is free
                kind, code, details = job.end
                real.done(**details) if kind == "done" else real.fail(code, **details)

    def explain(self, failed):
        """each check failure → the rule's own words for the client, and the field it points at"""
        rules = self.manifest.get("explain", [])
        c = self.content()
        out = []
        for r in failed:
            for f in r["failures"]:
                item = {"check": r["name"], "rule": f["rule"], "line": f["line"], "message": None, "field": None,
                        "lang": None}
                for rule in rules:
                    if rule.get("rule") and rule["rule"] != f["rule"]:
                        continue
                    if rule.get("match") and not re.search(rule["match"], f["line"]):
                        continue
                    item["message"] = rule.get("text")
                    if rule.get("where"):
                        m = re.search(rule["where"], f["line"])
                        if m:
                            gd = m.groupdict()
                            p = gd.get("path", "")
                            if rule.get("path_style") == "dotted":
                                p = "/" + re.sub(r"\[(\d+)\]", r"/\1", p).replace(".", "/")
                            key = f"{rule.get('source', '')}:{p}"
                            if key in c.fields:
                                item["field"] = key
                                item["lang"] = gd.get("lang")
                    break
                if not item["field"]:
                    item["field"], item["lang"] = self._guess_field(f["line"], c)
                out.append(item)
        # the same fault is often caught twice — in the text and again in the built page; say it once, at the text
        mapped = {(i["rule"], i["field"], i["lang"]) for i in out if i["field"]}
        rules = {i["rule"] for i in out if i["field"]}
        seen, folded, said = set(), [], set()
        for i in out:
            k = (i["rule"], i["field"], i["lang"])
            if (not i["field"] and i["rule"] in rules) or k in seen:
                continue
            msg = json.dumps(i["message"], sort_keys=True) if i["message"] and not i["field"] else None
            if msg and msg in said:                       # two checks, one fault (a logo caught twice): said once
                continue
            seen.add(k)
            said.add(msg)
            folded.append(i)
        return folded

    def _guess_field(self, line, c):
        for frag in re.findall(r"«([^»]{3,})»|'([^']{4,})'|\"([^\"]{4,})\"", line):
            s = next(x for x in frag if x)
            s = s.rstrip("…").strip()
            for k in c.order:
                for L, v in c.fields[k].values.items():
                    if v and s.lower() in v.lower():
                        return k, L
        return None, None


def _line(c, site):
    if c["type"] == "text":
        a = (c["after"] or "").replace("\n", " ")
        return f"- text {c['key']} [{c['lang']}]: {a[:90]}"
    if c["type"] == "image":
        return f"- picture {c['slot']}"
    if c["type"] == "record":
        t = c.get("title") or {}
        name = (t.get("en") or t.get("ar") or c["rid"]) if isinstance(t, dict) else str(t)
        if c["op"] == "order":
            return f"- record {c['coll']}: new order"
        extra = f" ({', '.join(c['fields'])})" if c["op"] == "changed" else ""
        return f"- record {c['coll']} {c['op']} {c['rid']}: {name[:80]}{extra}"
    if c["type"] == "settings":
        return f"- settings {c['group']}.{c['field']}"
    return f"- social {c['network']}: {c.get('after') or ''}"


def deploy(site, out, dep):
    """the built site to where it is served; returns its address"""
    kind = dep.get("kind", "folder")
    if kind == "folder":
        target = os.path.normpath(os.path.join(site.reg.data, dep.get("path", f"live/{site.cid}/{site.sid}")))
        os.makedirs(os.path.dirname(target), exist_ok=True)
        tmp = target + ".incoming"
        old = target + ".outgoing"
        shutil.rmtree(tmp, ignore_errors=True)
        shutil.rmtree(old, ignore_errors=True)
        shutil.copytree(out, tmp)
        if os.path.isdir(target):
            os.replace(target, old)
        os.replace(tmp, target)
        shutil.rmtree(old, ignore_errors=True)
        return dep.get("url", "")
    if kind == "git":
        repo = os.path.normpath(os.path.join(site.reg.base_dir, dep["repo"]))
        sub = dep["dir"].strip("/")
        if not sub or ".." in sub:
            raise RuntimeError("deploy.dir must be a folder inside the repository")
        if dep.get("pull", True):
            gitw.git(repo, "pull", "--ff-only", "-q")
        target = os.path.join(repo, sub)
        shutil.rmtree(target, ignore_errors=True)
        shutil.copytree(out, target)
        gitw.git(repo, "add", "-A", "--", sub)
        if gitw.git(repo, "status", "--porcelain", "--", sub).strip():
            gitw.commit(repo, f"{sub}: published from the panel", "MIDDLEWARE Panel", "panel@middlewaresy.com")
            if dep.get("push", True):
                gitw.git(repo, "push", "-q")
        return dep.get("url", "")
    raise RuntimeError(f"unknown deploy kind {kind}")
