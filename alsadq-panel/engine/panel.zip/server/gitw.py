"""memgit — the few git operations sites.py uses, kept in memory: the panel's history inside a static demo.

In the static demo (static.py, a site with records) the real server modules run in the visitor's browser, in Pyodide,
and there is no git there. This module stands in for gitw.py with the same functions over in-memory snapshots, so
sites.Site's drafts, review, History, undo and restore run unchanged. static.py ships it under the name gitw.py inside
the demo's engine bundle; on a server, gitw.py (real git) is always the one used. Nothing here is ever written to disk
beyond the working copy itself, and a reload of the demo starts from nothing.
"""
import itertools
import os

SKIP = {".git", "__pycache__", ".panel", "node_modules", ".DS_Store", ".check"}
_REPOS = {}                      # repo path → [commit, …] (oldest first)
_N = itertools.count(1)


class GitError(RuntimeError):
    pass


def _files(repo):
    out = {}
    for dp, dirs, fs in os.walk(repo):
        dirs[:] = [d for d in dirs if d not in SKIP and not d.startswith("dist")]
        for f in fs:
            if f in SKIP or f.endswith(".panel-tmp"):
                continue
            p = os.path.join(dp, f)
            out[os.path.relpath(p, repo).replace(os.sep, "/")] = p
    return out


def _read(p):
    with open(p, "rb") as fh:
        return fh.read()


def _commits(repo):
    if repo not in _REPOS:
        raise GitError(f"{repo} is not a repository")
    return _REPOS[repo]


def _rev(repo, rev):
    cs = _commits(repo)
    if rev in ("HEAD", None):
        return cs[-1]
    for c in reversed(cs):
        if c["id"] == rev or (len(rev) >= 7 and c["id"].startswith(rev)):
            return c
    raise GitError(f"unknown revision {rev}")


def _new(repo, parent, files, message, name, email):
    import hashlib
    import time
    n = next(_N)
    cid = hashlib.sha1(f"{repo}\0{n}\0{message}\0{time.time()}".encode()).hexdigest()
    subject, _, body = message.partition("\n\n")
    c = {"id": cid, "parent": parent["id"] if parent else None, "name": name, "email": email, "at": int(time.time()),
         "subject": subject, "body": body.strip(), "files": files}
    _REPOS.setdefault(repo, []).append(c)
    return cid


def has(repo):
    return repo in _REPOS


def init(repo, message, name="MIDDLEWARE Panel", email="panel@middlewaresy.com"):
    _REPOS.pop(repo, None)
    _new(repo, None, {rel: _read(p) for rel, p in _files(repo).items()}, message, name, email)


def commit(repo, message, name, email, paths=None):
    parent = _rev(repo, "HEAD")
    files = dict(parent["files"])
    if paths is not None:
        if not paths:
            raise GitError("nothing to commit")
        for rel in paths:
            p = os.path.join(repo, rel)
            if os.path.isfile(p):
                files[rel] = _read(p)
            else:
                files.pop(rel, None)
    else:
        files = {rel: _read(p) for rel, p in _files(repo).items()}
    return _new(repo, parent, files, message, name, email)


def head(repo):
    return _rev(repo, "HEAD")["id"]


def show(repo, rev, path, binary=False):
    try:
        b = _rev(repo, rev)["files"].get(path)
    except GitError:
        return None
    if b is None:
        return None
    return b if binary else b.decode("utf-8")


def changed(repo):
    tracked = _rev(repo, "HEAD")["files"]
    now = _files(repo)
    out = [rel for rel, p in now.items() if rel not in tracked or tracked[rel] != _read(p)]
    out += [rel for rel in tracked if rel not in now]
    return out


def checkout(repo, rev, paths):
    files = _rev(repo, rev)["files"]
    for rel in paths or []:
        p = os.path.join(repo, rel)
        if rel in files:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "wb") as fh:
                fh.write(files[rel])
        elif os.path.exists(p):
            os.remove(p)


def log(repo, limit=100):
    rows = []
    for c in reversed(_commits(repo)[-limit:]):
        rows.append({k: c[k] for k in ("id", "parent", "name", "email", "at", "subject", "body")})
    return rows


def files_at(repo, rev, paths):
    c = _rev(repo, rev)
    p = _rev(repo, c["parent"])["files"] if c["parent"] else {}
    return [x for x in paths if c["files"].get(x) != p.get(x)]


def git(repo, *args, check=True, binary=False, env_extra=None):
    """only what sites.py and records.py ask of git directly: the files tracked under some folders"""
    if args and args[0] == "ls-files":
        dirs = [a.rstrip("/") + "/" for a in args[args.index("--") + 1:]] if "--" in args else [""]
        out = "\n".join(sorted(rel for rel in _rev(repo, "HEAD")["files"] if any(rel.startswith(d) for d in dirs)))
        return out.encode() if binary else out
    raise GitError(f"git {' '.join(args[:2])} is not available in the demo")
