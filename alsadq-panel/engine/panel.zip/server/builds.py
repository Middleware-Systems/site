"""builds — a site built the way its developers build it, from a snapshot of the draft, and checked the same way.

Every build runs in its own copy of the working copy, so a build never writes into the draft and two builds never
meet. A preview build is the same command on content carrying invisible markers (markers.py); a publish build is the
same command on the content exactly as it will go live, followed by every check the site's panel.json names. Nothing
is published unless the build succeeds and every check passes.
"""
import html
import json
import os
import re
import shutil
import subprocess
import sys
import time

from . import jsonspan, markers
from .jsonspan import unptr

SKIP = {".git", ".panel", "__pycache__", "node_modules", ".DS_Store"}


def snapshot(work, dest, exclude=()):
    def ignore(d, names):
        rel = os.path.relpath(d, work)
        out = set()
        for n in names:
            p = n if rel == "." else os.path.join(rel, n)
            if n in SKIP or n.startswith("dist") or any(_glob(p, e) for e in exclude):
                out.add(n)
        return out
    shutil.copytree(work, dest, ignore=ignore, symlinks=False)


def _glob(p, pattern):
    import fnmatch
    return fnmatch.fnmatchcase(p, pattern)


def mark(root, content):
    """rewrite every editable string in the snapshot with its invisible id; returns id → (field key, lang)"""
    ids = []
    per_file = {}
    for key in content.order:
        f = content.fields[key]
        for lang in content.langs:
            v = f.values.get(lang)
            if not v:
                continue
            file, p = f.loc[lang]
            n = len(ids)
            ids.append((key, lang))
            per_file.setdefault(file, {})[p] = markers.wrap(v, n)
    for file, changes in per_file.items():
        path = os.path.join(root, file)
        data = json.load(open(path, encoding="utf-8"))
        for p, v in changes.items():
            parts = unptr(p)
            tgt = data
            for k in parts[:-1]:
                tgt = tgt[k]
            tgt[parts[-1]] = v
        json.dump(data, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return ids


def _fill(args, ctx):
    return [a.format(**ctx) for a in args]


def run(cmd, cwd, timeout, log, on_line=None):
    """a command in a fresh environment; its output kept for the log (and, line by line, for on_line as it comes)"""
    if on_line is not None:
        return run_stream(cmd, cwd, timeout, log, on_line)
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": os.environ.get("HOME", "/tmp"),
           "LANG": "en_US.UTF-8", "LC_ALL": "en_US.UTF-8", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONUTF8": "1"}
    t0 = time.time()
    p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, start_new_session=True)
    try:
        so, se = p.communicate(timeout=timeout)
        out = (so + se).decode("utf-8", "replace")
        code = p.returncode
    except subprocess.TimeoutExpired:
        _kill_group(p)
        so, se = p.communicate()
        out = ((so or b"") + (se or b"")).decode("utf-8", "replace") + f"\n✗ stopped after {timeout} s"
        code = -9
    log.append({"cmd": " ".join(os.path.basename(c) if i == 0 else c for i, c in enumerate(cmd)),
                "code": code, "seconds": round(time.time() - t0, 2), "out": out[-20000:]})
    return code, out


def _env():
    return {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": os.environ.get("HOME", "/tmp"),
            "LANG": "en_US.UTF-8", "LC_ALL": "en_US.UTF-8", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1"}


def _kill_group(p):
    """a command stopped with everything it started (a check's own Chrome would otherwise be left running)"""
    import signal
    try:
        os.killpg(p.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        p.kill()


def run_stream(cmd, cwd, timeout, log, on_line):
    """as run(), reading the output as it is printed, so a long check can say how far it has got"""
    import threading
    t0 = time.time()
    p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=_env(), start_new_session=True)
    lines = []
    killed = threading.Timer(timeout, _kill_group, (p,))
    killed.start()
    try:
        for raw in iter(p.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").rstrip("\n")
            lines.append(line)
            try:
                on_line(line)
            except Exception:
                pass
        p.wait()
    finally:
        killed.cancel()
    out = "\n".join(lines)
    code = p.returncode
    if time.time() - t0 >= timeout:
        out += f"\n✗ stopped after {timeout} s"
        code = -9
    log.append({"cmd": " ".join(os.path.basename(c) if i == 0 else c for i, c in enumerate(cmd)),
                "code": code, "seconds": round(time.time() - t0, 2), "out": out[-20000:]})
    return code, out


PROGRESS = re.compile(r"^\s*(?:…|\.\.\.)\s*(\d+)\s*/\s*(\d+)\s*(.*)$")


def supports(site, cmd, flag, cwd):
    """whether a check knows a flag (asked once, through its own --help): a newer flag is passed only where it exists"""
    cache = site.__dict__.setdefault("_flags", {})
    key = (tuple(cmd), flag)
    if key not in cache:
        try:
            r = subprocess.run(cmd + ["--help"], cwd=cwd, capture_output=True, timeout=60, env=_env())
            cache[key] = flag in (r.stdout + r.stderr).decode("utf-8", "replace")
        except Exception:
            cache[key] = False
    return cache[key]


def build(site, dest, content, *, marked, base, origin=""):
    """snapshot → (marked) → the site's own build command; returns a result dict"""
    m = site.manifest
    log = []
    src = os.path.join(dest, "src")
    t0 = time.time()
    if not os.path.isdir(src):                 # a caller may have taken the snapshot already, under the site's lock
        snapshot(site.work, src, m.get("workspace_exclude", []))
    ids = mark(src, content) if marked else []
    ctx = {"python": sys.executable, "base": base, "origin": origin, "out": "dist", "base_dir": base.strip("/")}
    b = m["build"]
    code, out = run(_fill(b["run"], ctx), src, b.get("timeout", 240), log)
    outdir = os.path.normpath(os.path.join(src, b.get("output", "dist").format(**ctx)))   # e.g. "dist/{base_dir}"
    if not (outdir == src or outdir.startswith(src + os.sep)):
        raise RuntimeError("build.output must stay inside the site")
    ok = code == 0 and os.path.isdir(outdir)
    res = {"ok": ok, "marked": marked, "log": log, "seconds": round(time.time() - t0, 2), "ids": ids,
           "src": src, "out": outdir, "base": base}
    if not ok:
        res["error"] = _last_error(out)
    return res


def checks(site, result, lang="en", progress=None):
    """every check the manifest names, on the build just made; each failure parsed into rule · where · message.
    A check that prints "… 7/20 <what>" lines reports them to `progress` as it goes; a flag the manifest lists under
    "if_supported" (e.g. ["--lang", "{lang}"]) is passed only when the check's own --help names it."""
    m = site.manifest
    ctx = {"python": sys.executable, "base": result["base"], "origin": "", "out": "dist", "lang": lang,
           "base_dir": result["base"].strip("/")}
    report = []
    for i, c in enumerate(m.get("checks", [])):
        log = []
        cmd = _fill(c["run"], ctx)
        for extra in c.get("if_supported", []):
            if supports(site, _fill(c["run"][:2], ctx), extra[0], result["src"]):
                cmd += _fill(extra, ctx)

        def on_line(line, i=i):
            mt = PROGRESS.match(line)
            if mt and progress:
                progress({"check": i, "done": int(mt.group(1)), "total": int(mt.group(2)), "what": mt.group(3).strip()[:120]})
        code, out = run(cmd, result["src"], c.get("timeout", 600), log, on_line if progress else None)
        fails = []
        for line in out.splitlines():
            line = line.strip()
            if not line.startswith("✗"):
                continue
            body = line[1:].strip()
            if re.match(r"^\d+ (of \d+ )?(failure|assertion|problem)", body):
                continue                                   # the summary line, not a failure
            if c.get("ignore") and re.search(c["ignore"], body):
                continue                                   # the check's own verdict, in whatever language it speaks
            mt = re.match(r"^(\S+)\s+(.*)$", body)
            rule, rest = (mt.group(1), mt.group(2)) if mt else ("", body)
            where, msg = rest, ""
            if ": " in rest:
                where, msg = rest.split(": ", 1)
            fails.append({"rule": rule, "where": where.strip(), "msg": msg.strip(), "line": body})
        if code and not fails:
            fails.append({"rule": "", "where": "", "msg": _last_error(out), "line": _last_error(out)})
        report.append({"name": c.get("name", {}), "ok": code == 0, "failures": fails, "log": log})
    return report


def _last_error(out):
    lines = [l for l in out.strip().splitlines() if l.strip()]
    for l in reversed(lines):
        if "✗" in l or "Error" in l or "error" in l:
            return l.strip()[:400]
    return (lines[-1] if lines else "the build stopped without saying why")[:400]


# ── reading a build: its pages, and where each marked string landed ──────────────────────────────────────────────

_LANG = re.compile(r"<html[^>]*\blang=\"([\w-]+)\"", re.I)
_TITLE = re.compile(r"<title[^>]*>(.*?)</title>", re.S | re.I)
_DESC = re.compile(r"<meta\s+name=\"description\"\s+content=\"([^\"]*)\"", re.I)
_IMG = re.compile(r"<img\b[^>]*>", re.I)
_ATTR = re.compile(r"\b(src|alt|srcset)=\"([^\"]*)\"", re.I)


def pages(outdir, manifest):
    """every page of a build: id (the same in each language), language, file, title, description, pictures, field ids"""
    prefixes = {l["code"]: l.get("path", "") for l in manifest["languages"]}
    excl = manifest.get("pages_exclude", [])
    found = []
    for dp, _, fn in os.walk(outdir):
        for f in sorted(fn):
            if not f.endswith(".html"):
                continue
            full = os.path.join(dp, f)
            rel = os.path.relpath(full, outdir).replace(os.sep, "/")
            path = rel[:-len("index.html")] if rel.endswith("index.html") else rel
            doc = open(full, encoding="utf-8").read()
            m = _LANG.search(doc)
            lang = (m.group(1) if m else "").split("-")[0]
            pre = prefixes.get(lang, "")
            pid = path[len(pre):] if pre and path.startswith(pre) else path
            if any(_glob(pid, e) for e in excl):
                continue
            head_end = doc.find("</head>")
            head = doc[:head_end] if head_end > 0 else ""
            t = _TITLE.search(head)
            d = _DESC.search(head)
            imgs = []
            for tag in _IMG.findall(doc):
                a = dict((k.lower(), v) for k, v in _ATTR.findall(tag))
                srcs = [a.get("src", "")] + [s.strip().split(" ")[0] for s in a.get("srcset", "").split(",") if s.strip()]
                imgs.append({"files": [os.path.basename(s.split("?")[0]) for s in srcs if s],
                             "alt": html.unescape(markers.strip(a.get("alt", ""))), "alt_ids": markers.found(a.get("alt", ""))})
            body = doc[head_end:] if head_end > 0 else doc
            seen, order = set(), []
            for n in markers.found(body):
                if n not in seen:
                    seen.add(n)
                    order.append(n)
            found.append({"id": pid, "lang": lang, "path": path,
                          "title": html.unescape(markers.strip(t.group(1))).strip() if t else "",
                          "title_ids": markers.found(t.group(1)) if t else [],
                          "description": html.unescape(markers.strip(d.group(1))).strip() if d else "",
                          "desc_ids": markers.found(d.group(1)) if d else [],
                          "images": imgs, "ids": order})
    return found
