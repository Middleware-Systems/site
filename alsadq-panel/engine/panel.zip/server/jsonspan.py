"""jsonspan — change string values inside a JSON file and leave every other byte of it alone.

The sites' developers read these files in git. Re-dumping a file on every edit would reformat it (indent, key order,
escapes) and bury a one-word change in a diff of hundreds of lines. So the panel never re-serialises a file to change
a string: it finds the exact span of that string literal and replaces only it, in the file's own escaping style.

Paths are JSON Pointers (RFC 6901): "/stage/h1", "/claims/3/en", "/hacks/0/name~0" (the key «name~»).
Only structural changes (adding or removing a social link) re-serialise, in the file's detected indent.
"""
import json
import re

_WS = " \t\r\n"
_NUM = re.compile(r"-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?")


def ptr(parts):
    """('stage', 'h1') → '/stage/h1'"""
    return "".join("/" + str(p).replace("~", "~0").replace("/", "~1") for p in parts)


def unptr(p):
    """'/hacks/0/name~0' → ['hacks', 0, 'name~'] — digits become list indexes"""
    if p == "":
        return []
    if not p.startswith("/"):
        raise ValueError(f"not a JSON pointer: {p!r}")
    out = []
    for s in p[1:].split("/"):
        s = s.replace("~1", "/").replace("~0", "~")
        out.append(int(s) if s.isdigit() else s)
    return out


def get(obj, p):
    for k in unptr(p) if isinstance(p, str) else p:
        obj = obj[k]
    return obj


class Doc:
    """A JSON file's text with the span of every string value, by path."""

    def __init__(self, text):
        self.text = text
        self.spans = {}                      # path (tuple) → (start, end) of the literal, quotes included
        self.vspans = {}                     # path (tuple) → (start, end) of every value, of any kind
        self.kspans = {}                     # path (tuple) of an object member → (start, end) of its key literal
        self.ascii = _uses_ascii_escapes(text)
        self.value = None
        self._i = 0
        self.value = self._value(())
        self._ws()
        if self._i != len(text):
            raise ValueError(f"trailing data at {self._i}")

    # ── the scanner ──────────────────────────────────────────────────────────────────────────────────────────────
    def _ws(self):
        t, i = self.text, self._i
        while i < len(t) and t[i] in _WS:
            i += 1
        self._i = i

    def _value(self, path):
        self._ws()
        start = self._i
        v = self._value_at(path)
        self.vspans[path] = (start, self._i)
        return v

    def _value_at(self, path):
        t, i = self.text, self._i
        c = t[i]
        if c == "{":
            self._i += 1
            out = {}
            self._ws()
            if t[self._i] == "}":
                self._i += 1
                return out
            while True:
                self._ws()
                k, kspan = self._string()
                self.kspans[path + (k,)] = kspan
                self._ws()
                if t[self._i] != ":":
                    raise ValueError(f"expected ':' at {self._i}")
                self._i += 1
                out[k] = self._value(path + (k,))
                self._ws()
                if t[self._i] == ",":
                    self._i += 1
                    continue
                if t[self._i] == "}":
                    self._i += 1
                    return out
                raise ValueError(f"expected ',' or '}}' at {self._i}")
        if c == "[":
            self._i += 1
            out = []
            self._ws()
            if t[self._i] == "]":
                self._i += 1
                return out
            n = 0
            while True:
                out.append(self._value(path + (n,)))
                n += 1
                self._ws()
                if t[self._i] == ",":
                    self._i += 1
                    continue
                if t[self._i] == "]":
                    self._i += 1
                    return out
                raise ValueError(f"expected ',' or ']' at {self._i}")
        if c == '"':
            s, span = self._string()
            self.spans[path] = span
            return s
        for lit, val in (("true", True), ("false", False), ("null", None)):
            if t.startswith(lit, i):
                self._i += len(lit)
                return val
        m = _NUM.match(t, i)
        if not m:
            raise ValueError(f"unexpected {c!r} at {i}")
        self._i = m.end()
        return json.loads(m.group(0))

    def _string(self):
        t, i = self.text, self._i
        if t[i] != '"':
            raise ValueError(f"expected a string at {i}")
        j = i + 1
        while True:
            c = t[j]
            if c == "\\":
                j += 2
                continue
            if c == '"':
                break
            j += 1
        self._i = j + 1
        return json.loads(t[i:j + 1]), (i, j + 1)

    # ── edits ────────────────────────────────────────────────────────────────────────────────────────────────────
    def literal(self, s):
        return json.dumps(s, ensure_ascii=self.ascii)

    def replace(self, changes):
        """{path (tuple or pointer): new string} → the new file text; every other byte unchanged"""
        edits = []
        for p, new in changes.items():
            key = tuple(unptr(p)) if isinstance(p, str) else tuple(p)
            if key not in self.spans:
                raise KeyError(f"no string at {ptr(key)}")
            if not isinstance(new, str):
                raise TypeError(f"{ptr(key)}: only strings are edited in place")
            edits.append((self.spans[key], self.literal(new)))
        out = self.text
        for (a, b), lit in sorted(edits, key=lambda e: e[0][0], reverse=True):
            out = out[:a] + lit + out[b:]
        return out


def patch(text, value):
    """The file's text with its value changed to `value`, touching only the parts that differ.

    A value that changed is written in place, in the file's own escaping, at its own indentation (or on one line,
    where the old value sat on one line). An object that gains or loses members, or a list that gains, loses or
    reorders items, is rebuilt from its old members' own text: an untouched member keeps every byte, a new one is
    written in its neighbours' style. So a record added to a list adds that record's lines and nothing else."""
    doc = Doc(text)
    a, b = doc.vspans[()]
    return text[:a] + _render(doc, (), doc.value, value) + text[b:]


def _same(old, new):
    return type(old) is type(new) and old == new and _order(old) == _order(new)


def _order(v):
    if isinstance(v, dict):
        return [(k, _order(x)) for k, x in v.items()]
    if isinstance(v, list):
        return [_order(x) for x in v]
    return None


def _render(doc, path, old, new):
    """the text of the value at `path` (old in the file) as it must read to hold `new`"""
    t = doc.text
    a, b = doc.vspans[path]
    if _same(old, new):
        return t[a:b]
    if isinstance(old, dict) and isinstance(new, dict) and old and new:
        if list(old) == list(new):
            return _splice(doc, path, [(k, old[k], new[k]) for k in old], a, b)
        return _rebuild(doc, path, old, new, a, b)
    if isinstance(old, list) and isinstance(new, list) and old and new:
        if len(old) == len(new) and [_ident(x) for x in old] == [_ident(x) for x in new]:
            return _splice(doc, path, [(i, old[i], new[i]) for i in range(len(old))], a, b)
        return _rebuild(doc, path, old, new, a, b)
    return _dump_at(doc, a, b, new)


def _splice(doc, path, members, a, b):
    """the container's own text with each member's value re-rendered in place"""
    t, out, at = doc.text, [], a
    for k, o, n in members:
        va, vb = doc.vspans[path + (k,)]
        out.append(t[at:va])
        out.append(_render(doc, path + (k,), o, n))
        at = vb
    out.append(t[at:b])
    return "".join(out)


def _ident(v):
    if isinstance(v, dict):
        for k in ("id", "key", "slug", "network"):
            if isinstance(v.get(k), (str, int)):
                return (k, v[k])
    return ("=", json.dumps(v, sort_keys=True, ensure_ascii=False))


def _rebuild(doc, path, old, new, a, b):
    """members added, removed or moved: the old members' text reused, new ones written like their neighbours"""
    import difflib
    t = doc.text
    is_dict = isinstance(old, dict)
    okeys = list(old) if is_dict else list(range(len(old)))

    def mstart(k):
        return doc.kspans[path + (k,)][0] if is_dict else doc.vspans[path + (k,)][0]
    first, last = okeys[0], okeys[-1]
    prefix, suffix = t[a:mstart(first)], t[doc.vspans[path + (last,)][1]:b]
    if len(okeys) > 1:
        sep = t[doc.vspans[path + (okeys[0],)][1]:mstart(okeys[1])]
    else:
        sep = "," + prefix[1:] if "\n" in prefix else ", "
    one_line = "\n" not in t[a:b]
    line_start = t.rfind("\n", 0, mstart(first)) + 1
    lead = re.match(r"[ \t]*", t[line_start:]).group(0)
    colon = ": "
    if is_dict:
        ka, kb = doc.kspans[path + (first,)]
        colon = t[kb:doc.vspans[path + (first,)][0]]

    fa, fb = doc.vspans[path + (first,)]
    like_one_line = "\n" not in t[fa:fb] and t[fa:fa + 1] in "{["       # its neighbours sit on one line each

    def fresh(v):
        if isinstance(v, str):
            return doc.literal(v)
        if one_line or like_one_line or not isinstance(v, (dict, list)) or not v:
            return json.dumps(v, ensure_ascii=doc.ascii, separators=(", ", ": "))
        ind = detect_indent(t)
        return json.dumps(v, ensure_ascii=doc.ascii, indent=ind if ind is not None else 1).replace("\n", "\n" + lead)

    parts = []
    if is_dict:
        for k, v in new.items():
            if k in old:
                ka, _ = doc.kspans[path + (k,)]
                va, _ = doc.vspans[path + (k,)]
                parts.append(t[ka:va] + _render(doc, path + (k,), old[k], v))
            else:
                parts.append(json.dumps(k, ensure_ascii=doc.ascii) + colon + fresh(v))
    else:
        oi, ni = [_ident(x) for x in old], [_ident(x) for x in new]
        sm = difflib.SequenceMatcher(None, oi, ni, autojunk=False)
        for op, i1, i2, j1, j2 in sm.get_opcodes():
            if op == "equal":
                for d in range(i2 - i1):
                    parts.append(_render(doc, path + (i1 + d,), old[i1 + d], new[j1 + d]))
            elif op in ("insert", "replace"):
                for j in range(j1, j2):
                    parts.append(fresh(new[j]))
    return prefix + sep.join(parts) + suffix


def _dump_at(doc, a, b, value):
    t = doc.text
    if isinstance(value, str):
        return doc.literal(value)
    if not isinstance(value, (dict, list)) or not value:
        return json.dumps(value, ensure_ascii=doc.ascii)
    old = t[a:b]
    ind = detect_indent(t)
    if "\n" not in old and (old[:1] in "{[" or ind is None):          # it sat on one line: it stays on one line
        return json.dumps(value, ensure_ascii=doc.ascii, separators=(", ", ": "))
    line_start = t.rfind("\n", 0, a) + 1
    lead = re.match(r"[ \t]*", t[line_start:a]).group(0)
    out = json.dumps(value, ensure_ascii=doc.ascii, indent=ind if ind is not None else 1)
    return out.replace("\n", "\n" + lead)


def _uses_ascii_escapes(text):
    """True when the file writes non-ASCII as \\uXXXX (json.dump's default) rather than as UTF-8"""
    raw = any(ord(c) > 127 for c in text)
    esc = re.search(r"\\u(?:00[89a-fA-F][0-9a-fA-F]|0[1-9a-fA-F][0-9a-fA-F]{2}|[1-9a-fA-F][0-9a-fA-F]{3})", text)
    return bool(esc) and not raw


def detect_indent(text):
    m = re.search(r"\n([ \t]+)\S", text)
    if not m:
        return None
    ws = m.group(1)
    return "\t" if ws.startswith("\t") else len(ws)


def redump(text, value):
    """A structural change: the whole value, written in the file's own indent and escaping."""
    ind = detect_indent(text)
    out = json.dumps(value, ensure_ascii=_uses_ascii_escapes(text), indent=ind,
                     separators=(",", ": ") if ind is not None else (", ", ": "))
    return out + ("\n" if text.endswith("\n") else "")


def strings(obj, base=()):
    """every string leaf of a value: (path tuple, string)"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from strings(v, base + (k,))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from strings(v, base + (i,))
    elif isinstance(obj, str):
        yield base, obj
