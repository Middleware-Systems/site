"""social — a site's social links: whatever a client pastes becomes the one correct address, written where the site
reads it (a list of links in B2B's site.json; a handle and an address in Indomie's claims)."""
import json
import re
from urllib.parse import urlparse

from . import content as C

NETWORKS = {
    "instagram": {"name": "Instagram", "hosts": ["instagram.com", "instagr.am"], "url": "https://www.instagram.com/{h}/"},
    "facebook": {"name": "Facebook", "hosts": ["facebook.com", "fb.com", "fb.me", "m.facebook.com"], "url": "https://www.facebook.com/{h}"},
    "linkedin": {"name": "LinkedIn", "hosts": ["linkedin.com"], "url": "https://www.linkedin.com/{h}"},
    "youtube": {"name": "YouTube", "hosts": ["youtube.com", "youtu.be", "m.youtube.com"], "url": "https://www.youtube.com/{h}"},
    "tiktok": {"name": "TikTok", "hosts": ["tiktok.com"], "url": "https://www.tiktok.com/{h}"},
    "x": {"name": "X", "hosts": ["x.com", "twitter.com"], "url": "https://x.com/{h}"},
    "telegram": {"name": "Telegram", "hosts": ["t.me", "telegram.me"], "url": "https://t.me/{h}"},
    "whatsapp": {"name": "WhatsApp", "hosts": ["wa.me", "whatsapp.com", "api.whatsapp.com"], "url": "https://wa.me/{h}"},
    "snapchat": {"name": "Snapchat", "hosts": ["snapchat.com"], "url": "https://www.snapchat.com/add/{h}"},
}


class LinkError(ValueError):
    def __init__(self, code, **details):
        super().__init__(code)
        self.code = code
        self.details = details


def network_of(url):
    host = (urlparse(url).hostname or "").lower()
    host = host[4:] if host.startswith("www.") else host
    for nid, n in NETWORKS.items():
        if any(host == h or host.endswith("." + h) for h in n["hosts"]):
            return nid
    return None


def normalise(raw, expect=None):
    """anything a person might paste — a full address, a bare host/path, an @handle — → (network, handle path, url)"""
    s = (raw or "").strip()
    if not s:
        raise LinkError("empty")
    if len(s) > 300 or re.search(r"\s", s):
        raise LinkError("not_link")
    if s.startswith("@"):
        if not expect:
            raise LinkError("which_network")
        h = s[1:]
        if not re.fullmatch(r"[\w.\-]{1,80}", h):
            raise LinkError("not_link")
        return expect, h, NETWORKS[expect]["url"].format(h=h)
    if not re.match(r"^https?://", s, re.I):
        s = "https://" + s
    u = urlparse(s)
    if u.scheme.lower() not in ("http", "https") or not u.hostname or "." not in u.hostname:
        raise LinkError("not_link")
    nid = network_of(s)
    if expect and nid != expect:
        raise LinkError("wrong_network", expected=NETWORKS[expect]["name"], got=NETWORKS.get(nid, {}).get("name") or u.hostname)
    if not nid:
        raise LinkError("unknown_network", host=u.hostname)
    path = u.path.strip("/")
    if nid == "facebook" and u.path.startswith("/profile.php"):
        path = "profile.php?" + u.query
    if not path:
        raise LinkError("no_profile")
    if nid == "youtube" and not re.match(r"^(@|channel/|c/|user/)", path):
        path = "@" + path if "/" not in path else path
    return nid, path, NETWORKS[nid]["url"].format(h=path)


def _same(a, b):
    try:
        return normalise(a)[2] == normalise(b)[2]
    except LinkError:
        return False


def _fmt(fmt, nid, h, url):
    if fmt == "url":
        return url
    if fmt == "@handle":
        return "@" + h.split("/")[0]
    if fmt == "host/path":
        host = NETWORKS[nid]["hosts"][0]
        return f"{host}/{h}"
    if fmt == "handle":
        return h
    raise ValueError(f"unknown social format {fmt}")


def read(manifest, read_text):
    """the links as they stand: [{network, name, url}] in the site's order"""
    cfg = manifest.get("social")
    if not cfg:
        return []
    if cfg["kind"] == "list":
        data = json.loads(read_text(cfg["file"]))
        items = C.jsonspan.get(data, cfg["pointer"])
        out = []
        for it in items:
            url = it.get(cfg.get("url", "url"), "")
            out.append({"network": network_of(url) or "", "name": it.get(cfg.get("name", "name"), ""), "url": url})
        return out
    out = []
    for n in cfg["networks"]:
        t = next((t for t in n["targets"] if t["format"] == "url"), n["targets"][0])
        data = json.loads(read_text(t["file"]))
        v = C.jsonspan.get(data, C.resolve(data, t["pointer"]))
        url = v if t["format"] == "url" else normalise(v if t["format"] != "@handle" else v, n["network"])[2]
        out.append({"network": n["network"], "name": NETWORKS[n["network"]]["name"], "url": url})
    return out


def write(manifest, root, links):
    """[{network?, url}] as typed → normalised and written; returns the links as saved"""
    cfg = manifest["social"]
    clean = []
    if cfg["kind"] == "list":
        allowed = cfg.get("allowed") or list(NETWORKS)
        if len(links) > 12:
            raise LinkError("too_many")
        for i, l in enumerate(links):
            try:
                nid, h, url = normalise(l.get("url"), l.get("network") or None)
            except LinkError as e:
                e.details["index"] = i
                raise
            if nid not in allowed:
                raise LinkError("not_allowed", index=i, name=NETWORKS[nid]["name"])
            clean.append({"network": nid, "name": NETWORKS[nid]["name"], "url": url})
        if len({c["network"] for c in clean}) != len(clean):
            raise LinkError("twice")
        text = C._read(root, cfg["file"])
        data = json.loads(text)
        old = C.jsonspan.get(data, cfg["pointer"])
        items = []
        uk = cfg.get("url", "url")
        for c in clean:                         # keep any other keys an existing item carries
            prev = next((o for o in old if network_of(o.get(uk, "")) == c["network"]), {})
            if prev and _same(prev.get(uk, ""), c["url"]):
                c["url"] = prev[uk]             # the same address, written as the site had it: not a change
            items.append({**prev, cfg.get("name", "name"): c["name"], uk: c["url"]})
        C.write_json_value(root, cfg["file"], cfg["pointer"], items)
        return clean
    by = {l.get("network"): l for l in links}
    for n in cfg["networks"]:
        l = by.get(n["network"])
        if l is None:
            continue
        try:
            nid, h, url = normalise(l.get("url"), n["network"])
        except LinkError as e:
            e.details["network"] = n["network"]
            raise
        for t in n["targets"]:
            data = json.loads(C._read(root, t["file"]))
            p = C.resolve(data, t["pointer"])
            old = C.jsonspan.get(data, p)
            new = _fmt(t["format"], nid, h, url)
            if t["format"] == "url" and isinstance(old, str) and _same(old, new):
                continue                        # the same address as written: leave it as it is
            if old != new:
                C.write_string(root, t["file"], p, new)
        clean.append({"network": nid, "name": NETWORKS[nid]["name"], "url": url})
    return clean


def files(manifest):
    cfg = manifest.get("social")
    if not cfg:
        return []
    if cfg["kind"] == "list":
        return [cfg["file"]]
    return sorted({t["file"] for n in cfg["networks"] for t in n["targets"]})
