"""content — a site's words as fields, read from and written to the site's own JSON files.

A site's panel.json names its text sources; each becomes fields a client can edit, in every language the site has:

  parallel   one file per language with the same shape (B2B's copy/en.json and copy/ar.json): every string is a field,
             its path the same in each file.
  bilingual  one file whose objects carry each language side by side ({"en": …, "ar": …}, Indomie's claims and
             recipes): every object holding a pair of language keys is a field.

Tokens — a figure [[pos]], a placeholder {n} — are part of a string the client may move but never delete or invent:
the editor shows them as locked chips and the server refuses a value whose tokens differ.
"""
import fnmatch
import json
import os
import re
import unicodedata
from collections import Counter

from . import jsonspan
from .jsonspan import ptr, unptr

MAX_LEN = 3000


class FieldError(ValueError):
    """an edit refused, with a reason the client can read (a code the UI translates, and its details)"""

    def __init__(self, code, **details):
        super().__init__(code)
        self.code = code
        self.details = details


def _read(root, rel):
    p = os.path.join(root, rel)
    return open(p, encoding="utf-8").read()


def _write(root, rel, text):
    p = os.path.join(root, rel)
    tmp = p + ".panel-tmp"
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        f.write(text)
    os.replace(tmp, p)


def _excluded(pointer, patterns):
    return any(fnmatch.fnmatchcase(pointer, pat) for pat in patterns)


class Tokens:
    """the manifest's token patterns, and what each token shows as a chip"""

    def __init__(self, manifest, read):
        self.rules = []
        for t in manifest.get("tokens", []):
            rx = re.compile(t["pattern"])
            values = None
            if t.get("values"):
                v = t["values"]
                data = json.loads(read(v["file"]))
                values = (v, data)
            self.rules.append((rx, t, values))

    def find(self, s):
        out = []
        for rx, _, _ in self.rules:
            out += [m.group(0) for m in rx.finditer(s or "")]
        return out

    def label(self, tok, lang):
        for rx, t, values in self.rules:
            m = rx.fullmatch(tok)
            if not m:
                continue
            if values:
                v, data = values
                rec = data.get(m.group(v.get("group", 1)))
                if isinstance(rec, dict) and v.get("show") in rec:
                    s = str(rec[v["show"]])
                    bare = v.get("bare_group")
                    if v.get("plus") and rec.get(v["plus"]) and not (bare and m.group(bare)):
                        s += "+"
                    return s
                if v.get("else"):
                    return v["else"].get(lang) or v["else"].get("en")
            if t.get("labels"):
                key = m.group(1) if m.groups() else tok
                lab = t["labels"].get(key)
                if lab:
                    return lab.get(lang) or lab.get("en")
            return tok
        return tok



class Field:
    __slots__ = ("key", "src", "loc", "kind", "values", "tokens")

    def __init__(self, key, src):
        self.key, self.src = key, src
        self.loc = {}          # lang → (file, pointer of the string)
        self.values = {}       # lang → str or None
        self.tokens = {}       # lang → list of tokens


class Content:
    """every field of one site, read from its working copy"""

    def __init__(self, root, manifest, read=None, skip=()):
        self.root = root
        self.m = manifest
        self.read = read or (lambda rel: _read(root, rel))
        self.langs = [l["code"] for l in manifest["languages"]]
        self.tok = Tokens(manifest, self.read)
        self.fields = {}       # key → Field
        self.order = []
        self.skip = set(skip)
        self._load()

    # ── reading ──────────────────────────────────────────────────────────────────────────────────────────────────
    def _add(self, f):
        self.fields[f.key] = f
        self.order.append(f.key)

    def _load(self):
        for src in self.m["text"]:
            ex = src.get("exclude", [])
            if src["kind"] == "parallel":
                docs = {L: json.loads(self.read(src["files"][L])) for L in self.langs}
                first = self.langs[0]
                seen = []
                for path, _ in jsonspan.strings(docs[first]):
                    seen.append(path)
                for L in self.langs[1:]:            # a key only the other language has is still a field
                    for path, _ in jsonspan.strings(docs[L]):
                        if path not in seen:
                            seen.append(path)
                for path in seen:
                    p = ptr(path)
                    if _excluded(p, ex):
                        continue
                    f = Field(f"{src['id']}:{p}", src["id"])
                    for L in self.langs:
                        try:
                            v = jsonspan.get(docs[L], list(path))
                        except (KeyError, IndexError, TypeError):
                            v = None
                        f.loc[L] = (src["files"][L], p)
                        f.values[L] = v if isinstance(v, str) else None
                    self._add(f)
            elif src["kind"] == "bilingual":
                doc = json.loads(self.read(src["file"]))
                pairs = src.get("pairs") or [{"name": "", **{L: L for L in self.langs}}]
                for path, obj in _objects(doc):
                    p = ptr(path)
                    if _excluded(p, ex):
                        continue
                    for pair in pairs:
                        keys = {L: pair[L] for L in self.langs}
                        if not all(k in obj for k in keys.values()):
                            continue
                        if not any(isinstance(obj[k], str) for k in keys.values()):
                            continue
                        name = pair.get("name", "")
                        f = Field(f"{src['id']}:{p}" + (f"|{name}" if name else ""), src["id"])
                        for L in self.langs:
                            v = obj.get(keys[L])
                            f.loc[L] = (src["file"], p + "/" + keys[L].replace("~", "~0").replace("/", "~1"))
                            f.values[L] = v if isinstance(v, str) else None
                        self._add(f)
            else:
                raise ValueError(f"unknown text source kind {src['kind']!r}")
        for f in self.fields.values():
            f.tokens = {L: self.tok.find(v) for L, v in f.values.items()}

    def get(self, key):
        f = self.fields.get(key)
        if f is None:
            raise FieldError("unknown_field")
        return f

    def public(self):
        """the fields as the panel's interface needs them"""
        out = []
        for k in self.order:
            f = self.fields[k]
            out.append({"key": k, "values": f.values, "hidden": k in self.skip,
                        "chips": {L: {t: self.tok.label(t, L) for t in f.tokens[L]} for L in self.langs},
                        "long": any(v and (len(v) > 90 or "\n" in v) for v in f.values.values())})
        return out

    # ── writing ──────────────────────────────────────────────────────────────────────────────────────────────────
    def clean(self, f, lang, value):
        if not isinstance(value, str):
            raise FieldError("not_text")
        value = unicodedata.normalize("NFC", value.replace("\r\n", "\n").replace("\r", "\n"))
        value = re.sub(r"[\U000E0000-\U000E007F]", "", value)            # never a marker from a pasted preview
        value = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", "", value)
        if len(value) > MAX_LEN:
            raise FieldError("too_long", max=MAX_LEN)
        old = f.values.get(lang)
        if old is not None and "\n" not in old:
            value = re.sub(r"\s*\n\s*", " ", value)
        want = Counter(f.tokens.get(lang) or [])
        got = Counter(self.tok.find(value))
        if want != got:
            missing = list((want - got).elements())
            extra = list((got - want).elements())
            raise FieldError("tokens", missing=[self.tok.label(t, lang) for t in missing],
                             extra=[self.tok.label(t, lang) for t in extra])
        return value

    def set_many(self, edits):
        """[(key, lang, value)] → write each file once; returns the cleaned values"""
        by_file = {}
        cleaned = []
        for key, lang, value in edits:
            f = self.get(key)
            if lang not in f.loc:
                raise FieldError("unknown_language")
            if f.values.get(lang) is None and lang in f.values and not self._slot_exists(f, lang):
                raise FieldError("no_slot")
            v = self.clean(f, lang, value)
            file, p = f.loc[lang]
            by_file.setdefault(file, {})[p] = v
            cleaned.append((f, lang, v))
        for file, changes in by_file.items():
            text = _read(self.root, file)
            doc = jsonspan.Doc(text)
            _write(self.root, file, doc.replace(changes))
        for f, lang, v in cleaned:
            f.values[lang] = v
        return [(f.key, lang, v) for f, lang, v in cleaned]

    def _slot_exists(self, f, lang):
        file, p = f.loc[lang]
        doc = jsonspan.Doc(_read(self.root, file))
        return tuple(unptr(p)) in doc.spans


def _objects(obj, base=()):
    if isinstance(obj, dict):
        yield base, obj
        for k, v in obj.items():
            yield from _objects(v, base + (k,))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _objects(v, base + (i,))


def read_json(root, rel):
    return json.loads(_read(root, rel))


def write_json_value(root, rel, pointer, value):
    """a structural edit (a list grows or shrinks): the file re-serialised in its own style"""
    text = _read(root, rel)
    data = json.loads(text)
    parts = unptr(pointer)
    tgt = data
    for k in parts[:-1]:
        tgt = tgt[k]
    tgt[parts[-1]] = value
    _write(root, rel, jsonspan.redump(text, data))


def write_string(root, rel, pointer, value):
    text = _read(root, rel)
    _write(root, rel, jsonspan.Doc(text).replace({pointer: value}))


def resolve(data, pointer):
    """a pointer that may select a list item by its id — /claims/[id=social.instagram]/en — as a plain pointer"""
    parts, out, tgt = pointer[1:].split("/") if pointer else [], [], data
    for raw in parts:
        m = re.fullmatch(r"\[(\w+)=([^\]]+)\]", raw)
        if m and isinstance(tgt, list):
            k, v = m.group(1), m.group(2)
            idx = next((i for i, x in enumerate(tgt) if isinstance(x, dict) and str(x.get(k)) == v), None)
            if idx is None:
                raise KeyError(f"no item with {k}={v} in {ptr(out)}")
            out.append(idx)
            tgt = tgt[idx]
            continue
        key = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(tgt, list):
            key = int(key)
        out.append(key)
        tgt = tgt[key]
    return ptr(out)
