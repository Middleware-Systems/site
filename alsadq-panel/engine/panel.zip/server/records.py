"""records — the lists a site is built from (projects, clients, areas of work, figures) and its single settings
objects (contact details, the company), as records a client adds, changes, duplicates, removes and reorders.

A site declares them in its panel.json, under "records":

  collections   each one a JSON array inside one of the site's files: its id field, how a new id is made, the field
                shown as the row's title, and typed fields (bilingual or plain text, number, "auto" or a number,
                dates, a choice of fixed options, a reference to another collection, a picture, yes/no, read-only).
  settings      each one a JSON object inside a file, with typed fields the same way.

Nothing is kept beside the site's own files: a record is the object in the array, a change is the difference between
the working copy and the last published version (as for every other edit), and History and undo are git. A write is
checked whole before anything touches a file — the record's fields, and then every reference across the site: a write
that would leave a project pointing at a client that does not exist, or remove a client a project still uses, is
refused with the names involved, and nothing is written. Files are changed in place (jsonspan.patch): what did not
change keeps its bytes.

Pictures for records (a client's logo, a project's photo) are received here, checked by what they are (their first
bytes, then decoded), stored under a generated name in the one folder the field declares, and never executed: SVG is
accepted only where a field allows it, and only after an allow-list pass that refuses scripts, event handlers,
foreignObject, external references and entity declarations.
"""
import copy
import datetime
import hashlib
import io
import json
import os
import re
import secrets
import time
import unicodedata
import xml.etree.ElementTree as ET

from . import jsonspan
from .content import FieldError

TYPES = {"text", "number", "auto_number", "dates", "choice", "ref", "image", "bool", "readonly"}
ID_RX = re.compile(r"^[a-z0-9][a-z0-9_-]{0,47}$")
NAME_RX = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")
EMAIL_RX = re.compile(r"^[^@\s<>\"']{1,64}@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$")
PHONE_RX = re.compile(r"^\+?[0-9][0-9 ()\-]{4,22}$")
URL_RX = re.compile(r"^https?://[A-Za-z0-9.-]+\.[A-Za-z]{2,}(:\d+)?(/[^\s<>\"]*)?$")
DATE_RX = re.compile(r"^(\d{4})(?:-(\d{2})-(\d{2}))?$")
UPLOAD_MAX = 10 * 1024 * 1024
ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٫", "01234567890123456789.")


# ── the declaration ──────────────────────────────────────────────────────────────────────────────────────────────

class Field:
    def __init__(self, cfg, where):
        self.cfg = cfg
        self.name = cfg.get("name")
        self.type = cfg.get("type")
        if not self.name or not re.fullmatch(r"[A-Za-z_][\w-]{0,40}", self.name):
            raise ValueError(f"records: {where}: a field needs a plain name, not {self.name!r}")
        if self.type not in TYPES:
            raise ValueError(f"records: {where}.{self.name}: unknown type {self.type!r} (one of {', '.join(sorted(TYPES))})")
        self.required = bool(cfg.get("required"))
        self.bilingual = bool(cfg.get("bilingual")) if self.type == "text" else False
        self.many = bool(cfg.get("many", self.type == "dates"))
        self.empty = cfg.get("empty", "omit")             # an optional value left empty: omit the key, or write null
        if self.empty not in ("omit", "null", "empty"):
            raise ValueError(f"records: {where}.{self.name}: empty must be omit, null or empty")
        if self.type == "image":
            folder = cfg.get("folder", "")
            if not folder or os.path.isabs(folder) or ".." in folder.replace("\\", "/").split("/"):
                raise ValueError(f"records: {where}.{self.name}: an image needs a folder inside the site")
            self.folder = folder.strip("/")
            self.accept = cfg.get("accept", ["png", "jpg", "webp"])
            bad = set(self.accept) - {"png", "jpg", "webp", "svg"}
            if bad:
                raise ValueError(f"records: {where}.{self.name}: cannot accept {sorted(bad)}")
            self.store = cfg.get("store", "object")
            self.prefix = cfg.get("prefix", "")

    def label(self):
        return self.cfg.get("label") or {"en": self.name, "ar": self.name}

    def public(self, langs):
        c = {k: v for k, v in self.cfg.items() if k not in ("options_from",)}
        c["label"] = self.label()
        c["many"] = self.many
        c["bilingual"] = self.bilingual
        return c


class Collection:
    def __init__(self, cfg, langs):
        self.cfg = cfg
        self.id = cfg.get("id", "")
        if not ID_RX.match(self.id):
            raise ValueError(f"records: a collection needs a plain id, not {self.id!r}")
        self.file = _safe_rel(cfg.get("file"), f"records: {self.id}.file")
        self.array = cfg.get("array", "")
        self.key = cfg.get("key", "id")
        self.new_key = cfg.get("new_key", {"make": "sequence", "prefix": self.id[:1], "width": 2})
        self.fields = [Field(f, self.id) for f in cfg.get("fields", [])]
        self.by = {f.name: f for f in self.fields}
        if len(self.by) != len(self.fields):
            raise ValueError(f"records: {self.id}: two fields share a name")
        if self.key in self.by:
            raise ValueError(f"records: {self.id}: the id field {self.key!r} is made by the panel, not declared as a field")
        self.title = cfg.get("title")
        if self.title not in self.by:
            raise ValueError(f"records: {self.id}: title {self.title!r} is not one of its fields")
        self.order = cfg.get("order", "manual")           # manual: the client's order is the site's; none: the site sorts
        self.can_add = cfg.get("add", True)
        self.can_delete = cfg.get("delete", True)
        self.new_at = cfg.get("new_at", "end")
        self.new = cfg.get("new", {})                     # fixed values a new record starts with (undeclared keys)
        self.langs = langs

    def public(self):
        return {"id": self.id, "label": self.cfg.get("label", {"en": self.id, "ar": self.id}),
                "one": self.cfg.get("one") or self.cfg.get("label") or {"en": self.id, "ar": self.id},
                "key": self.key, "title": self.title, "subtitle": self.cfg.get("subtitle"),
                "order": self.order, "add": self.can_add, "delete": self.can_delete,
                "filters": self.cfg.get("filters", []), "sort": self.cfg.get("sort"),
                "hint": self.cfg.get("hint"), "fields": [f.public(self.langs) for f in self.fields]}


class Group:
    def __init__(self, cfg, langs):
        self.cfg = cfg
        self.id = cfg.get("id", "")
        if not ID_RX.match(self.id):
            raise ValueError(f"records: a settings group needs a plain id, not {self.id!r}")
        self.file = _safe_rel(cfg.get("file"), f"records: {self.id}.file")
        self.object = cfg.get("object", "")
        self.fields = [Field(f, self.id) for f in cfg.get("fields", [])]
        self.by = {f.name: f for f in self.fields}
        for f in self.fields:
            if f.type == "image":
                raise ValueError(f"records: {self.id}.{f.name}: pictures in settings are not supported; use a picture slot")
        self.langs = langs

    def public(self):
        return {"id": self.id, "label": self.cfg.get("label", {"en": self.id, "ar": self.id}), "hint": self.cfg.get("hint"),
                "fields": [f.public(self.langs) for f in self.fields]}


def _safe_rel(rel, where):
    if not rel or not isinstance(rel, str) or os.path.isabs(rel) or ".." in rel.replace("\\", "/").split("/"):
        raise ValueError(f"{where}: a path inside the site is required, not {rel!r}")
    return rel


class Schema:
    def __init__(self, manifest):
        cfg = manifest.get("records") or {}
        self.langs = [l["code"] for l in manifest["languages"]]
        self.colls = {}
        self.groups = {}
        for c in cfg.get("collections", []):
            col = Collection(c, self.langs)
            if col.id in self.colls:
                raise ValueError(f"records: two collections are called {col.id}")
            self.colls[col.id] = col
        for g in cfg.get("settings", []):
            grp = Group(g, self.langs)
            if grp.id in self.groups or grp.id in self.colls:
                raise ValueError(f"records: {grp.id} is declared twice")
            self.groups[grp.id] = grp
        for col in list(self.colls.values()) + list(self.groups.values()):
            for f in col.fields:
                if f.type == "ref" and f.cfg.get("to") not in self.colls:
                    raise ValueError(f"records: {col.id}.{f.name} refers to {f.cfg.get('to')!r}, which is not a collection")
                if f.type == "choice" and not (f.cfg.get("options") or f.cfg.get("options_from")):
                    raise ValueError(f"records: {col.id}.{f.name}: a choice needs options or options_from")

    def __bool__(self):
        return bool(self.colls or self.groups)

    def files(self):
        out = [c.file for c in self.colls.values()] + [g.file for g in self.groups.values()]
        for col in self.colls.values():
            for f in col.fields:
                if f.type == "choice" and f.cfg.get("options_from"):
                    out.append(_safe_rel(f.cfg["options_from"]["file"], f"records: {col.id}.{f.name}.options_from"))
        for g in self.groups.values():
            for f in g.fields:
                if f.type == "choice" and f.cfg.get("options_from"):
                    out.append(_safe_rel(f.cfg["options_from"]["file"], f"records: {g.id}.{f.name}.options_from"))
        return sorted(set(out))

    def written_files(self):
        return sorted({c.file for c in self.colls.values()} | {g.file for g in self.groups.values()})

    def folders(self):
        return sorted({f.folder for c in self.colls.values() for f in c.fields if f.type == "image"})

    def owned(self):
        """(file, pointer) of every array and object the records own: their text is a record change, not a text change"""
        return [(c.file, c.array) for c in self.colls.values()] + [(g.file, g.object) for g in self.groups.values()]

    def public(self):
        return {"collections": [c.public() for c in self.colls.values()], "settings": [g.public() for g in self.groups.values()]}


# ── the data, at one state of the site ───────────────────────────────────────────────────────────────────────────

class Book:
    """every records file at one state (the draft, or a published version), parsed; changed in memory, then written"""

    def __init__(self, schema, read):
        self.schema = schema
        self.text = {}
        self.data = {}
        for rel in schema.files():
            t = read(rel)
            if t is None:
                raise FieldError("rec_file_missing", file=rel)
            self.text[rel] = t
            self.data[rel] = json.loads(t)

    def items(self, cid):
        col = self.schema.colls[cid]
        arr = jsonspan.get(self.data[col.file], col.array) if col.array else self.data[col.file]
        if not isinstance(arr, list):
            raise FieldError("rec_not_list", collection=cid)
        return arr

    def group(self, gid):
        g = self.schema.groups[gid]
        obj = jsonspan.get(self.data[g.file], g.object) if g.object else self.data[g.file]
        if not isinstance(obj, dict):
            raise FieldError("rec_not_object", group=gid)
        return obj

    def find(self, cid, rid):
        key = self.schema.colls[cid].key
        for i, r in enumerate(self.items(cid)):
            if isinstance(r, dict) and r.get(key) == rid:
                return i, r
        return None, None

    def ids(self, cid):
        key = self.schema.colls[cid].key
        return [r.get(key) for r in self.items(cid) if isinstance(r, dict)]

    def options(self, field):
        """a choice's options: [{value, label}]"""
        if field.cfg.get("options"):
            return [o if isinstance(o, dict) else {"value": o, "label": {L: str(o) for L in self.schema.langs}}
                    for o in field.cfg["options"]]
        of = field.cfg["options_from"]
        src = jsonspan.get(self.data[of["file"]], of.get("path", ""))
        out = []
        if isinstance(src, dict):
            for k, v in src.items():
                if k.startswith("_"):
                    continue
                lab = _pick(v, of.get("label", "")) if isinstance(v, dict) and of.get("label") else v
                out.append({"value": k, "label": _label(lab, self.schema.langs, k)})
        elif isinstance(src, list):
            for v in src:
                if not isinstance(v, dict) or of.get("value", "key") not in v:
                    continue
                out.append({"value": v[of.get("value", "key")],
                            "label": _label(_pick(v, of.get("label", "name")), self.schema.langs, v[of.get("value", "key")])})
        return out

    def changed_texts(self):
        """{file: new text} for every file whose value differs from what was read"""
        out = {}
        for rel in self.schema.written_files():
            if json.loads(self.text[rel]) != self.data[rel] or _keyorder(json.loads(self.text[rel])) != _keyorder(self.data[rel]):
                out[rel] = jsonspan.patch(self.text[rel], self.data[rel])
        return out


def _keyorder(v):
    if isinstance(v, dict):
        return [(k, _keyorder(x)) for k, x in v.items()]
    if isinstance(v, list):
        return [_keyorder(x) for x in v]
    return None


def _pick(obj, path):
    for k in [p for p in path.split(".") if p]:
        if not isinstance(obj, dict):
            return None
        obj = obj.get(k)
    return obj


def _label(v, langs, fallback):
    if isinstance(v, dict):
        return {L: str(v.get(L) or v.get("en") or fallback) for L in langs}
    return {L: str(v if v is not None else fallback) for L in langs}


# ── one value, cleaned ───────────────────────────────────────────────────────────────────────────────────────────

def _text(v, long=False, mx=None):
    if v is None:
        return ""
    if not isinstance(v, str):
        raise _bad("rec_not_text")
    v = unicodedata.normalize("NFC", v.replace("\r\n", "\n").replace("\r", "\n"))
    v = re.sub(r"[\U000E0000-\U000E007F]", "", v)                      # never a marker from a pasted preview
    v = re.sub(r"[\x00-\x08\x0b-\x1f\x7f‪-‮⁦-⁩]", "", v)
    if not long:
        v = re.sub(r"\s*\n\s*", " ", v)
    v = v.strip()
    limit = mx or (3000 if long else 300)
    if len(v) > limit:
        raise _bad("rec_too_long", max=limit)
    return v


class _Bad(Exception):
    def __init__(self, code, **d):
        self.code, self.d = code, d


def _bad(code, **d):
    return _Bad(code, **d)


def _number(v, f):
    if isinstance(v, bool):
        raise _bad("rec_bad_number")
    if isinstance(v, str):
        s = v.strip().translate(ARABIC_DIGITS).replace(",", "").replace("٬", "")
        if s == "":
            return None
        if not re.fullmatch(r"-?\d+(\.\d+)?", s):
            raise _bad("rec_bad_number")
        v = float(s) if "." in s else int(s)
    if not isinstance(v, (int, float)):
        raise _bad("rec_bad_number")
    if f.cfg.get("integer", True):
        if v != int(v):
            raise _bad("rec_not_whole")
        v = int(v)
    if f.cfg.get("min") is not None and v < f.cfg["min"]:
        raise _bad("rec_too_small", min=f.cfg["min"])
    mx = f.cfg.get("max")
    if mx == "this_year":
        mx = datetime.date.today().year
    if mx is not None and v > mx:
        raise _bad("rec_too_big", max=mx)
    return v


def _date(s):
    s = (s or "").strip().translate(ARABIC_DIGITS)
    m = DATE_RX.match(s)
    if not m:
        raise _bad("rec_bad_date", value=s[:20])
    y = int(m.group(1))
    if not 1900 <= y <= 2100:
        raise _bad("rec_bad_date", value=s)
    if m.group(2):
        try:
            datetime.date(y, int(m.group(2)), int(m.group(3)))
        except ValueError:
            raise _bad("rec_bad_date", value=s)
    return s


def clean(f, value, book, current=None, site=None, rid=None):
    """the value a client sent for one field → the value written to the file (or _OMIT); raises _Bad"""
    t = f.type
    langs = book.schema.langs
    if t == "readonly":
        return current if current is not None else _OMIT
    if t == "text":
        if f.bilingual:
            if value is None:
                value = {}
            if not isinstance(value, dict):
                raise _bad("rec_not_text")
            out = {L: _text(value.get(L), f.cfg.get("long"), f.cfg.get("max")) for L in langs}
            filled = [L for L in langs if out[L]]
            if not filled:
                if f.required:
                    raise _bad("rec_required", lang=langs[0])
                return _empty(f)
            if len(filled) != len(langs):
                missing = next(L for L in langs if not out[L])
                raise _bad("rec_both", lang=missing)
            if isinstance(current, dict):                  # keep any other key the object carries, in its order
                merged = dict(current)
                merged.update(out)
                return merged
            return out
        v = _text(value, f.cfg.get("long"), f.cfg.get("max"))
        if not v:
            if f.required:
                raise _bad("rec_required")
            return _empty(f)
        fmt = f.cfg.get("format")
        if fmt == "email" and not EMAIL_RX.match(v):
            raise _bad("rec_bad_email")
        if fmt == "phone":
            v = v.translate(ARABIC_DIGITS)
            if not PHONE_RX.match(v) or len(re.sub(r"\D", "", v)) < 6:
                raise _bad("rec_bad_phone")
        if fmt == "url" and not URL_RX.match(v):
            raise _bad("rec_bad_url")
        return v
    if t == "number":
        v = _number(value, f) if value is not None else None
        if v is None:
            if f.required:
                raise _bad("rec_required")
            return _empty(f)
        return v
    if t == "auto_number":
        if value == "auto":
            return "auto"
        v = _number(value, f) if value not in (None, "") else None
        if v is None:
            if f.required:
                raise _bad("rec_required")
            return _empty(f)
        return v
    if t == "bool":
        if not isinstance(value, bool):
            raise _bad("rec_bad_choice")
        return value
    if t == "dates":
        vals = value if isinstance(value, list) else [x for x in re.split(r"[,\n،]+", value or "")] if isinstance(value, str) else None
        if vals is None:
            raise _bad("rec_bad_date", value="")
        out = []
        for x in vals:
            if not isinstance(x, str):
                raise _bad("rec_bad_date", value=str(x)[:20])
            if not x.strip():
                continue
            d = _date(x)
            if d not in out:
                out.append(d)
        if len(out) > 20:
            raise _bad("rec_too_many", max=20)
        if not out:
            if f.required:
                raise _bad("rec_required")
            return _empty(f, [])
        if not f.many:
            if len(out) > 1:
                raise _bad("rec_one_only")
            return out[0]
        return out
    if t in ("choice", "ref"):
        allowed = None
        if t == "choice":
            allowed = [o["value"] for o in book.options(f)]
        vals = value if isinstance(value, list) else ([] if value in (None, "") else [value])
        out = []
        for x in vals:
            if not isinstance(x, str) or (t == "ref" and not ID_RX.match(x)):
                raise _bad("rec_bad_choice")
            if allowed is not None and x not in allowed:
                raise _bad("rec_bad_choice", value=x[:40])
            if x not in out:
                out.append(x)
        if not out:
            if f.required:
                raise _bad("rec_required")
            return _empty(f, [] if f.many else None)
        if not f.many:
            if len(out) > 1:
                raise _bad("rec_one_only")
            return out[0]
        return out
    if t == "image":
        return _image_value(f, value, current, site, rid)
    raise _bad("rec_bad_field")


class _Omit:
    def __repr__(self):
        return "OMIT"


_OMIT = _Omit()


def _empty(f, blank=""):
    if f.empty == "null":
        return None
    if f.empty == "empty":
        return blank
    return _OMIT


# ── whole records, and the site's integrity ──────────────────────────────────────────────────────────────────────

def _apply(f, rec, value):
    if value is _OMIT:
        rec.pop(f.name, None)
    else:
        rec[f.name] = value


def _keys_like(rec, sibling, col):
    """the record's keys in the order its neighbours use (then the declared order); its values untouched"""
    order = list(sibling.keys()) if isinstance(sibling, dict) else []
    for k in [col.key] + [f.name for f in col.fields] + list(rec):
        if k not in order:
            order.append(k)
    return {k: rec[k] for k in order if k in rec}


def build_record(col, values, book, current=None, site=None, rid=None, partial=False):
    """values the client sent → the record to store, or FieldError("invalid", errors=[…]) naming each field"""
    rec = copy.deepcopy(current) if current is not None else {}
    errors = []
    if not isinstance(values, dict):
        raise FieldError("bad_json")
    unknown = [k for k in values if k not in col.by]
    if unknown:
        raise FieldError("rec_unknown_field", field=unknown[0][:40])
    for f in col.fields:
        if partial and f.name not in values:
            continue
        cur = rec.get(f.name) if current is not None else None
        if f.name in values:
            v = values[f.name]
        elif f.cfg.get("default") is not None:
            v = f.cfg["default"]
        elif f.type == "readonly":
            v = None
        else:
            v = None
        try:
            _apply(f, rec, clean(f, v, book, cur, site, rid))
        except _Bad as e:
            errors.append({"field": f.name, "code": e.code, **e.d})
    if errors:
        raise FieldError("invalid", errors=errors)
    return rec


def problems(book):
    """every rule a book breaks, as comparable tuples: what a write may not add"""
    out = set()
    sch = book.schema
    ids = {cid: set() for cid in sch.colls}
    for cid, col in sch.colls.items():
        seen = set()
        for r in book.items(cid):
            if not isinstance(r, dict):
                out.add((cid, None, "", "rec_not_object", ""))
                continue
            rid = r.get(col.key)
            if not isinstance(rid, str) or not ID_RX.match(rid):
                out.add((cid, str(rid), col.key, "rec_bad_id", ""))
            if rid in seen:
                out.add((cid, rid, col.key, "rec_duplicate", ""))
            seen.add(rid)
        ids[cid] = seen
    for cid, col in sch.colls.items():
        for r in book.items(cid):
            if isinstance(r, dict):
                _check(col.fields, r, r.get(col.key), cid, book, ids, out)
    for gid, g in sch.groups.items():
        _check(g.fields, book.group(gid), "", gid, book, ids, out)
    return out


def _check(fields, r, rid, where, book, ids, out):
    for f in fields:
        v = r.get(f.name)
        if f.type == "ref":
            for x in (v if isinstance(v, list) else [v] if v else []):
                if x not in ids[f.cfg["to"]]:
                    out.add((where, rid, f.name, "rec_ref_missing", str(x)))
        if f.required and f.type != "readonly":
            empty = v is None or v == "" or v == [] or (isinstance(v, dict) and f.bilingual and not any(v.get(L) for L in book.schema.langs))
            if empty:
                out.add((where, rid, f.name, "rec_required", ""))


def refused(book, before):
    """FieldError for every rule this book breaks that `before` did not; nothing when the write may go ahead"""
    new = sorted(problems(book) - before, key=str)
    if not new:
        return None
    errs = []
    for where, rid, field, code, value in new[:12]:
        e = {"collection": where, "id": rid, "field": field, "code": code, "value": value}
        if where in book.schema.colls and rid:
            e["title"] = title_of(book, where, rid)
        errs.append(e)
    return FieldError("rec_integrity", errors=errs)


def users_of(book, cid, rid):
    """every record (and settings group) that refers to this one: [{collection, id, title, field}]"""
    out = []
    sch = book.schema
    for oid, col in sch.colls.items():
        for f in col.fields:
            if f.type == "ref" and f.cfg["to"] == cid:
                for r in book.items(oid):
                    v = r.get(f.name)
                    if rid in (v if isinstance(v, list) else [v]):
                        out.append({"collection": oid, "id": r.get(col.key), "field": f.name,
                                    "title": title_of(book, oid, r.get(col.key))})
    for gid, g in sch.groups.items():
        for f in g.fields:
            if f.type == "ref" and f.cfg["to"] == cid:
                v = book.group(gid).get(f.name)
                if rid in (v if isinstance(v, list) else [v]):
                    out.append({"collection": gid, "id": "", "field": f.name, "title": g.cfg.get("label")})
    return out


def title_of(book, cid, rid, rec=None):
    col = book.schema.colls[cid]
    if rec is None:
        _, rec = book.find(cid, rid)
    if not rec:
        return {L: rid for L in book.schema.langs}
    v = rec.get(col.title)
    f = col.by[col.title]
    if f.type == "ref":
        return title_of(book, f.cfg["to"], v) if isinstance(v, str) else {L: rid for L in book.schema.langs}
    return _label(v, book.schema.langs, rid) if v not in (None, "", {}) else {L: rid for L in book.schema.langs}


# ── new ids ──────────────────────────────────────────────────────────────────────────────────────────────────────

def new_id(col, book, rec):
    taken = set(book.ids(col.id))
    how = col.new_key or {}
    make = how.get("make", "sequence")
    prefix = how.get("prefix", "")
    if make == "slug":
        src = _pick(rec, how.get("from", col.title))
        if isinstance(src, dict):
            src = src.get(how.get("lang", "en")) or ""
        base = _slug(src or "")[: how.get("max", 32)].strip("-")
        if base and not base[0].isalnum():
            base = base.lstrip("-_")
        if not base:                                  # a name with no Latin letters: a numbered id instead
            make, prefix = "sequence", how.get("fallback", col.id[:1] + "-")
        else:
            base = (prefix + base)[:40]
            cand, n = base, 2
            while cand in taken:
                cand, n = f"{base}-{n}", n + 1
            return cand
    if make == "random":
        while True:
            cand = prefix + secrets.token_hex(3)
            if cand not in taken and ID_RX.match(cand):
                return cand
    width = how.get("width", 2)
    n = 0
    for x in taken:
        m = re.fullmatch(re.escape(prefix) + r"(\d+)", x or "")
        if m:
            n = max(n, int(m.group(1)))
    while True:
        n += 1
        cand = f"{prefix}{n:0{width}d}"
        if cand not in taken:
            return cand


def _slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-")


# ── the difference between two books (a published version and the draft) ────────────────────────────────────────

def diff(a, b):
    sch = b.schema
    out = []
    for cid, col in sch.colls.items():
        A = {r.get(col.key): r for r in a.items(cid) if isinstance(r, dict)}
        B = {r.get(col.key): r for r in b.items(cid) if isinstance(r, dict)}
        for rid, r in B.items():
            if rid not in A:
                out.append({"type": "record", "coll": cid, "rid": rid, "op": "added", "fields": [],
                            "title": title_of(b, cid, rid, r), "after": r, "before": None, "id": f"record:{cid}:{rid}"})
            elif A[rid] != r:
                fields = [f.name for f in col.fields if A[rid].get(f.name) != r.get(f.name)]
                if not fields:
                    fields = ["_other"]
                out.append({"type": "record", "coll": cid, "rid": rid, "op": "changed", "fields": fields,
                            "title": title_of(b, cid, rid, r), "after": r, "before": A[rid], "id": f"record:{cid}:{rid}"})
        for rid, r in A.items():
            if rid not in B:
                out.append({"type": "record", "coll": cid, "rid": rid, "op": "removed", "fields": [],
                            "title": title_of(a, cid, rid, r), "before": r, "after": None, "id": f"record:{cid}:{rid}"})
        if col.order == "manual":
            ca = [x for x in A if x in B]
            cb = [x for x in B if x in A]
            if ca != cb:
                out.append({"type": "record", "coll": cid, "rid": "", "op": "order", "fields": [], "title": None,
                            "before": ca, "after": cb, "id": f"record:{cid}:~order"})
    for gid, g in sch.groups.items():
        A, B = a.group(gid), b.group(gid)
        for f in g.fields:
            if A.get(f.name) != B.get(f.name) or ((f.name in A) != (f.name in B)):
                out.append({"type": "settings", "group": gid, "field": f.name, "before": A.get(f.name),
                            "after": B.get(f.name), "id": f"settings:{gid}:{f.name}"})
    return out


def put_back(draft, src, change):
    """one change (as diff() describes it, src being the state before it) undone in the draft, in memory"""
    if change["type"] == "settings":
        g = draft.schema.groups[change["group"]]
        obj = draft.group(g.id)
        old = src.group(g.id)
        if change["field"] in old:
            obj[change["field"]] = copy.deepcopy(old[change["field"]])
        else:
            obj.pop(change["field"], None)
        return
    cid, rid, op = change["coll"], change["rid"], change["op"]
    col = draft.schema.colls[cid]
    items = draft.items(cid)
    if op == "order":
        want = [x for x in src.ids(cid)]
        pos = {x: i for i, x in enumerate(want)}
        common = [r for r in items if r.get(col.key) in pos]
        common.sort(key=lambda r: pos[r.get(col.key)])
        it = iter(common)
        items[:] = [next(it) if r.get(col.key) in pos else r for r in items]
        return
    i, cur = draft.find(cid, rid)
    j, old = src.find(cid, rid)
    if old is None:                                   # it did not exist before: it goes
        if i is not None:
            del items[i]
        return
    if i is not None:
        items[i] = copy.deepcopy(old)
        return
    src_ids = src.ids(cid)                            # it was removed: back after the record that preceded it
    at = 0
    for k in range(src_ids.index(rid) - 1, -1, -1):
        p, _ = draft.find(cid, src_ids[k])
        if p is not None:
            at = p + 1
            break
    items.insert(at, copy.deepcopy(old))


# ── what a site does with its records (each called under the site's lock) ───────────────────────────────────────

def book(site, rev=None):
    return Book(site.records, site._reader(rev))


def public(site):
    """the declaration and every record, for the Content area"""
    sch = site.records
    b = book(site)
    head = None
    try:
        head = book(site, "HEAD")
    except Exception:
        head = None
    marks = {}
    if head is not None:
        for c in diff(head, b):
            if c["type"] == "record" and c["op"] in ("added", "changed"):
                marks[(c["coll"], c["rid"])] = c["op"]
            if c["type"] == "settings":
                marks.setdefault(("settings", c["group"]), []).append(c["field"])
    cols = []
    for cid, col in sch.colls.items():
        p = col.public()
        for fp, f in zip(p["fields"], col.fields):
            if f.type == "choice":
                fp["options"] = b.options(f)
        rows = []
        for r in b.items(cid):
            if not isinstance(r, dict):
                continue
            rid = r.get(col.key)
            vals = {f.name: r.get(f.name) for f in col.fields}
            for f in col.fields:
                if f.type == "image" and r.get(f.name):
                    vals[f.name] = {**_image_public(site, cid, f, r.get(f.name))}
            rows.append({"key": rid, "values": vals, "title": title_of(b, cid, rid, r), "mark": marks.get((cid, rid)),
                         "used": len(users_of(b, cid, rid))})
        p["items"] = rows
        cols.append(p)
    groups = []
    for gid, g in sch.groups.items():
        p = g.public()
        for fp, f in zip(p["fields"], g.fields):
            if f.type == "choice":
                fp["options"] = b.options(f)
        obj = b.group(gid)
        p["values"] = {f.name: obj.get(f.name) for f in g.fields}
        p["changed"] = marks.get(("settings", gid), [])
        groups.append(p)
    return {"collections": cols, "settings": groups}


def _image_public(site, cid, f, v):
    name = _image_name(f, v)
    out = dict(v) if isinstance(v, dict) else {"file": v}
    if name:
        out["url"] = f"/api/s/{site.sid}/rec-file/{cid}/{f.name}/{name}"
        out["name"] = name
    return out


def _write(site, b):
    for rel, text in b.changed_texts().items():
        p = os.path.join(site.work, rel)
        tmp = p + ".panel-tmp"
        with open(tmp, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, p)
    site.invalidate()


def _guarded(site, b, before):
    err = refused(b, before)
    if err:
        raise err


def add(site, cid, values, at=None):
    col = _coll(site, cid)
    if not col.can_add:
        raise FieldError("rec_fixed")
    b = book(site)
    before = problems(b)
    rec = build_record(col, values, b, None, site, None)
    for k, v in col.new.items():
        rec.setdefault(k, copy.deepcopy(v))
    rid = new_id(col, b, rec)
    rec[col.key] = rid
    items = b.items(cid)
    rec = _keys_like(rec, items[0] if items else None, col)
    _finalise_images(site, col, rec, rid)
    if at is None:
        at = 0 if col.new_at == "start" else len(items)
    items.insert(max(0, min(at, len(items))), rec)
    _guarded(site, b, before)
    _write(site, b)
    return rid, title_of(b, cid, rid, rec)


def edit(site, cid, rid, values):
    col = _coll(site, cid)
    b = book(site)
    before = problems(b)
    i, cur = b.find(cid, rid)
    if cur is None:
        raise FieldError("rec_not_found")
    rec = build_record(col, values, b, cur, site, rid, partial=True)
    _finalise_images(site, col, rec, rid)
    b.items(cid)[i] = rec
    _guarded(site, b, before)
    _write(site, b)
    return title_of(b, cid, rid, rec)


def duplicate(site, cid, rid, copy_word):
    col = _coll(site, cid)
    if not col.can_add:
        raise FieldError("rec_fixed")
    b = book(site)
    before = problems(b)
    i, cur = b.find(cid, rid)
    if cur is None:
        raise FieldError("rec_not_found")
    rec = copy.deepcopy(cur)
    t = col.by[col.title]
    if t.type == "text":
        v = rec.get(col.title)
        if isinstance(v, dict):
            rec[col.title] = {**v, **{L: f"{v.get(L, '')} ({copy_word.get(L, copy_word.get('en', 'copy'))})".strip()
                                      for L in b.schema.langs if v.get(L)}}
        elif isinstance(v, str):
            rec[col.title] = f"{v} ({copy_word.get('en', 'copy')})"
    for k in col.cfg.get("duplicate_drop", []):        # what belongs to the original only (the Excel row number)
        rec.pop(k, None)
    rec.pop(col.key, None)
    nid = new_id(col, b, rec)
    rec = {col.key: nid, **rec}
    rec = _keys_like(rec, cur, col)
    b.items(cid).insert(i + 1, rec)
    _guarded(site, b, before)
    _write(site, b)
    return nid, title_of(b, cid, nid, rec)


def delete(site, cid, rid):
    col = _coll(site, cid)
    if not col.can_delete:
        raise FieldError("rec_fixed")
    b = book(site)
    before = problems(b)
    i, cur = b.find(cid, rid)
    if cur is None:
        raise FieldError("rec_not_found")
    users = users_of(b, cid, rid)
    if users:
        raise FieldError("rec_in_use", title=title_of(b, cid, rid, cur), users=users[:12], count=len(users))
    t = title_of(b, cid, rid, cur)
    del b.items(cid)[i]
    _guarded(site, b, before)
    _write(site, b)
    return t


def reorder(site, cid, ids):
    col = _coll(site, cid)
    if col.order != "manual":
        raise FieldError("rec_not_ordered")
    b = book(site)
    items = b.items(cid)
    cur = [r.get(col.key) for r in items]
    if not isinstance(ids, list) or sorted(map(str, ids)) != sorted(map(str, cur)) or len(set(ids)) != len(ids):
        raise FieldError("rec_bad_order")
    pos = {x: i for i, x in enumerate(ids)}
    items.sort(key=lambda r: pos[r.get(col.key)])
    _write(site, b)


def set_settings(site, gid, values):
    g = site.records.groups.get(gid)
    if not g:
        raise FieldError("rec_not_found")
    b = book(site)
    before = problems(b)
    obj = b.group(gid)
    if not isinstance(values, dict):
        raise FieldError("bad_json")
    unknown = [k for k in values if k not in g.by]
    if unknown:
        raise FieldError("rec_unknown_field", field=unknown[0][:40])
    errors = []
    for name, v in values.items():
        f = g.by[name]
        try:
            _apply(f, obj, clean(f, v, b, obj.get(name), site, None))
        except _Bad as e:
            errors.append({"field": name, "code": e.code, **e.d})
    if errors:
        raise FieldError("invalid", errors=errors)
    _guarded(site, b, before)
    _write(site, b)


def undo_changes(site, picks, rev):
    """put each picked record/settings change back as it was at `rev`, all or nothing"""
    if not picks:
        return
    b = book(site)
    src = book(site, rev)
    before = problems(b)
    for c in picks:
        put_back(b, src, c)
    err = refused(b, before)
    if err:
        raise FieldError("rec_undo_conflict", errors=err.details["errors"])
    _write(site, b)


def _coll(site, cid):
    col = site.records.colls.get(cid)
    if not col:
        raise FieldError("rec_not_found")
    return col


# ── pictures ─────────────────────────────────────────────────────────────────────────────────────────────────────

def _image_name(f, v):
    """the stored value → the bare file name inside the field's folder (None when it is not one)"""
    p = v.get("file") if isinstance(v, dict) else v
    if not isinstance(p, str):
        return None
    if f.prefix and p.startswith(f.prefix):
        p = p[len(f.prefix):]
    return p if NAME_RX.match(p) and ".." not in p else None


def _image_value(f, value, current, site, rid):
    if value is None or value == "":
        if f.required:
            raise _bad("rec_required")
        return _empty(f, None)
    if not isinstance(value, dict):
        raise _bad("rec_bad_image")
    out = {}
    if value.get("upload"):
        uid = str(value["upload"])
        if not re.fullmatch(r"[0-9a-f]{24}", uid):
            raise _bad("rec_upload_gone")
        meta = _staged(site, uid)
        if meta is None or meta.get("field") != f.name:
            raise _bad("rec_upload_gone")
        out["__upload"] = uid
    else:                                             # keeping the picture it has: only the record's own file
        stored = current.get("file") if isinstance(current, dict) else current
        if not stored or not _image_name(f, current) or value.get("file") not in (stored, _image_name(f, current)):
            raise _bad("rec_bad_image")
        if f.store == "path":
            return current
        out = {k: v for k, v in current.items()} if isinstance(current, dict) else {"file": current}
    if f.store == "path":
        return out
    if f.cfg.get("source"):
        src = _text(value.get("source"), False, 500)
        if src and not URL_RX.match(src):
            raise _bad("rec_bad_url", part="source")
        if not src and f.cfg.get("source") == "required":
            raise _bad("rec_required", part="source")
        if src:
            out["source"] = src
        else:
            out.pop("source", None)
    if f.cfg.get("alt"):
        alt = value.get("alt") or {}
        if not isinstance(alt, dict):
            raise _bad("rec_not_text", part="alt")
        langs = site.records.langs
        a = {L: _text(alt.get(L), False, 300) for L in langs}
        if any(a.values()) and not all(a.values()):
            raise _bad("rec_both", part="alt", lang=next(L for L in langs if not a[L]))
        if f.cfg.get("alt") == "required" and not any(a.values()):
            raise _bad("rec_required", part="alt")
        if any(a.values()):
            out["alt"] = a
        else:
            out.pop("alt", None)
    return out


def _finalise_images(site, col, rec, rid):
    """an upload named in the record → its file in the field's folder, under a generated name; the record points at it"""
    for f in col.fields:
        v = rec.get(f.name)
        uid = v.pop("__upload", None) if isinstance(v, dict) else None
        if not uid:
            continue
        meta = _staged(site, uid)
        if meta is None:
            raise FieldError("invalid", errors=[{"field": f.name, "code": "rec_upload_gone"}])
        data = open(os.path.join(site.uploads, f"rec-{uid}.{meta['ext']}"), "rb").read()
        sha = hashlib.sha256(data).hexdigest()
        name = f"{_slug(rid or 'new')[:30] or 'file'}-{sha[:10]}.{meta['ext']}"
        folder = _folder(site, f)
        os.makedirs(folder, exist_ok=True)
        dest = os.path.join(folder, name)
        if not os.path.exists(dest):
            tmp = dest + ".panel-tmp"
            open(tmp, "wb").write(data)
            os.replace(tmp, dest)
        stored = f.prefix + name
        if f.store == "path":
            rec[f.name] = stored
            continue
        obj = {"file": stored}
        for k, val in v.items():
            if k not in ("file", "sha256"):
                obj[k] = val
        if f.cfg.get("sha256", True):
            obj["sha256"] = sha
        order = f.cfg.get("keys") or ["file", "source", "alt", "sha256"]
        rec[f.name] = {k: obj[k] for k in order if k in obj} | {k: obj[k] for k in obj if k not in order}


def _folder(site, f):
    root = os.path.realpath(site.work)
    p = os.path.realpath(os.path.join(root, f.folder))
    if not p.startswith(root + os.sep):
        raise FieldError("rec_bad_folder")
    return p


def _staged(site, uid):
    p = os.path.join(site.uploads, f"rec-{uid}.json")
    if not os.path.exists(p):
        return None
    meta = json.load(open(p))
    if time.time() - meta.get("at", 0) > 24 * 3600:
        return None
    return meta


def file_path(site, cid, fname, name):
    """a record picture the panel may show: only a plain name, inside the field's own folder, a regular file"""
    col = site.records.colls.get(cid)
    f = col.by.get(fname) if col else None
    if not f or f.type != "image" or not NAME_RX.match(name or "") or ".." in name:
        return None
    folder = _folder(site, f)
    p = os.path.join(folder, name)
    if os.path.islink(p) or not os.path.isfile(p) or os.path.dirname(os.path.realpath(p)) != folder:
        return None
    return p


def staged_path(site, uid):
    if not re.fullmatch(r"[0-9a-f]{24}", uid or ""):
        return None, None
    meta = _staged(site, uid)
    if not meta:
        return None, None
    return os.path.join(site.uploads, f"rec-{uid}.{meta['ext']}"), meta


def sniff(data):
    """what a file is, by its first bytes — never by its name"""
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    head = data[:2048].lstrip(b"\xef\xbb\xbf \t\r\n").lower()
    if head.startswith(b"<?xml") or head.startswith(b"<svg") or (head.startswith(b"<!--") and b"<svg" in data[:8192].lower()):
        return "svg"
    return None


def receive(site, cid, fname, data, filename=""):
    """a file sent for a record's picture → staged, checked, cleaned; returns its description"""
    col = site.records.colls.get(cid)
    f = col.by.get(fname) if col else None
    if not f or f.type != "image":
        raise FieldError("rec_not_found")
    limit = min(UPLOAD_MAX, int(f.cfg.get("max_kb", 2048)) * 1024)
    if len(data) > limit:
        raise FieldError("rec_img_big", kb=limit // 1024)
    kind = sniff(data)
    if kind is None:
        raise FieldError("rec_img_type", accept=f.accept)
    if kind not in f.accept:
        raise FieldError("rec_img_svg_here" if kind == "svg" else "rec_img_type", accept=f.accept, got=kind)
    w = h = None
    if kind == "svg":
        data = sanitise_svg(data)
    else:
        data, w, h = _raster(data, kind, f)
    uid = secrets.token_hex(12)
    os.makedirs(site.uploads, exist_ok=True)
    open(os.path.join(site.uploads, f"rec-{uid}.{kind}"), "wb").write(data)
    meta = {"id": uid, "ext": kind, "w": w, "h": h, "bytes": len(data), "field": f.name, "collection": cid,
            "sha256": hashlib.sha256(data).hexdigest(), "name": os.path.basename(filename or "")[:120], "at": int(time.time())}
    json.dump(meta, open(os.path.join(site.uploads, f"rec-{uid}.json"), "w"))
    return meta


def _raster(data, kind, f):
    from PIL import Image, ImageOps
    fmt = {"png": "PNG", "jpg": "JPEG", "webp": "WEBP"}[kind]
    try:
        with Image.open(io.BytesIO(data)) as probe:
            if probe.format != fmt:
                raise FieldError("rec_img_type", accept=f.accept)
            if probe.width * probe.height > 40_000_000 or max(probe.size) > 12000:
                raise FieldError("rec_img_huge")
            probe.verify()
        im = Image.open(io.BytesIO(data))
        if getattr(im, "n_frames", 1) > 1:
            raise FieldError("rec_img_animated")
        im.load()
    except FieldError:
        raise
    except Exception:
        raise FieldError("rec_img_broken")
    small = int(f.cfg.get("min_px", 32))
    if min(im.size) < small:
        raise FieldError("rec_img_small", px=small)
    if f.cfg.get("keep_original"):                    # an official file kept byte for byte (it was decoded whole above)
        return data, im.width, im.height
    im = ImageOps.exif_transpose(im)
    mx = int(f.cfg.get("max_px", 2400))
    if max(im.size) > mx:
        im.thumbnail((mx, mx), Image.LANCZOS)
    alpha = im.mode in ("RGBA", "LA", "PA") or (im.mode == "P" and "transparency" in im.info)
    im = im.convert("RGBA" if alpha else "RGB")
    out = io.BytesIO()
    icc = im.info.get("icc_profile")
    extra = {"icc_profile": icc} if icc else {}
    if kind == "png":
        im.save(out, "PNG", optimize=True, **extra)
    elif kind == "jpg":
        im.convert("RGB").save(out, "JPEG", quality=90, optimize=True, **extra)
    else:
        im.save(out, "WEBP", quality=90, method=6, **extra)
    return out.getvalue(), im.width, im.height


# ── SVG: an allow-list, or a refusal that says why ───────────────────────────────────────────────────────────────

SVG_NS = "http://www.w3.org/2000/svg"
XLINK_NS = "http://www.w3.org/1999/xlink"
SVG_ELEMENTS = {"svg", "g", "path", "rect", "circle", "ellipse", "line", "polyline", "polygon", "defs", "linearGradient",
                "radialGradient", "stop", "clipPath", "mask", "title", "desc", "use", "symbol", "text", "tspan", "pattern",
                "style", "filter", "feGaussianBlur", "feOffset", "feBlend", "feColorMatrix", "feFlood", "feComposite",
                "feMerge", "feMergeNode", "feMorphology", "marker"}
SVG_DROP = {"metadata"}                               # harmless, and stripped
SVG_ACTIVE = {"script", "foreignObject", "iframe", "embed", "object", "audio", "video", "image", "a", "animate",
              "animateTransform", "animateMotion", "set", "handler", "listener", "feImage", "discard"}
SVG_ATTRS = {"id", "class", "style", "d", "x", "y", "x1", "y1", "x2", "y2", "cx", "cy", "r", "rx", "ry", "fx", "fy",
             "width", "height", "viewBox", "preserveAspectRatio", "transform", "points", "fill", "fill-opacity",
             "fill-rule", "stroke", "stroke-width", "stroke-opacity", "stroke-linecap", "stroke-linejoin",
             "stroke-miterlimit", "stroke-dasharray", "stroke-dashoffset", "opacity", "clip-path", "clip-rule", "mask",
             "offset", "stop-color", "stop-opacity", "gradientUnits", "gradientTransform", "spreadMethod",
             "patternUnits", "patternTransform", "patternContentUnits", "clipPathUnits", "maskUnits",
             "maskContentUnits", "font-family", "font-size", "font-weight", "font-style", "letter-spacing",
             "text-anchor", "dominant-baseline", "dx", "dy", "version", "baseProfile", "color", "display",
             "visibility", "overflow", "filter", "stdDeviation", "in", "in2", "result", "mode", "values", "type",
             "operator", "k1", "k2", "k3", "k4", "flood-color", "flood-opacity", "radius", "markerWidth",
             "markerHeight", "refX", "refY", "orient", "markerUnits", "href", "xml:space", "lang", "direction",
             "unicode-bidi", "mix-blend-mode", "isolation", "paint-order", "vector-effect", "shape-rendering",
             "text-rendering", "image-rendering", "color-interpolation-filters", "filterUnits", "primitiveUnits",
             "data-name", "enable-background", "xml:lang"}
_CSS_BAD = re.compile(r"@import|expression\s*\(|javascript:|behavior\s*:|-moz-binding|url\s*\(\s*(?!['\"]?#)", re.I)


def sanitise_svg(data):
    """an SVG that may be shown → its bytes (cleaned only of editors' metadata); one that could act → refused"""
    low = data.lower()
    if b"<!doctype" in low or b"<!entity" in low:
        raise FieldError("rec_svg_external", what="DOCTYPE")
    if b"<?xml-stylesheet" in low:
        raise FieldError("rec_svg_external", what="xml-stylesheet")
    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        raise FieldError("rec_img_broken")
    if root.tag != f"{{{SVG_NS}}}svg":
        raise FieldError("rec_img_broken")
    changed = False

    def walk(el):
        nonlocal changed
        for child in list(el):
            if not isinstance(child.tag, str):          # a comment or a processing instruction
                el.remove(child)
                changed = True
                continue
            ns, _, local = child.tag[1:].partition("}") if child.tag.startswith("{") else ("", "", child.tag)
            if local in SVG_ACTIVE and ns in (SVG_NS, ""):
                raise FieldError({"script": "rec_svg_script", "foreignObject": "rec_svg_foreign"}.get(local, "rec_svg_active"), what=local)
            if ns != SVG_NS or local in SVG_DROP:
                if ns in (SVG_NS, "") and local not in SVG_DROP:
                    raise FieldError("rec_svg_unknown", what=local[:40])
                if any(True for d in child.iter() if isinstance(d.tag, str) and d.tag.split("}")[-1] in ("script", "foreignObject")):
                    raise FieldError("rec_svg_script", what="script")
                el.remove(child)
                changed = True
                continue
            if local not in SVG_ELEMENTS:
                raise FieldError("rec_svg_unknown", what=local[:40])
            attrs(child)
            if local == "style" and _CSS_BAD.search(child.text or ""):
                raise FieldError("rec_svg_external", what="style")
            walk(child)

    def attrs(el):
        nonlocal changed
        for k in list(el.attrib):
            v = el.attrib[k]
            ns, _, local = k[1:].partition("}") if k.startswith("{") else ("", "", k)
            if local.lower().startswith("on"):
                raise FieldError("rec_svg_script", what=local[:40])
            vv = re.sub(r"[\s\x00-\x1f]", "", v).lower()
            if "javascript:" in vv or "vbscript:" in vv or vv.startswith("data:"):
                raise FieldError("rec_svg_script", what=local[:40])
            if local == "href":
                if ns not in ("", XLINK_NS) or not v.strip().startswith("#"):
                    raise FieldError("rec_svg_external", what="href")
                continue
            if local == "style" and _CSS_BAD.search(v):
                raise FieldError("rec_svg_external", what="style")
            if any(m.group(1) != "#" for m in re.finditer(r"url\(['\"]?(.?)", vv)):
                raise FieldError("rec_svg_external", what=local[:40])
            name = local if ns == "" else ("xml:" + local if ns == "http://www.w3.org/XML/1998/namespace" else None)
            if name is None or name not in SVG_ATTRS:
                del el.attrib[k]
                changed = True

    attrs(root)
    walk(root)
    if not changed:
        return data
    ET.register_namespace("", SVG_NS)
    ET.register_namespace("xlink", XLINK_NS)
    return b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="utf-8", xml_declaration=False)


def sweep(site):
    """pictures uploaded into a records folder that no record names and that were never published: removed"""
    from . import gitw
    if not site.records:
        return
    b = book(site)
    named = set()
    for cid, col in site.records.colls.items():
        for f in col.fields:
            if f.type == "image":
                for r in b.items(cid):
                    n = _image_name(f, r.get(f.name)) if isinstance(r, dict) else None
                    if n:
                        named.add(os.path.join(f.folder, n))
    tracked = set(gitw.git(site.work, "ls-files", "--", *site.records.folders()).splitlines()) if site.records.folders() else set()
    for folder in site.records.folders():
        full = os.path.join(site.work, folder)
        if not os.path.isdir(full):
            continue
        for n in os.listdir(full):
            rel = os.path.join(folder, n)
            if rel not in named and rel not in tracked and os.path.isfile(os.path.join(full, n)):
                os.remove(os.path.join(full, n))
