"""inbrowser — the panel's own server code, run in the visitor's browser (Pyodide) for the static demo of a site with
records (static.py --client alsadq).

The same modules the server runs do the work: content.py and jsonspan.py for words, records.py for the lists and their
refusals, sites.Site for drafts, the review, History, undo and restore; only git is swapped for memgit (shipped as
gitw.py in the bundle) and subprocesses for an in-process call of the site's own tools/build.py. What cannot run here
is said, never faked: publishing runs the site's build, the records' integrity rules and the site's instant rules
(its panel.json hints); the site's full checks drive a browser and run only on the real dashboard.

Entry points, called from ui/engine-worker.js: boot(), api(), upload(), build_preview(), publish(), parity().
"""
import json
import os
import re
import shutil
import sys
import time
import types

# the demo has no logins: the sign-in page is a door sign (ui/static-api.js), and no password code is shipped
sys.modules.setdefault("server.auth", types.ModuleType("server.auth"))
sys.modules["server.auth"].ABSOLUTE = 0

from . import app as A  # noqa: E402
from . import builds, gitw, records, sites  # noqa: E402
from .content import FieldError  # noqa: E402
from .images import ImageError  # noqa: E402
from .social import LinkError  # noqa: E402

SITE = None
FOLDER = ""
USER = {"name": "", "email": "", "lang": "ar"}
_BUILD = None


def _site_build():
    """the site's own tools/build.py, imported once from the working copy (where its SITE constant points)"""
    global _BUILD
    if _BUILD is None:
        sys.path.insert(0, os.path.join(SITE.work, "tools"))
        import build as b  # noqa: E402 — the site's module, not the panel's
        _BUILD = b
    return _BUILD


def run_build(src, out, base, origin):
    """one build, in process: (ok, root or the build's own reason)"""
    try:
        root = _site_build().build(base, out, site=src, origin=origin, quiet=True)
        return True, root
    except SystemExit as e:                       # build.py's die(): a sentence that names the problem
        return False, str(e.code if e.code is not None else "the build stopped")
    except Exception as e:                        # a defect in the build itself: said, not hidden
        return False, f"{type(e).__name__}: {e}"


class Reg:
    def __init__(self, data):
        self.data = data
        self.builds = {}
        self.base_dir = data
        self.reg = {}
        self.clients = {}


class BrowserSite(sites.Site):
    """sites.Site with the build run in process and nothing on a timer (the page asks for a preview when it needs one)"""

    def ensure(self):
        if not gitw.has(self.work):
            gitw.init(self.work, "Starting point")

    def schedule_preview(self, delay=0):
        self._dirty = True

    def preview_now(self, wait=0):
        return self.preview()

    def preview(self):
        content = self.content()
        values = {f"{k}|{L}": content.fields[k].values.get(L) for k in content.order for L in self.langs}
        rec_hash = self._records_hash()
        cur = self.preview_meta()
        if cur and cur.get("values") == values and cur.get("records") == rec_hash:
            return cur
        bid = "p" + str(int(time.time() * 1000))[-9:] + str(len(os.listdir(self.builds_dir)) if os.path.isdir(self.builds_dir) else 0)
        dest = os.path.join(self.builds_dir, bid)
        src = os.path.join(dest, "src")
        shutil.copytree(self.work, src, ignore=shutil.ignore_patterns(".git", "__pycache__", "dist*", ".check"))
        base = f"/{FOLDER}/pv/{bid}/"
        t0 = time.time()
        ids = builds.mark(src, content)
        ok, root = run_build(src, os.path.join(dest, "out"), base, "")
        marked = ok
        if not ok:                                # as on the server: a marked build that fails falls back to the plain one
            shutil.rmtree(src)
            shutil.copytree(self.work, src, ignore=shutil.ignore_patterns(".git", "__pycache__", "dist*", ".check"))
            ids = []
            ok, root = run_build(src, os.path.join(dest, "out"), base, "")
        pv = {"id": bid, "at": time.time(), "ok": ok, "marked": marked, "seconds": round(time.time() - t0, 2),
              "error": None if ok else root, "ids": ids, "values": values, "images": {}, "records": rec_hash, "base": base}
        if ok:
            pv["pages"] = builds.pages(root, self.manifest)
            pv["root"] = root
            old = (self.state.get("preview") or {}).get("id")
            self.state["preview"] = {"id": bid, "at": pv["at"]}
            self.state.pop("preview_error", None)
            for d in os.listdir(self.builds_dir):                    # one build kept, the one shown
                if d not in (bid, old) and d != "seed":
                    shutil.rmtree(os.path.join(self.builds_dir, d), ignore_errors=True)
        else:
            self.state["preview_error"] = {"at": pv["at"], "error": pv["error"]}
            shutil.rmtree(src, ignore_errors=True)
        json.dump(pv, open(os.path.join(dest, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False)
        self.save_state()
        self._dirty = False
        return pv

    def preview_meta(self):
        pv = self.state.get("preview")
        if not pv:
            return None
        p = os.path.join(self.builds_dir, pv["id"], "meta.json")
        return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def preview_public(site):
    pv = site.preview_meta()
    if not pv:
        return {"ready": False, "building": False, "error": (site.state.get("preview_error") or {}).get("error")}
    err = site.state.get("preview_error") or {}
    return {"ready": True, "id": pv["id"], "base": pv["base"], "fresh": site.preview_fresh(), "building": False,
            "marked": pv["marked"], "ids": pv["ids"], "values": pv["values"], "images": {},
            "error": err.get("error") if err.get("at", 0) > pv.get("at", 0) else None,
            "pages": [{k: p[k] for k in ("id", "lang", "path", "title", "ids")} for p in pv.get("pages", [])],
            "seconds": pv.get("seconds")}


class _Panel:
    """what app.state() asks of the panel object"""
    preview_host = ""

    def origin(self, host):
        return ""

    class reg:
        clients = {}


def state():
    st = A.state(_PANEL, SITE, USER)
    st["preview"] = preview_public(SITE)
    st["site"]["live_url"] = ""
    st["site"]["records"] = bool(SITE.records)
    return st


_PANEL = _Panel()


# ── boot ─────────────────────────────────────────────────────────────────────────────────────────────────────────

def boot(work, folder, client, user, seed_meta=None):
    """the working copy at `work` (unpacked by the worker) becomes the site; seed_meta is the prepared preview's meta"""
    global SITE, FOLDER
    FOLDER = folder
    USER.update(json.loads(user))
    data = work
    for _ in range(4):                                                # <data>/sites/<client>/site/work
        data = os.path.dirname(data)
    reg = Reg(data)
    reg.clients = {client: {"name": {}, "sites": {"site": {}}, "shared": []}}
    _Panel.reg.clients = reg.clients
    SITE = BrowserSite(reg, client, "site", {"source": {}, "deploy": {"kind": "demo"}})
    if seed_meta:                                                     # the preview static.py prepared, until the first rebuild
        meta = json.loads(seed_meta)
        d = os.path.join(SITE.builds_dir, "seed")
        os.makedirs(d, exist_ok=True)
        json.dump(meta, open(os.path.join(d, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False)
        SITE.state["preview"] = {"id": "seed", "at": meta.get("at", 0)}
    return json.dumps({"ok": True, "fields": len(SITE.content().order)})


# ── the API, as app.py routes it for one site ────────────────────────────────────────────────────────────────────

def _ok(body, status=200):
    return json.dumps({"status": status, "body": body}, ensure_ascii=False)


def _err(status, error, **d):
    return json.dumps({"status": status, "body": {"error": error, **d}}, ensure_ascii=False)


def api(method, sub, body_json):
    try:
        return _route(method, sub, json.loads(body_json or "{}") if body_json else {})
    except FieldError as e:
        code = 409 if e.code in ("rec_in_use", "rec_undo_conflict") else 404 if e.code == "rec_not_found" else 400
        return _err(code, e.code, **e.details)
    except ImageError as e:
        return _err(400, "image_" + e.code, **e.details)
    except LinkError as e:
        return _err(400, "link_" + e.code, **e.details)
    except sites.Busy as e:
        return _err(409, "busy", what=str(e))


def _route(method, sub, b):
    s, user = SITE, USER
    ID = r"[a-z0-9][a-z0-9_-]{0,47}"
    if sub == "/state":
        return _ok(state())
    if sub == "/text" and method == "PUT":
        edits = [(e["key"], e["lang"], e["value"]) for e in (b.get("edits") or [])][:50]
        if not edits:
            raise FieldError("nothing")
        done = s.set_text(edits, user)
        return _ok({"saved": [{"key": k, "lang": L, "value": v} for k, L, v in done], "also": [], "changes": len(s.diff())})
    if sub == "/labels":
        c = s.content()
        for k, v in list((b.get("labels") or {}).items())[:2000]:
            if k in c.fields and isinstance(v, dict):
                s.state["labels"][k] = {kk: str(v.get(kk, ""))[:80] for kk in ("role", "section", "page")}
        return _ok({"ok": True})
    if sub == "/changes":
        return _ok({"changes": A.changes_public(s)})
    if sub == "/revert" and method == "POST":
        n = s.revert(b.get("ids"))
        return _ok({"reverted": n, "changes": len(s.diff())})
    if sub == "/preview":
        return _ok(preview_public(s))
    if sub == "/history":
        return _ok({"versions": A.history_public(s)})
    if b.get("version") == "start":                    # the prepared History's starting point: the engine's first version
        b["version"] = gitw.log(s.work, 10000)[-1]["id"]
    if sub == "/undo" and method == "POST":
        c = s.undo(str(b.get("version", "")), str(b.get("change", "")))
        return _ok({"undone": c["id"], "changes": len(s.diff())})
    if sub == "/restore" and method == "POST":
        return _ok({"changes": s.restore(str(b.get("version", "")))})
    if sub == "/records" and method == "GET":
        return _ok(records.public(s))
    m = re.fullmatch(rf"/records/({ID})", sub)
    if m and method == "POST":
        at = b.get("at") if isinstance(b.get("at"), int) else None
        rid, title = s.record_op("add", user, m.group(1), b.get("values") or {}, at)
        return _ok({"id": rid, "title": title, "changes": len(s.diff())})
    m = re.fullmatch(rf"/records/({ID})/({ID})", sub)
    if m and method == "PUT":
        title = s.record_op("edit", user, m.group(1), m.group(2), b.get("values") or {})
        return _ok({"id": m.group(2), "title": title, "changes": len(s.diff())})
    if m and method == "DELETE":
        title = s.record_op("delete", user, m.group(1), m.group(2))
        return _ok({"removed": m.group(2), "title": title, "changes": len(s.diff())})
    m = re.fullmatch(rf"/records/({ID})/({ID})/duplicate", sub)
    if m and method == "POST":
        rid, title = s.record_op("duplicate", user, m.group(1), m.group(2), {"en": "copy", "ar": "نسخة"})
        return _ok({"id": rid, "title": title, "changes": len(s.diff())})
    m = re.fullmatch(rf"/order/({ID})", sub)
    if m and method == "PUT":
        s.record_op("reorder", user, m.group(1), b.get("ids"))
        return _ok({"ok": True, "changes": len(s.diff())})
    m = re.fullmatch(rf"/settings/({ID})", sub)
    if m and method == "PUT":
        s.record_op("settings", user, m.group(1), b.get("values") or {})
        return _ok({"ok": True, "changes": len(s.diff())})
    return _err(404, "not_found")


def upload(cid, field, data, name):
    """a record's picture, received exactly as the server receives it (records.receive: bytes, decoding, SVG allow-list)"""
    try:
        if len(data) > records.UPLOAD_MAX:
            return _err(413, "too_large")
        meta = records.receive(SITE, cid, field, data.to_bytes() if hasattr(data, "to_bytes") else bytes(data), name)
        return _ok(meta)
    except FieldError as e:
        return _err(404 if e.code == "rec_not_found" else 400, e.code, **e.details)


def staged(uid):
    """the staged upload's bytes and type, for the page to show (served by the demo's service worker)"""
    path, meta = records.staged_path(SITE, uid)
    return (open(path, "rb").read(), meta["ext"]) if path else (None, None)


def record_files():
    """every picture inside a records folder now: (url path under the demo, file path)"""
    out = []
    for cid, col in SITE.records.colls.items():
        for f in col.fields:
            if f.type != "image":
                continue
            folder = os.path.join(SITE.work, f.folder)
            for n in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
                if records.NAME_RX.match(n):
                    out.append((f"rf/site/{cid}/{f.name}/{n}", os.path.join(folder, n)))
    return out


def build_preview():
    """a marked build of the draft, if the draft moved since the last one: (meta json, root or '')"""
    pv = SITE.preview()
    return json.dumps({k: v for k, v in pv.items() if k != "root"}, ensure_ascii=False), pv.get("root", "") if pv.get("ok") else ""


# ── publishing, honestly ─────────────────────────────────────────────────────────────────────────────────────────

def _instant_rules(changes):
    """the site's rules that can be known from the words alone (its panel.json hints), as the static demo applies them"""
    out = []
    c = SITE.content()
    for ch in changes:
        if ch["type"] != "text":
            continue
        v = ch.get("after") or ""
        if not v.strip() and (ch.get("before") or "").strip():
            out.append({"check": {"en": "The site's instant rules", "ar": "قواعد الموقع الفورية"}, "rule": "empty", "line": f"empty: {ch['key']} [{ch['lang']}]",
                        "field": ch["key"], "lang": ch["lang"],
                        "message": {"en": "This text is empty. Every text needs words in both languages.", "ar": "هذا النص فارغ، ولكل نص كلمات باللغتين."}})
            continue
        for h in SITE.manifest.get("hints", []):
            if h.get("level") != "bad" or (h.get("lang") and h["lang"] != ch["lang"]):
                continue
            mt = re.search(h["pattern"], v, re.I)
            if mt:
                out.append({"check": {"en": "The site's instant rules", "ar": "قواعد الموقع الفورية"}, "rule": "hint",
                            "line": f"{ch['key']} [{ch['lang']}]: «{mt.group(0)}»", "field": ch["key"] if ch["key"] in c.fields else None,
                            "lang": ch["lang"], "message": {k: t.replace("{m}", mt.group(0)) for k, t in h["text"].items()}})
    return out


def publish(step, live_base, origin):
    """build → the records' integrity and the site's instant rules → keep the built site → record a version"""
    s = SITE
    changes = s.diff()
    if not changes:
        return json.dumps({"state": "failed", "result": {"code": "nothing"}})
    step("build")
    dest = os.path.join(s.root, "publish")
    shutil.rmtree(dest, ignore_errors=True)
    src = os.path.join(dest, "src")
    shutil.copytree(s.work, src, ignore=shutil.ignore_patterns(".git", "__pycache__", "dist*", ".check"))
    ok, root = run_build(src, os.path.join(dest, "out"), live_base, origin)
    if not ok:
        return json.dumps({"state": "failed", "result": {"code": "build", "error": root}, "log": [root]}, ensure_ascii=False)
    step("checks")
    failures = []
    for where, rid, field, code, value in sorted(records.problems(s.book()), key=str):
        failures.append({"check": {"en": "Your lists", "ar": "قوائمك"}, "rule": code, "line": f"{where} {rid} {field}: {code} {value}",
                         "field": None, "lang": None, "message": None})
    failures += _instant_rules(changes)
    if failures:
        return json.dumps({"state": "failed", "result": {"code": "checks", "failures": failures}}, ensure_ascii=False)
    step("deploy")
    step("record")
    managed = set(s.managed_paths())
    paths = [p for p in gitw.changed(s.work) if s.is_managed(p, managed)]
    n = len(changes)
    body = "\n".join(sites._line(c, s) for c in changes[:40])
    rev = gitw.commit(s.work, f"Published {n} change{'s' if n != 1 else ''}\n\n{body}\n\nPanel-Live: demo", USER["name"], USER["email"], paths)
    for c in changes:
        s.state["draft_by"].pop(c["id"], None)
    s.state["live"] = {"version": rev, "at": int(time.time()), "by": USER["name"], "url": ""}
    s.save_state()
    s.invalidate()
    return json.dumps({"state": "done", "result": {"version": rev, "url": None, "changes": n}, "root": root})


def parity(base, origin):
    """the draft built plainly with this base and origin: every HTML page, for the parity test against the native build"""
    dest = os.path.join(SITE.root, "parity")
    shutil.rmtree(dest, ignore_errors=True)
    src = os.path.join(dest, "src")
    shutil.copytree(SITE.work, src, ignore=shutil.ignore_patterns(".git", "__pycache__", "dist*", ".check"))
    ok, root = run_build(src, os.path.join(dest, "out"), base, origin)
    if not ok:
        return json.dumps({"ok": False, "error": root})
    pages = {}
    for dp, _, fs in os.walk(root):
        for f in fs:
            if f.endswith(".html"):
                p = os.path.join(dp, f)
                pages[os.path.relpath(p, root)] = open(p, encoding="utf-8").read()
    return json.dumps({"ok": True, "pages": pages}, ensure_ascii=False)
