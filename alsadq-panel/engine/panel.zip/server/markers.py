"""markers — invisible ids woven into a preview build, so a click on the page finds the text it came from.

The panel never asks a site's templates to say where a word came from. Instead, for a preview, every editable string
is built with an invisible id at its start and at its end, written in Unicode tag characters (U+E0020–U+E007E). They
are default-ignorable: no width, no glyph, transparent to Arabic joining, never in a font subset. The bridge script in
the preview reads them, tags the elements that hold them, and strips them before the page's own scripts run.
The published build never carries them: it is built from the unmarked content.

    START(n) = TAG '[' + n in base 36 (tag digits and letters) + TAG ']'
    END(n)   = TAG '{' + n in base 36                           + TAG '}'
"""
import re

T = 0xE0000
OPEN_S, CLOSE_S, OPEN_E, CLOSE_E = chr(T + ord("[")), chr(T + ord("]")), chr(T + ord("{")), chr(T + ord("}"))
DIGITS = "0123456789abcdefghijklmnopqrstuvwxyz"
_TAG_DIGITS = "".join(chr(T + ord(c)) for c in DIGITS)


def _b36(n):
    s = ""
    while True:
        n, r = divmod(n, 36)
        s = DIGITS[r] + s
        if not n:
            return s


def _tag(s):
    return "".join(chr(T + ord(c)) for c in s)


def wrap(s, n):
    """the string with its id at both ends; an empty string stays empty (the site's own default must still apply)"""
    if not s:
        return s
    i = _tag(_b36(n))
    return f"{OPEN_S}{i}{CLOSE_S}{s}{OPEN_E}{i}{CLOSE_E}"


_D = f"[{re.escape(_TAG_DIGITS)}]+"
START = re.compile(re.escape(OPEN_S) + f"({_D})" + re.escape(CLOSE_S))
END = re.compile(re.escape(OPEN_E) + f"({_D})" + re.escape(CLOSE_E))
ANY = re.compile(f"(?:{START.pattern}|{END.pattern})")
TAGCHARS = re.compile("[\U000E0020-\U000E007E]")


def num(tagged):
    return int("".join(chr(ord(c) - T) for c in tagged), 36)


def strip(s):
    return TAGCHARS.sub("", s)


def found(s):
    """every id whose start marker appears in s"""
    return [num(m.group(1)) for m in START.finditer(s)]
