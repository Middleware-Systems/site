"""app — the panel's HTTP server: the interface, its API, the previews and (locally) the published sites.

One process answers on one port for three kinds of address, told apart by the Host header:

  the panel      localhost:8800             the interface and /api — the only address with a session cookie
  previews       preview.localhost:8800     /b/<build>/… — a draft build, its address the only key, on its own origin
                                            so nothing a site's own scripts do can reach the panel's session
  live sites     <site>.<client>.localhost  the folder a "folder" deploy publishes to (a stand-in for real hosting)

Isolation is structural: a request names a site only by its short id, and that id is looked up inside the client the
session belongs to. Another client's site is not refused; it does not exist from where the request stands (404).
"""
import email.utils
import json
import mimetypes
import os
import re
import secrets
import sys
import threading
import time
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import auth, images, records, social
from .content import FieldError
from .images import ImageError
from .sites import Busy, Registry
from .social import LinkError

HERE = os.path.dirname(os.path.abspath(__file__))
UI = os.path.join(os.path.dirname(HERE), "ui")
JSON_MAX = 1_000_000
mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("image/webp", ".webp")
mimetypes.add_type("image/avif", ".avif")


class Job:
    STEPS = ("build", "checks", "deploy", "record")

    def __init__(self, cid, sid, kind):
        self.id = secrets.token_urlsafe(12)
        self.cid, self.sid, self.kind = cid, sid, kind
        self.state = "running"
        self.steps = []
        self.result = {}
        self.progress = None                     # {"done", "total", "what"} while a long check says how far it is
        self.started = time.time()

    def step(self, name):
        if self.steps:
            self.steps[-1]["done"] = time.time()
        self.steps.append({"name": name, "at": time.time()})

    def fail(self, code, **details):
        self.state = "failed"
        self.result = {"code": code, **details}
        return self

    def done(self, **details):
        if self.steps:
            self.steps[-1]["done"] = time.time()
        self.state = "done"
        self.result = details
        return self

    def public(self):
        r = dict(self.result)
        r.pop("log", None)
        return {"id": self.id, "kind": self.kind, "state": self.state, "steps": [s["name"] for s in self.steps],
                "result": r, "seconds": round(time.time() - self.started, 1), "log": self.result.get("log", [])[-6:],
                "progress": self.progress if self.state == "running" else None}


class Panel:
    def __init__(self, data_dir, port=8800, host="localhost", secure=False, demo=False, panel_host=None,
                 preview_host=None, live_suffix=None):
        self.reg = Registry(data_dir)
        self.sessions = auth.Sessions(os.path.join(data_dir, "sessions.json"))
        self.port = port
        p = "" if (secure or port in (80, 443)) else f":{port}"      # behind Caddy the public address has no port
        self.panel_host = panel_host or f"{host}{p}"
        self.preview_host = preview_host or f"preview.{host}{p}"
        self.live_suffix = live_suffix if live_suffix is not None else f".{host}{p}"
        self.scheme = "https" if secure else "http"
        self.secure = secure
        self.demo = demo
        self.jobs = {}
        self.ui_version = str(int(time.time()))
        self.demo_logins = []
        self.trust_proxy = secure

    # ── who is asking ────────────────────────────────────────────────────────────────────────────────────────────
    def user_of(self, h):
        token = h.cookie("mw_session")
        email_ = self.sessions.get(token)
        if not email_:
            return None
        u = self.reg.users.get(email_)
        if not u:
            return None
        return {**u, "email": email_}

    def site_of(self, user, sid):
        """the only door from a request to a site: the session's client, then the short id inside it"""
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,40}", sid or ""):
            return None
        return self.reg.site(user["client"], sid)

    def live_site(self, host):
        if not self.live_suffix or not host.endswith(self.live_suffix):
            return None
        label = host[: -len(self.live_suffix)]
        parts = label.split(".")
        if len(parts) != 2:
            return None
        sid, cid = parts
        site = self.reg.site(cid, sid)
        if not site or site.cfg.get("deploy", {}).get("kind", "folder") != "folder":
            return None
        return os.path.normpath(os.path.join(self.reg.data, site.cfg.get("deploy", {}).get("path", f"live/{cid}/{sid}")))

    def origin(self, host):
        return f"{self.scheme}://{host}"


def make_handler(panel, force=None):
    """force="panel" or "preview": this listening port is that one address, whatever the Host header says
    (behind a tunnel the public names are random and the Host header is not ours to choose)"""
    class H(BaseHTTPRequestHandler):
        server_version = "MIDDLEWARE-Panel"
        sys_version = ""
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            if os.environ.get("PANEL_LOG"):
                sys.stderr.write("%s %s\n" % (self.address_string(), fmt % args))

        # ── plumbing ─────────────────────────────────────────────────────────────────────────────────────────────
        def cookie(self, name):
            raw = self.headers.get("Cookie", "")
            for part in raw.split(";"):
                k, _, v = part.strip().partition("=")
                if k == name:
                    return v
            return None

        def host(self):
            return (self.headers.get("Host") or "").lower()

        def send(self, code, body=b"", ctype="application/json; charset=utf-8", headers=None, cache="no-store"):
            if isinstance(body, (dict, list)):
                body = json.dumps(body, ensure_ascii=False).encode("utf-8")
            elif isinstance(body, str):
                body = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", cache)
            self.send_header("X-Content-Type-Options", "nosniff")
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def err(self, code, error, **details):
            self.send(code, {"error": error, **details})

        def body(self, limit=JSON_MAX):
            n = int(self.headers.get("Content-Length") or 0)
            if n > limit:
                raise ValueError("too_large")
            data = self.rfile.read(n) if n else b""
            self._read = True
            return data

        def drain(self):
            """a request whose body no handler read: read it now, or the next request on this keep-alive connection
            starts with its bytes and is answered 501 (seen: POST /preview, then GET /changes, which told the client
            "everything is live" with six changes unpublished)"""
            if getattr(self, "_read", False):
                return
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = -1
            if 0 < n <= JSON_MAX:
                self.rfile.read(n)
            elif n:
                self.close_connection = True

        def json_body(self):
            data = self.body()
            try:
                return json.loads(data or b"{}")
            except Exception:
                raise ValueError("bad_json")

        def panel_headers(self):
            pv = panel.origin(panel.preview_host)
            return {"Content-Security-Policy": f"default-src 'self'; img-src 'self' data: blob: {pv}; frame-src {pv}; "
                                               f"connect-src 'self'; style-src 'self' 'unsafe-inline'; font-src 'self'; "
                                               f"script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
                    "Referrer-Policy": "same-origin", "X-Frame-Options": "DENY",
                    "Permissions-Policy": "camera=(), microphone=(), geolocation=()"}

        def file(self, path, cache="no-cache", extra=None, inject=None):
            if not os.path.isfile(path):
                return self.err(404, "not_found")
            ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype in ("application/json", "image/svg+xml", "text/javascript"):
                ctype += "; charset=utf-8"
            data = open(path, "rb").read()
            if inject and path.endswith(".html"):
                data = inject(data)
            h = dict(extra or {})
            h["Last-Modified"] = email.utils.formatdate(os.path.getmtime(path), usegmt=True)
            self.send(200, data, ctype, h, cache)

        # ── dispatch ─────────────────────────────────────────────────────────────────────────────────────────────
        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            self.route("GET")

        def do_POST(self):
            self.route("POST")

        def do_PUT(self):
            self.route("PUT")

        def do_DELETE(self):
            self.route("DELETE")

        def route(self, method):
            self._read = False
            try:
                host = self.host()
                path = urllib.parse.urlsplit(self.path).path
                if force == "preview" or (force is None and host == panel.preview_host):
                    return self.preview(method, path)
                if force is None:
                    live = panel.live_site(host)
                    if live:
                        return self.live(method, live, path)
                    if host != panel.panel_host:
                        return self.err(404, "unknown_host")
                if path.startswith("/api/"):
                    return self.api(method, path)
                if method not in ("GET", "HEAD"):
                    return self.err(405, "method")
                return self.ui(path)
            except (BrokenPipeError, ConnectionResetError):
                pass                                   # the browser went away mid-answer (a closed tab, a cancelled fetch)
            except Exception:
                traceback.print_exc()
                try:
                    self.err(500, "server")
                except Exception:
                    pass
            finally:
                try:
                    self.drain()
                except Exception:
                    self.close_connection = True

        # ── the interface ────────────────────────────────────────────────────────────────────────────────────────
        def ui(self, path):
            if path == "/ui/demo.json":
                return self.send(200, panel.demo_logins) if panel.demo else self.err(404, "not_found")
            if path.startswith("/ui/"):
                rel = os.path.normpath(path[4:].split("?")[0])
                if rel.startswith("..") or rel.startswith("/") or rel == "bridge.js":
                    return self.err(404, "not_found")
                return self.file(os.path.join(UI, rel), cache="no-cache", extra=self.panel_headers())
            if path in ("/", "/index.html") or re.fullmatch(r"/(sites|login)(/[\w./-]*)?", path):
                doc = open(os.path.join(UI, "index.html"), encoding="utf-8").read()
                doc = doc.replace("__PREVIEW_ORIGIN__", panel.origin(panel.preview_host)).replace("__V__", panel.ui_version)
                doc = doc.replace("__DEMO__", "1" if panel.demo else "")
                return self.send(200, doc, "text/html; charset=utf-8", self.panel_headers())
            if path == "/ui/demo.json":
                if not panel.demo:
                    return self.err(404, "not_found")
                return self.send(200, panel.demo_logins)
            if path == "/favicon.ico":
                return self.file(os.path.join(UI, "favicon.svg"), extra={"Content-Type": "image/svg+xml"})
            return self.err(404, "not_found")

        # ── previews: a build's address is its key ───────────────────────────────────────────────────────────────
        def preview(self, method, path):
            if method not in ("GET", "HEAD"):
                return self.err(405, "method")
            if path == "/__mw/bridge.js":
                return self.file(os.path.join(UI, "bridge.js"), cache="no-cache",
                                 extra={"Access-Control-Allow-Origin": "*"})
            m = re.fullmatch(r"/live/([a-z0-9-]+)/([a-z0-9-]+)(/.*)?", path)
            if m:                                      # a published site served under the preview address (a tunnel)
                site = panel.reg.site(m.group(1), m.group(2))
                dep = (site.cfg.get("deploy") or {}) if site else {}
                if not site or dep.get("kind", "folder") != "folder" or not dep.get("base", "").startswith("/live/"):
                    return self.err(404, "not_found")
                if not m.group(3):
                    return self.send(301, b"", "text/plain", {"Location": path + "/"})
                root = os.path.normpath(os.path.join(panel.reg.data, dep.get("path", f"live/{site.cid}/{site.sid}")))
                return self.live(method, root, m.group(3))
            m = re.fullmatch(r"/b/([\w-]{20,40})/(.*)", path)
            if not m:
                return self.err(404, "not_found")
            bid, rel = m.group(1), urllib.parse.unquote(m.group(2))
            hit = panel.reg.builds.get(bid)
            if not hit:
                return self.send(410, "<!doctype html><meta charset=utf-8><title>Preview expired</title>"
                                      "<p style='font:16px system-ui;padding:2em'>This preview has been replaced.</p>",
                                 "text/html; charset=utf-8")
            site, out = hit
            target = os.path.normpath(os.path.join(out, rel))
            if not (target == out or target.startswith(out + os.sep)):
                return self.err(404, "not_found")
            if os.path.isdir(target):
                target = os.path.join(target, "index.html")
            if not os.path.exists(target) and not os.path.splitext(target)[1]:
                target = target.rstrip("/") + "/index.html"
            po = panel.origin(panel.panel_host)
            headers = {"Content-Security-Policy": f"frame-ancestors {po}", "Referrer-Policy": "no-referrer",
                       "X-Robots-Tag": "noindex, nofollow"}

            def inject(data):
                tag = b'<script src="/__mw/bridge.js?v=' + panel.ui_version.encode() + b'" data-panel="' + po.encode() + b'"></script>'
                i = data.rfind(b"</body>")
                return data[:i] + tag + data[i:] if i >= 0 else data + tag
            if not os.path.exists(target):
                nf = os.path.join(out, "404.html")
                if os.path.exists(nf):
                    data = inject(open(nf, "rb").read())
                    return self.send(404, data, "text/html; charset=utf-8", headers)
                return self.err(404, "not_found")
            cache = "no-cache" if target.endswith(".html") else "private, max-age=600"
            return self.file(target, cache=cache, extra=headers, inject=inject)

        # ── the published sites (a "folder" deploy, served here only as a stand-in for real hosting) ─────────────
        def live(self, method, root, path):
            if method not in ("GET", "HEAD"):
                return self.err(405, "method")
            rel = urllib.parse.unquote(path).lstrip("/")
            target = os.path.normpath(os.path.join(root, rel))
            if not (target == root or target.startswith(root + os.sep)):
                return self.err(404, "not_found")
            if os.path.isdir(target):
                target = os.path.join(target, "index.html")
            if not os.path.exists(target):
                nf = os.path.join(root, "404.html")
                if os.path.exists(nf):
                    return self.send(404, open(nf, "rb").read(), "text/html; charset=utf-8")
                return self.send(404, "<!doctype html><meta charset=utf-8><title>Not published yet</title>"
                                      "<p style='font:16px system-ui;padding:2em'>Nothing has been published here yet.</p>",
                                 "text/html; charset=utf-8")
            return self.file(target, cache="no-cache")

        # ── the API ──────────────────────────────────────────────────────────────────────────────────────────────
        def api(self, method, path):
            if method != "GET":
                if self.headers.get("X-Panel") != "1":
                    return self.err(403, "csrf")
                o = self.headers.get("Origin")
                if o and o != panel.origin(panel.panel_host):
                    return self.err(403, "csrf")
            if path == "/api/login" and method == "POST":
                return self.login()
            if path == "/api/logout" and method == "POST":
                panel.sessions.drop(self.cookie("mw_session"))
                return self.send(200, {"ok": True}, headers={"Set-Cookie": self.clear_cookie()})
            if path == "/api/demo" and method == "GET":
                return self.send(200, {"demo": bool(panel.demo)})
            user = panel.user_of(self)
            if not user:
                return self.err(401, "signed_out")
            if path == "/api/me":
                if method == "PUT":
                    b = self.json_body()
                    if b.get("lang") in ("ar", "en"):
                        panel.reg.users[user["email"]]["lang"] = b["lang"]
                        panel.reg.save_users()
                    user = panel.user_of(self)
                return self.send(200, me(panel, user))
            m = re.fullmatch(r"/api/jobs/([\w-]+)", path)
            if m:
                j = panel.jobs.get(m.group(1))
                if not j or j.cid != user["client"]:
                    return self.err(404, "not_found")
                return self.send(200, j.public())
            m = re.fullmatch(r"/api/s/([a-z0-9-]+)(/.*)?", path)
            if not m:
                return self.err(404, "not_found")
            site = panel.site_of(user, m.group(1))
            if not site:
                return self.err(404, "not_found")
            return self.site_api(method, (m.group(2) or "/"), site, user)

        def clear_cookie(self):
            return "mw_session=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict" + ("; Secure" if panel.secure else "")

        def login(self):
            b = self.json_body()
            email_ = (b.get("email") or "").strip().lower()[:200]
            ip = self.client_address[0]
            if panel.trust_proxy and self.headers.get("X-Forwarded-For"):
                ip = self.headers["X-Forwarded-For"].split(",")[-1].strip()      # the address Caddy saw
            wait = panel.sessions.wait("ip:" + ip, "user:" + email_)
            if wait:
                return self.err(429, "slow_down", seconds=wait)
            u = auth.verify(panel.reg.users, email_, b.get("password") or "")
            if not u:
                panel.sessions.failed("ip:" + ip, "user:" + email_)
                time.sleep(0.25)
                return self.err(401, "wrong")
            panel.sessions.cleared("user:" + email_)
            token = panel.sessions.create(email_)
            ck = f"mw_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={auth.ABSOLUTE}" + ("; Secure" if panel.secure else "")
            return self.send(200, me(panel, {**u, "email": email_}), headers={"Set-Cookie": ck})

        def site_api(self, method, sub, site, user):
            try:
                return self._site_api(method, sub, site, user)
            except FieldError as e:
                code = 409 if e.code in ("rec_in_use", "rec_undo_conflict") else 404 if e.code == "rec_not_found" else 400
                return self.err(code, e.code, **e.details)
            except ImageError as e:
                return self.err(400, "image_" + e.code, **e.details)
            except LinkError as e:
                return self.err(400, "link_" + e.code, **e.details)
            except Busy as e:
                return self.err(409, "busy", what=str(e))
            except ValueError as e:
                if str(e) == "too_large":
                    self.close_connection = True
                    return self.send(413, {"error": "too_large"}, headers={"Connection": "close"})
                if str(e) == "bad_json":
                    return self.err(400, "bad_json")
                raise

        def records_api(self, method, sub, site, user):
            """the Content area: lists of records and settings objects, edited as drafts like everything else"""
            if not site.records:
                return self.err(404, "not_found")
            ID = r"[a-z0-9][a-z0-9_-]{0,47}"
            if sub == "/records" and method == "GET":
                with site.lock:
                    return self.send(200, records.public(site))
            m = re.fullmatch(rf"/records/({ID})", sub)
            if m and method == "POST":
                b = self.json_body()
                at = b.get("at") if isinstance(b.get("at"), int) else None
                rid, title = site.record_op("add", user, m.group(1), b.get("values") or {}, at)
                return self.send(200, {"id": rid, "title": title, "changes": len(site.diff())})
            m = re.fullmatch(rf"/records/({ID})/({ID})", sub)
            if m and method == "PUT":
                b = self.json_body()
                title = site.record_op("edit", user, m.group(1), m.group(2), b.get("values") or {})
                return self.send(200, {"id": m.group(2), "title": title, "changes": len(site.diff())})
            if m and method == "DELETE":
                title = site.record_op("delete", user, m.group(1), m.group(2))
                return self.send(200, {"removed": m.group(2), "title": title, "changes": len(site.diff())})
            m = re.fullmatch(rf"/records/({ID})/({ID})/duplicate", sub)
            if m and method == "POST":
                rid, title = site.record_op("duplicate", user, m.group(1), m.group(2), {"en": "copy", "ar": "نسخة"})
                return self.send(200, {"id": rid, "title": title, "changes": len(site.diff())})
            m = re.fullmatch(rf"/order/({ID})", sub)
            if m and method == "PUT":
                b = self.json_body()
                site.record_op("reorder", user, m.group(1), b.get("ids"))
                return self.send(200, {"ok": True, "changes": len(site.diff())})
            m = re.fullmatch(rf"/settings/({ID})", sub)
            if m and method == "PUT":
                b = self.json_body()
                site.record_op("settings", user, m.group(1), b.get("values") or {})
                return self.send(200, {"ok": True, "changes": len(site.diff())})
            m = re.fullmatch(rf"/rec-upload/({ID})/([A-Za-z_][\w-]{{0,40}})", sub)
            if m and method == "POST":
                data = self.body(limit=records.UPLOAD_MAX + 1)
                name = urllib.parse.unquote(self.headers.get("X-Filename") or "upload")
                with site.lock:
                    meta = records.receive(site, m.group(1), m.group(2), data, name)
                return self.send(200, {**meta, "url": f"/api/s/{site.sid}/rec-upload/{meta['id']}"})
            m = re.fullmatch(r"/rec-upload/([0-9a-f]{24})", sub)
            if m and method == "GET":
                path, meta = records.staged_path(site, m.group(1))
                return self.rec_file(path, meta["ext"] if meta else None)
            m = re.fullmatch(rf"/rec-file/({ID})/([A-Za-z_][\w-]{{0,40}})/([^/]{{1,121}})", sub)
            if m and method == "GET":
                name = urllib.parse.unquote(m.group(3))
                path = records.file_path(site, m.group(1), m.group(2), name)
                return self.rec_file(path, os.path.splitext(name)[1].lstrip(".").lower() if path else None)
            return self.err(404, "not_found")

        def rec_file(self, path, ext):
            """a record's picture, shown to the panel only as a picture: its type from what it is, never sniffed,
            an SVG sandboxed so that even opened on its own it runs nothing"""
            types = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "webp": "image/webp", "svg": "image/svg+xml"}
            if not path or ext not in types or not os.path.isfile(path):
                return self.err(404, "not_found")
            h = {"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox",
                 "Content-Disposition": "inline", "Cross-Origin-Resource-Policy": "same-origin"}
            return self.send(200, open(path, "rb").read(), types[ext], h, cache="private, max-age=600")

        def _site_api(self, method, sub, site, user):
            if re.match(r"/(records|order|settings|rec-upload|rec-file)(/|$)", sub):
                return self.records_api(method, sub, site, user)
            if sub == "/state" and method == "GET":
                return self.send(200, state(panel, site, user))
            if sub == "/text" and method == "PUT":
                b = self.json_body()
                edits = [(e["key"], e["lang"], e["value"]) for e in (b.get("edits") or [])][:50]
                if not edits:
                    raise FieldError("nothing")
                for k, L, _ in edits:
                    if k.startswith("seo:"):
                        ensure_seo_slot(site, k)
                done = site.set_text(edits, user)
                also = shared_fanout(panel, site, user, done)
                return self.send(200, {"saved": [{"key": k, "lang": L, "value": v} for k, L, v in done], "also": also,
                                       "changes": len(site.diff())})
            if sub == "/labels" and method == "POST":
                b = self.json_body()
                labels = b.get("labels") or {}
                c = site.content()
                with site.lock:
                    for k, v in list(labels.items())[:2000]:
                        if k in c.fields and isinstance(v, dict):
                            site.state["labels"][k] = {kk: str(v.get(kk, ""))[:80] for kk in ("role", "section", "page")}
                    site.save_state()
                return self.send(200, {"ok": True})
            m = re.fullmatch(r"/upload/([\w-]+)", sub)
            if m and method == "POST":
                slot = site.slots.get(m.group(1))
                if not slot:
                    return self.err(404, "not_found")
                data = self.body(limit=images.MAX_BYTES + 1)
                name = urllib.parse.unquote(self.headers.get("X-Filename") or "upload")
                meta = images.receive(site.uploads, data, name)
                ratio, need = images.shape(site.work, slot)
                try:
                    warn = images.assess(meta, ratio, need, slot)
                except ImageError:
                    raise
                return self.send(200, {**meta, "ratio": ratio, "need": need, "warnings": warn,
                                       "thumb": f"/api/s/{site.sid}/uploads/{meta['id']}.webp"})
            m = re.fullmatch(r"/uploads/([a-f0-9]{24})\.webp", sub)
            if m and method == "GET":
                return self.file(os.path.join(site.uploads, m.group(1) + ".thumb.webp"), cache="private, max-age=3600")
            m = re.fullmatch(r"/image/([\w-]+)", sub)
            if m and method == "POST":
                slot = site.slots.get(m.group(1))
                if not slot:
                    return self.err(404, "not_found")
                b = self.json_body()
                written = site.set_image(slot["id"], str(b.get("upload", "")), b.get("crop") or {}, user)
                return self.send(200, {"written": written, "changes": len(site.diff())})
            m = re.fullmatch(r"/image-at/([0-9a-f]{7,40}|HEAD)/([\w-]+)\.webp", sub)
            if m and method == "GET":
                slot = site.slots.get(m.group(2))
                if not slot:
                    return self.err(404, "not_found")
                big = max(slot["files"], key=lambda f: f["width"])
                from . import gitw
                data = gitw.show(site.work, m.group(1), big["path"], binary=True)
                if data is None:
                    return self.err(404, "not_found")
                return self.send(200, data, "image/webp", cache="private, max-age=86400")
            m = re.fullmatch(r"/image/([\w-]+)\.webp", sub)
            if m and method == "GET":
                slot = site.slots.get(m.group(1))
                if not slot:
                    return self.err(404, "not_found")
                big = max(slot["files"], key=lambda f: f["width"])
                return self.file(os.path.join(site.work, big["path"]), cache="no-cache")
            if sub == "/mark" and method == "GET":
                rel = site.manifest.get("mark")
                if not rel:
                    return self.err(404, "not_found")
                return self.file(os.path.join(site.work, rel), cache="private, max-age=3600")
            if sub == "/social" and method == "PUT":
                b = self.json_body()
                saved = site.set_social(b.get("links") or [], user)
                return self.send(200, {"links": saved, "changes": len(site.diff())})
            if sub == "/changes" and method == "GET":
                return self.send(200, {"changes": changes_public(site)})
            if sub == "/revert" and method == "POST":
                b = self.json_body()
                n = site.revert(b.get("ids"))
                return self.send(200, {"reverted": n, "changes": len(site.diff())})
            if sub == "/preview" and method == "GET":
                return self.send(200, preview_public(panel, site))
            if sub == "/preview" and method == "POST":
                site.preview_now()
                return self.send(200, preview_public(panel, site))
            if sub == "/publish" and method == "POST":
                if site.busy:
                    raise Busy(site.busy)
                job = Job(site.cid, site.sid, "publish")
                panel.jobs[job.id] = job

                def go():
                    try:
                        site.publish(user, job)
                    except Busy as e:
                        job.fail("busy", what=str(e))
                    except Exception as e:
                        traceback.print_exc()
                        job.fail("deploy" if job.steps and job.steps[-1]["name"] == "deploy" else "server", error=str(e)[:300])
                threading.Thread(target=go, daemon=True).start()
                return self.send(202, job.public())
            if sub == "/history" and method == "GET":
                return self.send(200, {"versions": history_public(site)})
            if sub == "/undo" and method == "POST":
                b = self.json_body()
                c = site.undo(str(b.get("version", "")), str(b.get("change", "")))
                return self.send(200, {"undone": c["id"], "changes": len(site.diff())})
            if sub == "/restore" and method == "POST":
                b = self.json_body()
                n = site.restore(str(b.get("version", "")))
                return self.send(200, {"changes": n})
            return self.err(404, "not_found")
    return H


# ── what the interface is sent ───────────────────────────────────────────────────────────────────────────────────

def me(panel, user):
    c = panel.reg.clients[user["client"]]
    sites = []
    for s in panel.reg.sites_of(user["client"]):
        sites.append(site_card(panel, s))
    return {"user": {"name": user["name"], "email": user["email"], "lang": user.get("lang", "ar")},
            "client": {"id": user["client"], "name": c["name"]}, "sites": sites,
            "preview_origin": panel.origin(panel.preview_host)}


def site_card(panel, s):
    m = s.manifest
    return {"id": s.sid, "name": m.get("name", {}), "short": m.get("short", s.sid), "color": m.get("color", "#111"),
            "ink": m.get("ink", "#fff"), "langs": m["languages"], "live_url": s.cfg.get("deploy", {}).get("url", ""),
            "changes": len(s.diff()), "live": s.state.get("live"),
            "mark": f"/api/s/{s.sid}/mark" if m.get("mark") else None, "records": bool(s.records)}


def state(panel, site, user):
    c = site.content()
    slots = []
    for sid, sl in site.slots.items():
        ratio, need = images.shape(site.work, sl)
        slots.append({**sl, "ratio": ratio, "need": need,
                      "url": f"/api/s/{site.sid}/image/{sid}.webp?v={site._hash(max(sl['files'], key=lambda f: f['width'])['path'], None)[:10]}"})
    soc = None
    if site.manifest.get("social"):
        cfg = site.manifest["social"]
        soc = {"kind": cfg["kind"], "links": social.read(site.manifest, site._reader(None)),
               "allowed": cfg.get("allowed") or [n["network"] for n in cfg.get("networks", [])],
               "names": {k: v["name"] for k, v in social.NETWORKS.items()}}
    shared = {}
    for g in panel.reg.clients[site.cid].get("shared", []):
        names = [t["site"] for t in g["targets"]]
        for t in g["targets"]:
            if t["site"] == site.sid:
                shared[t["field"]] = [n for n in names if n != site.sid]
    card = site_card(panel, site)
    card["hints"] = site.manifest.get("hints", [])
    card["sections"] = site.manifest.get("sections", {})
    card["word_list"] = site.manifest.get("word_list")
    return {"site": card, "fields": c.public(), "slots": slots, "social": soc,
            "seo": seo_public(site), "labels": site.state.get("labels", {}), "shared": shared,
            "preview": preview_public(panel, site), "busy": site.busy}


def preview_public(panel, site):
    pv = site.preview_meta()
    if not pv and not site._building and not (site._timer and site._timer.is_alive()) and not site.state.get("preview_error"):
        site.schedule_preview(0.05)             # a site opened for the first time builds its preview by itself
    if not pv:
        return {"ready": False, "building": site._building, "error": (site.state.get("preview_error") or {}).get("error")}
    return {"ready": True, "id": pv["id"], "base": f"{panel.origin(panel.preview_host)}/b/{pv['id']}/",
            "fresh": site.preview_fresh(), "building": site._building, "marked": pv["marked"],
            "error": ((site.state.get("preview_error") or {}).get("error")
                      if (site.state.get("preview_error") or {}).get("at", 0) > pv.get("at", 0) else None),
            "ids": pv["ids"], "values": pv["values"], "images": pv.get("images", {}),
            "pages": [{k: p[k] for k in ("id", "lang", "path", "title", "ids")} for p in pv.get("pages", [])],
            "seconds": pv.get("seconds")}


def seo_public(site):
    pv = site.preview_meta() or {}
    cfg = site.manifest.get("seo", {})
    c = site.content()
    by_id = {}
    for p in pv.get("pages", []):
        by_id.setdefault(p["id"], {})[p["lang"]] = p
    out = []
    ids_map = pv.get("ids", [])
    defaults = site.state.setdefault("seo_default", {})
    for pid, langs in by_id.items():
        refs = cfg.get("pages", {}).get(pid)
        if refs:
            tk, dk = refs.get("title"), refs.get("description")
        elif cfg.get("overrides"):
            slot = cfg["overrides"]["pointer"].format(page=_page_key(pid))
            tk, dk = f"{cfg['overrides']['source']}:{slot}/title", f"{cfg['overrides']['source']}:{slot}/description"
        else:
            tk = dk = None
        entry = {"id": pid, "title_key": tk, "desc_key": dk, "langs": {}}
        for L, p in langs.items():
            ov_t = c.fields[tk].values.get(L) if tk in c.fields else None
            ov_d = c.fields[dk].values.get(L) if dk in c.fields else None
            dflt = defaults.setdefault(pid, {}).setdefault(L, {})
            if not (refs) and not ov_t:
                dflt["title"] = p["title"]
            if not (refs) and not ov_d:
                dflt["description"] = p["description"]
            imgs = []
            for im in p["images"]:
                slot = next((s for s in site.slots.values() if any(os.path.basename(f["path"]) in im["files"] for f in s["files"])), None)
                alt_key = slot["alt"] if slot and slot["alt"] else None
                if not alt_key and im["alt_ids"]:
                    k = ids_map[im["alt_ids"][0]][0] if im["alt_ids"][0] < len(ids_map) else None
                    alt_key = k
                imgs.append({"slot": slot["id"] if slot else None, "file": im["files"][0] if im["files"] else "",
                             "alt": im["alt"], "alt_key": alt_key})
            entry["langs"][L] = {"path": p["path"], "title": p["title"], "description": p["description"],
                                 "default_title": dflt.get("title", ""), "default_description": dflt.get("description", ""),
                                 "images": imgs}
        out.append(entry)
    site.save_state()
    order = {"": 0}
    out.sort(key=lambda e: (order.get(e["id"], 1), e["id"]))
    return {"pages": out, "brand": site.manifest.get("brand_words", [])}


def _page_key(pid):
    return pid.strip("/") or "home"


def ensure_seo_slot(site, key):
    """an override slot for a page that has none yet (a new recipe page) is created, in the file's own style"""
    from . import content as C
    src_id, _, pointer = key.partition(":")
    src = next((s for s in site.manifest["text"] if s["id"] == src_id), None)
    if not src or src.get("role") != "seo":
        return
    c = site.content()
    if key in c.fields:
        return
    parts = C.unptr(pointer)
    data = C.read_json(site.work, src["file"])
    tgt = data
    for k in parts[:-1]:
        tgt = tgt.setdefault(k, {})
    tgt.setdefault(parts[-1], {L: "" for L in site.langs})
    text = open(os.path.join(site.work, src["file"]), encoding="utf-8").read()
    C._write(site.work, src["file"], C.jsonspan.redump(text, data))
    site.invalidate()


def shared_fanout(panel, site, user, done):
    """a value shared by several of the client's sites is written to each of them"""
    groups = panel.reg.clients[site.cid].get("shared", [])
    also = []
    for g in groups:
        mine = [t for t in g["targets"] if t["site"] == site.sid]
        for k, L, v in done:
            if not any(t["field"] == k for t in mine):
                continue
            for t in g["targets"]:
                if t["site"] == site.sid:
                    continue
                other = panel.reg.site(site.cid, t["site"])
                if other and t["field"] in other.content().fields:
                    other.set_text([(t["field"], L, v)], user)
                    also.append(t["site"])
    return sorted(set(also))


def changes_public(site):
    out = []
    by = site.state.get("draft_by", {})
    for c in site.diff():
        out.append({**c, "by": by.get(c["id"])})
    return out


def history_public(site):
    rows = site.history()
    live = (site.state.get("live") or {}).get("version")
    out = []
    for r in rows:
        out.append({"id": r["id"], "at": r["at"], "name": r["name"], "first": r["first"], "live": r["id"] == live,
                    "changes": r["changes"], "subject": r["subject"]})
    return out


class Server(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 128              # Chrome opens many connections at once; the default backlog of 5 resets them
    allow_reuse_address = True


class Pair:
    """the panel's port and the previews' port, run together"""

    def __init__(self, a, b):
        self.a, self.b = a, b

    def serve_forever(self):
        threading.Thread(target=self.b.serve_forever, daemon=True).start()
        self.a.serve_forever()

    def shutdown(self):
        self.b.shutdown()
        self.a.shutdown()


def serve(data_dir, port=8800, demo=False, bind="127.0.0.1", preview_port=None, **kw):
    panel = Panel(data_dir, port=port, demo=demo, **kw)
    if not preview_port:
        return panel, Server((bind, port), make_handler(panel))
    return panel, Pair(Server((bind, port), make_handler(panel, "panel")), Server((bind, preview_port), make_handler(panel, "preview")))
