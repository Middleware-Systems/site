#!/usr/bin/env python3
"""
geo.py: Syria's fourteen governorates for the plan view, and the geometry the build and the checks share.

    python3 tools/geo.py path/to/geoBoundaries-SYR-ADM1.geojson     writes content/geo.json

Source (downloaded 5 Nov 2026, read as data):
  https://github.com/wmgeolab/geoBoundaries/raw/9469f09/releaseData/gbOpen/SYR/ADM1/geoBoundaries-SYR-ADM1.geojson
  boundaryID SYR-ADM1-8384693 · United Nations Cartographic Section and OCHA ROSC · CC BY 3.0 IGO
  SHA-256 9f781624caaf3bb3256585deee69c2b985b1144b19909cf0386f663ddb41d527

Each ring is simplified (Douglas–Peucker, TOL_KM) on its own; at the size the map is drawn a kilometre is under a
pixel, so neighbours still meet. The label anchor of each governorate is its pole of inaccessibility, found on a grid.
"""
import hashlib, json, math, os, sys
# numpy is imported where it is used, so the build (which needs only km_xy) runs without it, in Pyodide too

SITE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SHA = "9f781624caaf3bb3256585deee69c2b985b1144b19909cf0386f663ddb41d527"
TOL_KM = 0.45
LAT0 = 35.0                     # the projection's standard parallel: Syria spans 32.3–37.3 °N
KX = math.cos(math.radians(LAT0))

ISO = {   # geoBoundaries' shapeISO → the key the site uses
    "SYR-DI": "damascus", "SYR-RD": "rural-damascus", "SYR-HL": "aleppo", "SYR-HI": "homs", "SYR-HM": "hama",
    "SYR-LA": "latakia", "SYR-TA": "tartus", "SYR-ID": "idlib", "SYR-DR": "daraa", "SYR-QU": "quneitra",
    "SYR-SU": "suwayda", "SYR-DY": "deir-ez-zor", "SYR-RA": "raqqa", "SYR-HA": "hasakah",
}


NAMES = {   # the names the page shows (the company profile's own, page 8), in the profile's order
    "damascus": {"en": "Damascus", "ar": "دمشق"},
    "rural-damascus": {"en": "Rural Damascus", "ar": "ريف دمشق"},
    "aleppo": {"en": "Aleppo", "ar": "حلب"},
    "homs": {"en": "Homs", "ar": "حمص"},
    "hama": {"en": "Hama", "ar": "حماة"},
    "latakia": {"en": "Latakia", "ar": "اللاذقية"},
    "tartus": {"en": "Tartus", "ar": "طرطوس"},
    "idlib": {"en": "Idlib", "ar": "إدلب"},
    "daraa": {"en": "Daraa", "ar": "درعا"},
    "quneitra": {"en": "Quneitra", "ar": "القنيطرة"},
    "suwayda": {"en": "As-Suwayda", "ar": "السويداء"},
    "deir-ez-zor": {"en": "Deir ez-Zor", "ar": "دير الزور"},
    "raqqa": {"en": "Raqqa", "ar": "الرقة"},
    "hasakah": {"en": "Al-Hasakah", "ar": "الحسكة"},
}


def km_xy(lon, lat):
    """One point, lon/lat to kilometres on the map's plane, in plain Python: the same arithmetic as km(), in the same order."""
    return (lon * 111.32 * KX, -lat * 110.57)


def km(lon, lat):
    """Lon/lat to kilometres on the plane the map is drawn on (equirectangular at LAT0, good to ~1 % over Syria)."""
    import numpy as np
    return np.stack([np.asarray(lon) * 111.32 * KX, -np.asarray(lat) * 110.57], axis=-1)


def dp(pts, tol):
    """Douglas–Peucker on an (n, 2) array, iterative."""
    import numpy as np
    keep = np.zeros(len(pts), bool); keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        a, b = stack.pop()
        if b <= a + 1:
            continue
        seg = pts[b] - pts[a]; L = np.hypot(*seg)
        rel = pts[a + 1:b] - pts[a]
        d = np.abs(seg[0] * rel[:, 1] - seg[1] * rel[:, 0]) / L if L else np.hypot(rel[:, 0], rel[:, 1])
        i = int(np.argmax(d))
        if d[i] > tol:
            m = a + 1 + i; keep[m] = True
            stack += [(a, m), (m, b)]
    return pts[keep]


def inside(pt, rings):
    """Even–odd point in polygon over all rings (holes included). pt and rings in the same units."""
    x, y = pt; c = False
    for r in rings:
        n = len(r)
        for i in range(n):
            x1, y1 = r[i]; x2, y2 = r[(i + 1) % n]
            if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
                c = not c
    return c


def edge_dist(pt, rings):
    import numpy as np
    best = 1e18
    for r in rings:
        a = np.asarray(r); b = np.roll(a, -1, axis=0); ab = b - a
        t = np.clip(((pt - a) * ab).sum(1) / np.maximum((ab * ab).sum(1), 1e-12), 0, 1)
        q = a + ab * t[:, None]
        best = min(best, float(np.min(np.hypot(*(q - pt).T))))
    return best


def pole(rings_km):
    """The point inside the polygon farthest from its edge, on a grid refined twice (good enough for a label)."""
    import numpy as np
    allp = np.concatenate(rings_km)
    (x0, y0), (x1, y1) = allp.min(0), allp.max(0)
    best, cell = None, max(x1 - x0, y1 - y0) / 24
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    for _ in range(3):
        xs = np.arange(cx - 12 * cell, cx + 12 * cell + 1e-9, cell)
        ys = np.arange(cy - 12 * cell, cy + 12 * cell + 1e-9, cell)
        for x in xs:
            for y in ys:
                p = np.array([x, y])
                if inside(p, rings_km):
                    d = edge_dist(p, rings_km)
                    if best is None or d > best[0]:
                        best = (d, p)
        cx, cy = best[1]; cell /= 6
    return best[1]


def main():
    import numpy as np
    src = sys.argv[1]
    raw = open(src, "rb").read()
    got = hashlib.sha256(raw).hexdigest()
    if got != SHA:
        sys.exit(f"geo: {src} is not the file this was checked against (sha256 {got[:12]}…, expected {SHA[:12]}…)")
    fc = json.loads(raw)
    out, total_in, total_out = [], 0, 0
    for f in fc["features"]:
        key = ISO.get(f["properties"]["shapeISO"])
        if not key:
            sys.exit(f"geo: unknown governorate {f['properties']}")
        g = f["geometry"]
        polys = [g["coordinates"]] if g["type"] == "Polygon" else g["coordinates"]
        rings = []
        for poly in polys:
            for ring in poly:
                a = np.asarray(ring, float)[:-1]
                total_in += len(a)
                k = km(a[:, 0], a[:, 1])
                s = dp(np.vstack([k, k[:1]]), TOL_KM)[:-1]
                if len(s) < 4:
                    continue
                total_out += len(s)
                lon = s[:, 0] / (111.32 * KX); lat = -s[:, 1] / 110.57
                rings.append([[round(float(x), 4), round(float(y), 4)] for x, y in zip(lon, lat)])
        rk = [km(np.array(r)[:, 0], np.array(r)[:, 1]) for r in rings]
        p = pole(rk)
        out.append({"key": key, "name": NAMES[key], "iso": f["properties"]["shapeISO"], "source_name": f["properties"]["shapeName"],
                    "label": [round(float(p[0] / (111.32 * KX)), 4), round(float(-p[1] / 110.57), 4)], "rings": rings})
    if len(out) != 14:
        sys.exit(f"geo: expected 14 governorates, got {len(out)}")
    doc = {"_": "Generated by tools/geo.py. Do not edit by hand.",
           "source": "geoBoundaries SYR-ADM1-8384693 (United Nations Cartographic Section and OCHA ROSC)",
           "license": "CC BY 3.0 IGO", "sha256": SHA, "tolerance_km": TOL_KM, "lat0": LAT0,
           "governorates": sorted(out, key=lambda g: list(NAMES).index(g["key"]))}
    path = os.path.join(SITE, "content", "geo.json")
    json.dump(doc, open(path, "w"), separators=(",", ":"))
    print(f"✓ geo: 14 governorates · {total_in} → {total_out} vertices · {os.path.getsize(path) // 1024} kB")


if __name__ == "__main__":
    main()
