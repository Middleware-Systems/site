#!/usr/bin/env python3
"""
build.py: AlSadeq's site, from content/*.json to <out>/<base>/.

    python3 tools/build.py [--out dist] [--base /alsadq/] [--origin https://middlewaresy.com]

The content contract (docs/REVISIONS.md §2), which the dashboard edits:
  content/projects.json   every project: title, client, governorates, optional region, signing date(s), areas, photo
  content/clients.json    who AlSadeq works for, their kinds, their logos (files in src/assets/clients/)
  content/areas.json      the areas of work in the order the drawing descends, each with its level and note
  content/site.json       the company, the contact, the figures (stats: "auto" = counted here, or a typed number)
  content/copy.json       every other word, English and formal Arabic in lockstep
  content/geo.json        the governorates' outlines and names (tools/geo.py)
This file holds markup and no words. A count never sits typed in a sentence: it is counted here and written through
count() (copy.json "counts"; Arabic 1 · 2 · 3–10 · 11+). On the Arabic page every Latin run and every figure is isolated
in a <bdi dir="ltr">.

Base-path-safe: every URL the pages write starts with --base. The English page is <base>, the Arabic one <base>ar/.
Every page says noindex, nofollow. The output is a function of the content alone (no clock, no randomness), so the
same content builds the same bytes. Unknown or inconsistent content stops the build with a sentence that names it.
"""
import argparse, datetime, hashlib, html, json, math, os, re, shutil, sys

SITE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from geo import km_xy  # noqa: E402  (plain Python: the build needs no numpy)

E = html.escape
# the drawing's networks, one colour each, and the area dots
DATA = "#D58BFF"
AREA_COLOR = {"water": "#38C3F0", "sanitation": "#CDAA6B", "solar": "#FFB23F", "it": DATA, "wells": "#7C93FF",
              "equipment": "#7FD0B0", "civil": "#9AA6B5"}
OTHER_COLOR = "#B8C2CE"               # an area added later, with no station and no colour of its own
STATION_PARTS = {"solar": ["array", "light"], "civil": ["school", "bakery"], "it": ["registry", "dataroom", "duct"],
                 "equipment": ["cabinet", "wellhead"], "water": ["tank", "main"], "sanitation": ["sewer", "manhole", "plant"],
                 "wells": ["casing", "pump", "aquifer"]}
PARTS = [p for ps in STATION_PARTS.values() for p in ps]
CARD_ITEMS = 3                        # the newest projects shown on an area's card; the rest are one tap away
HOME_ITEMS = 6                        # the home page's short list of projects (four on a phone)
PAGE_STEP = 12                        # the projects page shows twelve, then twelve more at a time
PANEL_ITEMS = 5                       # the map's governorate panel lists at most five, then a link to all
MARKER = ".alsadeq-build"             # a folder build.py made, and may therefore empty again


def die(msg):
    sys.exit(f"build: {msg}")


def load(name, site=SITE):
    p = os.path.join(site, "content", name)
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        die(f"content/{name} is missing")
    except json.JSONDecodeError as e:
        die(f"content/{name} is not valid JSON (line {e.lineno}: {e.msg})")


# ── words that the page and the checks share ─────────────────────────────────────────────────────────────────────
def plural_form(n, lang):
    """The form of a counted noun. Arabic: 0, 1, 2, 3–10 (plural), 11 and over (singular, accusative)."""
    if lang == "en":
        return "one" if n == 1 else "other"
    if n == 0:
        return "zero"
    if n == 1:
        return "one"
    if n == 2:
        return "two"
    return "few" if n <= 10 else "many"


RUN = re.compile(r"[A-Za-z0-9+−±](?:[A-Za-z0-9.,:&'/+\-−±°]|\s(?=[A-Za-z0-9(]))*")
TOKEN = re.compile(r"\{(\w+)\}")


def iso(s, ar):
    """Escape text; on the Arabic page, wrap each Latin or numeric run so it reads left to right in the Arabic line."""
    if not ar:
        return E(s)
    out, i = [], 0
    for m in RUN.finditer(s):
        out.append(E(s[i:m.start()]))
        run = m.group(0).rstrip(".,:")
        out.append(f'<bdi dir="ltr">{E(run)}</bdi>{E(m.group(0)[len(run):])}')
        i = m.end()
    out.append(E(s[i:]))
    return "".join(out)


def iso_plain(s, ar):
    """For text that cannot hold markup (an <option>, a string the script writes): each Latin or numeric run between
    the Unicode isolates LRI … PDI, which do in plain text what <bdi dir="ltr"> does in HTML."""
    if not ar:
        return s
    return RUN.sub(lambda m: "\u2066" + m.group(0).rstrip(".,:") + "\u2069" + m.group(0)[len(m.group(0).rstrip(".,:")):], s)


def norm(s):
    """Search text: lower case, no diacritics or tatweel, one form of alef, ta marbuta, ya and hamza seats."""
    s = s.lower()
    s = re.sub("[ً-ْٰـ]", "", s)
    s = re.sub("[أإآٱ]", "ا", s).replace("ة", "ه").replace("ى", "ي").replace("ؤ", "و").replace("ئ", "ي")
    return re.sub(r"\s+", " ", s).strip()


def year_of(p):
    return int(p["dates"][0][:4])


def sort_key(p):
    """Newest first; within a year a full date before a year-only one; then the Excel row (or the id)."""
    d = p["dates"][0]
    return (-int(d[:4]), 0 if len(d) == 10 else 1, "".join(chr(0x10FFFF - ord(c)) for c in d), p.get("src") or 10_000, p["id"])


class Content:
    """The content contract, read and checked once: everything the pages state, and nothing guessed."""
    def __init__(self, site=SITE):
        self.copy = load("copy.json", site)
        self.areas = load("areas.json", site)["areas"]
        self.projects = load("projects.json", site)["projects"]
        cj = load("clients.json", site)
        self.kinds, self.clients = cj["kinds"], cj["clients"]
        self.site = load("site.json", site)
        self.geo = load("geo.json", site)
        self.govs = {g["key"]: g for g in self.geo["governorates"]}
        self.area_by = {a["key"]: a for a in self.areas}
        self.client_by = {c["key"]: c for c in self.clients}
        self.validate(site)
        self.projects = sorted(self.projects, key=sort_key)

    def validate(self, site):
        """Content the dashboard may write, refused with a sentence the client can act on: every text in both languages,
        every reference resolvable, every date a date, every file present."""
        def both(obj, where):
            if not isinstance(obj, dict) or not all(isinstance(obj.get(l), str) and obj.get(l).strip() for l in ("en", "ar")):
                die(f"{where} needs its text in English and in Arabic")
        seen = set()
        for k, v in self.kinds.items():
            both(v, f"clients.json: the group label for «{k}»")
        for s in self.site.get("stats", []):
            both(s.get("label"), f"site.json: the figure «{s.get('key')}»'s label")
        for f in ("name", "line"):
            both(self.site["company"].get(f), f"site.json: the company's {f}")
        both(self.site["contact"].get("country"), "site.json: the contact country")
        for g in self.govs.values():
            both(g.get("name"), f"geo.json: the governorate «{g.get('key')}»'s name")
        for a in self.areas:
            # an area in the drawing carries its level and its caption; one added later (no station) may go without
            for f in ("key", "name", "scope") + (("level", "note") if a.get("station") else ()):
                if not a.get(f):
                    die(f"areas.json: area {a.get('key', '?')} has no {f}")
            for f in ("name", "scope", "level", "note"):
                if a.get(f):
                    both(a[f], f"areas.json: area {a['key']}'s {f}")
            if a.get("station") and a["station"] not in STATION_PARTS:
                die(f"areas.json: area {a['key']} names station «{a['station']}», which the drawing does not have")
        keys = [c.get("key") for c in self.clients]
        if len(set(keys)) != len(keys):
            die(f"clients.json: two clients share the key «{next(k for k in keys if keys.count(k) > 1)}»")
        akeys = [a.get("key") for a in self.areas]
        if len(set(akeys)) != len(akeys):
            die(f"areas.json: two areas share the key «{next(k for k in akeys if akeys.count(k) > 1)}»")
        for c in self.clients:
            both(c.get("name"), f"clients.json: client {c.get('key')}'s name")
            if c.get("kind") not in self.kinds:
                die(f"clients.json: client {c.get('key')} has kind «{c.get('kind')}», not one of {list(self.kinds)}")
            if c.get("logo"):
                p = os.path.join(site, "src", "assets", "clients", c["logo"]["file"])
                if not os.path.exists(p):
                    die(f"clients.json: {c['key']}'s logo file {c['logo']['file']} is not in src/assets/clients/")
        for p in self.projects:
            pid = p.get("id", "?")
            if pid in seen:
                die(f"projects.json: two projects have the id {pid}")
            seen.add(pid)
            both(p.get("title"), f"projects.json: {pid}'s title")
            if p.get("region"):
                both(p["region"], f"projects.json: {pid}'s region")
            if p.get("client") not in self.client_by:
                die(f"projects.json: {pid}'s client «{p.get('client')}» is not in clients.json")
            if not p.get("govs") or any(g not in self.govs for g in p["govs"]):
                die(f"projects.json: {pid}'s governorates {p.get('govs')} are not all governorates of geo.json")
            if not p.get("areas") or any(a not in self.area_by for a in p["areas"]):
                die(f"projects.json: {pid}'s areas {p.get('areas')} are not all in areas.json")
            if not p.get("dates"):
                die(f"projects.json: {pid} has no date")
            for d in p["dates"]:
                if not re.fullmatch(r"\d{4}(-\d\d-\d\d)?", d):
                    die(f"projects.json: {pid}'s date «{d}» is neither YYYY-MM-DD nor YYYY")
                if len(d) == 10:
                    try:
                        datetime.date.fromisoformat(d)
                    except ValueError:
                        die(f"projects.json: {pid}'s date «{d}» is not a day of the calendar")
            if "featured" in p and not isinstance(p["featured"], bool):
                die(f"projects.json: {pid}'s «featured» must be true or false, not {p['featured']!r}")
            if p.get("photo"):
                both(p["photo"].get("alt"), f"projects.json: {pid}'s photo description")
                if not os.path.exists(os.path.join(site, "src", "assets", "projects", p["photo"]["file"])):
                    die(f"projects.json: {pid}'s photo {p['photo']['file']} is not in src/assets/projects/")

    # counts, the only numbers the page states that are not typed by the client
    def gov_counts(self):
        n = {k: 0 for k in self.govs}
        for p in self.projects:
            for g in p["govs"]:
                n[g] += 1
        return n

    def stat_value(self, s):
        v = s.get("value")
        if v == "auto":
            auto = {"areas": len(self.areas), "projects": len(self.projects),
                    "governorates": sum(1 for v in self.gov_counts().values() if v),
                    "established": self.site["company"]["established"]}
            if s.get("key") not in auto:
                die(f"site.json: the figure «{s.get('key')}» says auto, but only {list(auto)} can be counted")
            return auto[s["key"]]
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return v
        die(f"site.json: the figure «{s.get('key')}» has value {v!r}: write \"auto\" or a number")

    def client_projects(self, key):
        return [p for p in self.projects if p["client"] == key]

    def home_projects(self):
        """The home page's short list: the projects marked featured (newest first, at most HOME_ITEMS); none marked,
        the newest HOME_ITEMS."""
        feat = [p for p in self.projects if p.get("featured") is True]
        return (feat or self.projects)[:HOME_ITEMS]

    def area_projects(self, key):
        return [p for p in self.projects if key in p["areas"]]


def image_size(path):
    """Width and height of a logo for its <img> (PNG, JPEG, WebP through Pillow; SVG from its viewBox)."""
    if path.lower().endswith(".svg"):
        s = open(path, encoding="utf-8").read(4000)
        m = re.search(r'viewBox="\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)', s)
        if not m:
            die(f"{os.path.basename(path)} has no viewBox, so its size is unknown")
        return round(float(m.group(1))), round(float(m.group(2)))
    from PIL import Image
    with Image.open(path) as im:
        return im.size


ARROW = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2 8h11M9 3.5 13.5 8 9 12.5" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>'


class Page:
    def __init__(self, lang, C, base, origin, assets, kind="home"):
        self.lang, self.C, self.c, self.base, self.assets, self.kind = lang, C, C.copy, base, assets, kind
        self.origin = origin.rstrip("/")
        self.ar = lang == "ar"
        self.other = "en" if self.ar else "ar"

    # ── words ───────────────────────────────────────────────────────────────────────────────────────────────────
    def t(self, path, lang=None):
        node = self.c
        for k in path.split("."):
            if not isinstance(node, dict) or k not in node:
                die(f"copy.json has no {path}")
            node = node[k]
        v = node.get(lang or self.lang) if isinstance(node, dict) else None
        if not isinstance(v, str) or not v.strip():
            die(f"copy.json {path} has no {lang or self.lang} text")
        return v

    def fill(self, template, **tokens):
        """A template from copy.json as HTML: its text isolated, its {tokens} replaced by the HTML given."""
        out, i = [], 0
        for m in TOKEN.finditer(template):
            out.append(iso(template[i:m.start()], self.ar))
            if m.group(1) not in tokens:
                die(f"copy.json: «{template[:50]}» uses {{{m.group(1)}}}, which this place does not fill")
            out.append(tokens[m.group(1)])
            i = m.end()
        out.append(iso(template[i:], self.ar))
        return "".join(out)

    def x(self, path, **tokens):
        return self.fill(self.t(path), **tokens)

    def a(self, path):
        """For an attribute: plain escaped text."""
        return E(self.t(path))

    def i(self, s):
        return iso(s, self.ar)

    def n(self, obj):
        return obj[self.lang]

    def num(self, v):
        return f'<bdi dir="ltr">{E(str(v))}</bdi>' if self.ar else E(str(v))

    def count(self, noun, n):
        forms = self.c["counts"][noun][self.lang]
        f = plural_form(n, self.lang)
        if f not in forms:
            die(f"copy.json counts.{noun}.{self.lang} has no «{f}» form")
        return self.fill(forms[f], n=self.num(n))

    def date(self, d):
        if len(d) == 4:
            return f'<time datetime="{d}">{self.num(d)}</time>'
        y, m, dd = d.split("-")
        month = self.c["dates"]["months"][self.lang][int(m) - 1]
        return f'<time datetime="{d}">{self.num(int(dd))} {E(month)} {self.num(y)}</time>'

    def dates(self, p):
        return E(self.t("dates.and")).join(self.date(d) for d in p["dates"])

    def joined(self, names):
        names = list(names)
        if len(names) < 2:
            return "".join(names)
        if self.ar:
            return "، ".join(names[:-1]) + " و" + names[-1]
        return ", ".join(names[:-1]) + " and " + names[-1]

    def in_sentence(self, name):
        """An area's name inside an English sentence: lower case, unless it begins with an acronym (IT services)."""
        return name if self.ar or name[1:2].isupper() else name[0].lower() + name[1:]

    def url(self, path=""):
        return self.base + path

    def page_url(self, lang, kind=None):
        """A page's address: the home page or the projects page, in either language."""
        kind = kind or self.kind
        return self.url(("ar/" if lang == "ar" else "") + ("projects/" if kind == "projects" else ""))

    def home(self, anchor=""):
        """A place on the home page: '#x' on the home page itself, the home page's address + '#x' from elsewhere."""
        return anchor if self.kind == "home" and anchor else (self.page_url(self.lang, "home") + anchor)

    def projects_url(self, query="", anchor=""):
        return self.page_url(self.lang, "projects") + query + anchor

    def gov_name(self, k):
        return self.n(self.C.govs[k]["name"])

    def client_name(self, k):
        return self.n(self.C.client_by[k]["name"])

    def area_color(self, k):
        return AREA_COLOR.get(k, OTHER_COLOR)

    # ── the head ────────────────────────────────────────────────────────────────────────────────────────────────
    def head(self):
        if self.kind == "projects":
            title, desc = self.t("projects_page.meta_title"), self.t("projects_page.meta_description")
            share_t = desc
        else:
            title, desc, share_t = self.t("meta.title"), self.t("meta.description"), self.t("meta.share")
        fonts = (["amiri-arabic-700.woff2", "ibm-plex-sans-arabic-400.woff2"] if self.ar
                 else ["marcellus-latin-400.woff2", "ibm-plex-sans-latin-400.woff2"])
        pre = "".join(f'<link rel="preload" href="{self.url("assets/fonts/" + f)}" as="font" type="font/woff2" crossorigin>' for f in fonts)
        share = self.origin + self.url(f"assets/still/share-{self.lang}.jpg")
        has_share = os.path.exists(os.path.join(SITE, "src", "still", f"share-{self.lang}.jpg"))
        og = (f'<meta property="og:type" content="website"><meta property="og:title" content="{E(title)}">'
              f'<meta property="og:description" content="{E(share_t)}">'
              f'<meta property="og:url" content="{self.origin + self.page_url(self.lang)}">'
              f'<meta property="og:locale" content="{"ar_SY" if self.ar else "en_GB"}">'
              + (f'<meta property="og:image" content="{share}"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">' if has_share else "")
              + '<meta name="twitter:card" content="summary_large_image">')
        co, ct = self.C.site["company"], self.C.site["contact"]
        ld = {"@context": "https://schema.org", "@type": "Organization", "name": co["name"]["en"],
              "alternateName": co["name"]["ar"], "foundingDate": str(co["established"]), "email": ct["email"],
              "telephone": ct["phone_intl"], "areaServed": {"@type": "Country", "name": "Syria"}}
        return f"""<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{E(title)}</title>
<meta name="description" content="{E(desc)}">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#00132A">
<link rel="canonical" href="{self.origin + self.page_url(self.lang)}">
<link rel="alternate" hreflang="en" href="{self.page_url('en')}"><link rel="alternate" hreflang="ar" href="{self.page_url('ar')}">
<link rel="icon" href="{self.url('assets/brand/favicon.svg')}" type="image/svg+xml"><link rel="icon" href="{self.url('assets/brand/favicon.png')}" type="image/png" sizes="64x64"><link rel="apple-touch-icon" href="{self.url('assets/brand/touch.png')}">
{og}
{pre}
<link rel="stylesheet" href="{self.url('assets/css/site.css')}?v={self.assets['css']}">
<script type="application/ld+json">{json.dumps(ld, ensure_ascii=False)}</script>
</head>"""

    # ── the header ──────────────────────────────────────────────────────────────────────────────────────────────
    NAV = [("work", "#work"), ("plan", "#plan"), ("projects", "#projects"), ("clients", "#clients"), ("about", "#about"),
           ("contact", "#contact")]

    def logo(self, cls, file="logo.svg"):
        return f'<i class="{cls}" style="--m:url({self.url("assets/brand/" + file)})" role="img" aria-label="{E(self.n(self.C.site["company"]["name"]))}"></i>'

    def header(self):
        def link(k, h):
            if k == "projects":
                cur = ' aria-current="page"' if self.kind == "projects" else ""
                return f'<a href="{self.projects_url()}"{cur}>{self.x("nav." + k)}</a>'
            return f'<a href="{self.home(h)}">{self.x("nav." + k)}</a>'
        links = "".join(link(k, h) for k, h in self.NAV)
        return f"""<a class="skip" href="#main">{self.x("skip")}</a>
<header class="hdr" data-tone="light">
  <a class="brand" href="{self.page_url(self.lang, 'home')}" aria-label="{self.a('nav.home')}">{self.logo("lk full")}{self.logo("lk ar", "logo-ar.svg")}</a>
  <nav class="nav" aria-label="{self.a('nav.menu')}">{links}</nav>
  <a class="lang" href="{self.page_url(self.other)}" lang="{self.other}" hreflang="{self.other}" aria-label="{self.a('nav.lang_label')}">{E(self.t("nav.lang"))}</a>
  <a class="btn" href="{self.home('#contact')}"><span>{self.x("nav.cta")}</span></a>
  <button class="burger" type="button" aria-expanded="false" aria-controls="drawer"><span class="sr">{self.x("nav.menu")}</span><i></i><i></i></button>
</header>
<div class="drawer" id="drawer" aria-hidden="true">
  <button class="x" type="button" aria-label="{self.a('nav.close')}">×</button>
  <nav aria-label="{self.a('nav.menu')}">{links}<a href="{self.page_url(self.other)}" lang="{self.other}" hreflang="{self.other}">{E(self.t("nav.lang"))}</a></nav>
</div>"""

    # ── the descent: hero, manifesto, the areas over one drawing ───────────────────────────────────────────────
    def level(self, a):
        if not a.get("level"):
            return ""
        s = self.n(a["level"])
        if " · " in s:
            fig, words = s.split(" · ", 1)
            return f'<bdi class="num" dir="ltr">{E(fig)}</bdi> · {E(words)}'
        return E(s)

    def proj_line(self, p):
        govs = self.joined(self.i(self.gov_name(g)) for g in p["govs"])
        return (f'<li><b>{self.i(self.client_name(p["client"]))} · {govs} · {self.dates_short(p)}</b>'
                f'<span>{self.i(self.n(p["title"]))}</span></li>')

    def dates_short(self, p):
        return E(" · ").join(self.num(d[:4]) for d in dict.fromkeys(d[:4] for d in p["dates"]))

    def area_card(self, i, a):
        key, ps = a["key"], self.C.area_projects(a["key"])
        rec = ""
        if ps:
            more = (f'<a class="seeall" href="{self.projects_url(f"?area={key}")}" data-area="{key}">{self.x("areas.see_all", count=self.count("projects", len(ps)))}{ARROW}</a>'
                    if len(ps) > CARD_ITEMS else "")
            rec = (f'<div class="rec"><h4>{self.x("areas.from_projects")}</h4><ul>{"".join(self.proj_line(p) for p in ps[:CARD_ITEMS])}</ul>{more}</div>')
        k = a.get("station") or "none"
        note = f'<p class="note">{self.i(self.n(a["note"]))}</p>' if a.get("note") else ""
        return f"""<article class="station area" data-k="{k}" data-area="{key}" id="area-{key}">
  <div class="card rv" style="--c:{self.area_color(key)}"><span class="bar" aria-hidden="true"></span>
    <div class="top"><span class="num">{self.num(f"{i + 1:02d}")} / {self.num(f"{len(self.C.areas):02d}")}</span><span class="lvl">{self.level(a)}</span></div>
    <h3>{self.i(self.n(a["name"]))}</h3>
    <p class="scope">{self.i(self.n(a["scope"]))}</p>
    {note}
    {rec}
  </div>
</article>"""

    def separated(self, s):
        """Items joined by « · », breaking only between items: each separator belongs to the item after it and is
        clipped when that item starts a line, so no line ever ends or starts with a separator."""
        items = [x.strip() for x in s.split(" · ") if x.strip()]
        return ('<span class="row">' + " ".join(f'<span class="it"><span class="sep" aria-hidden="true">·</span>{self.i(x)}</span>' for x in items)
                + '</span>')

    def descent(self):
        callouts = "".join(f'<div class="callout" data-part="{p}">{self.x("parts." + p)}</div>' for p in PARTS)
        cards = "\n".join(self.area_card(i, a) for i, a in enumerate(self.C.areas))
        keys = "".join(f'<span style="--c:var(--{v})">{self.x("hero.legend_" + k)}</span>'
                       for k, v in (("water", "water"), ("waste", "waste"), ("power", "power"), ("data", "data")))
        return f"""<section class="descent" id="top" data-tone="light" aria-label="{self.a('areas.kicker')}">
  <div class="stage"><canvas aria-hidden="true"></canvas><div class="callouts" aria-hidden="true">{callouts}</div>
    <div class="tag" aria-hidden="true"><span>{self.x("hero.drawing")}</span></div></div>
  <div class="track">
    <header class="station hero" data-k="hero">
      <p class="eyebrow intro sepd">{self.separated(self.t("hero.eyebrow"))}</p>
      <h1><span class="h1a intro">{self.x("hero.h1a")}</span> <span class="h1b intro">{self.x("hero.h1b")}</span></h1>
      <div class="below intro">
        <p class="lede">{self.x("hero.lede")}</p>
        <div class="ctas"><a class="btn solid" href="{self.projects_url()}">{self.x("hero.cta1")}{ARROW}</a><a class="btn line" href="#contact">{self.x("hero.cta2")}</a></div>
      </div>
      <div class="legend">
        <div class="keys" aria-hidden="true">{keys}</div>
        <div class="daynight" role="group" aria-label="{self.a('hero.daynight_label')}"><button type="button" data-time="day" aria-pressed="true">{self.x("hero.day")}</button><button type="button" data-time="night" aria-pressed="false">{self.x("hero.night")}</button></div>
        <p class="note" aria-live="polite">{self.x("hero.day_note")}</p>
        <span>{self.x("hero.drawing")}</span>
      </div>
      <a class="cue" href="#beneath"><i aria-hidden="true"></i>{self.x("hero.cue")}</a>
    </header>
    <section class="station manifesto" data-k="manifesto" id="beneath">
      <div class="scrim" aria-hidden="true"></div>
      <div class="inner">
        <p class="kicker rv">{self.x("beneath.kicker")}</p>
        <h2 class="h2 rv">{self.x("beneath.h2")}</h2>
        <p class="rv">{self.x("beneath.p1")}</p>
        <p class="rv">{self.x("beneath.p2")}</p>
      </div>
    </section>
    <div class="station areas-head" data-k="areas" id="work">
      <div class="inner">
        <p class="kicker rv">{self.x("areas.kicker")}</p>
        <h2 class="h2 rv">{self.x("areas.h2")}</h2>
        <p class="lede rv">{self.x("areas.intro")}</p>
      </div>
    </div>
{cards}
  </div>
</section>"""

    def figures(self):
        lis = "".join(f'<li class="rv" data-stat="{E(s["key"])}"><span class="dim" aria-hidden="true"></span>'
                      f'<span class="n">{self.num(self.C.stat_value(s))}</span><span class="l">{self.i(self.n(s["label"]))}</span></li>'
                      for s in self.C.site["stats"])
        return f'<section class="figs" data-tone="dark" aria-label="{self.a("hero.figs_label")}"><ul>{lis}</ul></section>'

    # ── where we work: the plan view ────────────────────────────────────────────────────────────────────────────
    def map_svg(self, counts):
        govs = self.C.geo["governorates"]
        allp = [p for g in govs for r in g["rings"] for p in r]
        K = [km_xy(p[0], p[1]) for p in allp]
        x0, y0 = min(k[0] for k in K), min(k[1] for k in K); x1, y1 = max(k[0] for k in K), max(k[1] for k in K)
        padW, pad = 380, 26                 # room in the west for the Damascus inset
        scale = (1000 - padW - pad) / (x1 - x0)
        H = (y1 - y0) * scale + pad * 2 + 22

        def P(lon, lat):
            k = km_xy(lon, lat)
            return ((k[0] - x0) * scale + padW, (k[1] - y0) * scale + pad)

        def path(rings, f=P):
            return "".join("M" + "L".join(f"{x:.1f},{y:.1f}" for x, y in (f(lon, lat) for lon, lat in r)) + "Z" for r in rings)

        out, outer, labels = [], [], []
        for g in govs:
            d = path(g["rings"])
            lx, ly = P(*g["label"])
            name, n = self.gov_name(g["key"]), counts[g["key"]]
            outer.append(f'<path class="outer" d="{d}"/>')
            out.append(f'<path class="gov{" cov" if n else ""}" data-gov="{g["key"]}" data-n="{n}" data-lx="{lx:.0f}" tabindex="0" role="button" aria-pressed="false" '
                       f'aria-label="{E(name)}" d="{d}" fill-rule="evenodd"/>')
            nudge = {"damascus": (0, -10), "quneitra": (-2, 10), "rural-damascus": (34, 20), "tartus": (-6, 0), "daraa": (0, 6)}.get(g["key"], (0, 0))
            labels.append(f'<text class="glabel" data-gov="{g["key"]}" x="{lx + nudge[0]:.1f}" y="{ly + nudge[1]:.1f}">{E(name)}</text>')
        # the inset: the governorates around Damascus, magnified, in the empty west, clear of every boundary
        cx_lon, cy_lat, Z, R = 36.31, 33.45, 4.6, 158
        verts = [P(lon, lat) for g in govs for r in g["rings"] for lon, lat in r]
        ccx, ccy = P(cx_lon, cy_lat)
        clear = [(math.dist((x, y), (ccx, ccy)), x, y)
                 for y in range(int(R + 40), int(H - R - 30), 6) for x in range(int(R + 10), int(padW + 160), 6)
                 if min(math.dist((x, y), v) for v in verts) >= R + 14]
        if not clear:
            die("no room for the Damascus inset clear of the boundaries")
        _, icx, icy = min(clear)
        Pi = lambda lon, lat: (icx + (P(lon, lat)[0] - ccx) * Z, icy + (P(lon, lat)[1] - ccy) * Z)
        inset_govs = "".join(f'<path class="igov{" cov" if counts[g["key"]] else ""}" data-gov="{g["key"]}" data-n="{counts[g["key"]]}" d="{path(g["rings"], Pi)}" fill-rule="evenodd"/>'
                             for g in govs if g["key"] in ("damascus", "rural-damascus", "quneitra", "daraa", "suwayda", "homs"))
        # the inset earns its place: Damascus, too small to choose on the main map, is drawn large and chosen here
        ilabels = []
        for k, (dx, dy) in (("damascus", (0, -6)), ("rural-damascus", (46, 74))):
            g = self.C.govs[k]
            lx, ly = Pi(*g["label"])
            if math.dist((lx + dx, ly + dy), (icx, icy)) < R - 30:
                ilabels.append(f'<text class="ilab" data-gov="{k}" x="{lx + dx:.1f}" y="{ly + dy:.1f}" text-anchor="middle">{E(self.gov_name(k))}'
                               f'<tspan class="ic" x="{lx + dx:.1f}" dy="17">{counts[k]}</tspan></text>')
        dx, dy = ccx - icx, ccy - icy
        L = math.hypot(dx, dy) or 1
        r_lens = R / Z
        inset = f"""<g class="inset">
  <clipPath id="insclip"><circle cx="{icx:.1f}" cy="{icy:.1f}" r="{R}"/></clipPath>
  <line class="lead" x1="{icx + dx / L * R:.1f}" y1="{icy + dy / L * R:.1f}" x2="{ccx - dx / L * r_lens:.1f}" y2="{ccy - dy / L * r_lens:.1f}"/>
  <circle class="lens" cx="{ccx:.1f}" cy="{ccy:.1f}" r="{r_lens:.1f}"/>
  <g clip-path="url(#insclip)"><circle cx="{icx:.1f}" cy="{icy:.1f}" r="{R}" class="insbg"/>{inset_govs}{"".join(ilabels)}</g>
  <circle class="insring" cx="{icx:.1f}" cy="{icy:.1f}" r="{R}"/>
  <text class="tlabel" x="{icx:.1f}" y="{icy + R + 16:.1f}" text-anchor="middle">×{Z:g}</text>
</g>"""
        ticks = []
        for lon in range(36, 43):
            x, _ = P(lon, 35)
            ticks.append(f'<line class="tick" x1="{x:.1f}" y1="{H - 8:.1f}" x2="{x:.1f}" y2="{H - 16:.1f}"/><text class="tlabel" x="{x:.1f}" y="{H + 4:.1f}" text-anchor="middle">{lon}°E</text>')
        for lat in range(33, 38):
            _, y = P(42, lat)
            ticks.append(f'<line class="tick" x1="992" y1="{y:.1f}" x2="1000" y2="{y:.1f}"/><text class="tlabel" x="1006" y="{y + 3:.1f}">{lat}°N</text>')
        sx, sy = P(35.3, 35.9)
        sea = f'<text class="sea" transform="translate({sx:.1f},{sy:.1f}) rotate(-90)" text-anchor="middle">{E(self.t("plan.sea"))}</text>'
        km100 = 100 * scale
        bx, by = 1000 - pad - km100, H - 34
        scalebar = (f'<g class="scale"><line x1="{bx:.1f}" y1="{by:.1f}" x2="{bx + km100:.1f}" y2="{by:.1f}"/>'
                    + "".join(f'<line x1="{bx + km100 * t:.1f}" y1="{by - 4:.1f}" x2="{bx + km100 * t:.1f}" y2="{by + 4:.1f}"/>' for t in (0, .5, 1))
                    + f'<text x="{bx:.1f}" y="{by - 8:.1f}">0</text><text x="{bx + km100:.1f}" y="{by - 8:.1f}" text-anchor="end">100 {E(self.t("plan.km"))}</text></g>')
        north = f'<g class="north" transform="translate(30,{pad + 22})"><path d="M0,-16L6,6L0,2L-6,6Z"/><text class="tlabel" x="0" y="20" text-anchor="middle">N</text></g>'
        defs = ('<defs><pattern id="hatch" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">'
                '<rect width="6" height="6" fill="#06264A"/><line x1="0" y1="0" x2="0" y2="6" stroke="rgba(56,195,240,.42)" stroke-width="1.1"/></pattern></defs>')
        return (f'<svg class="plan-svg" viewBox="0 0 1000 {H + 10:.0f}" role="group" aria-label="{self.a("plan.map_label")}">{defs}'
                f'<rect class="frame" x="0.5" y="0.5" width="999" height="{H + 9:.0f}"/>{sea}{"".join(ticks)}'
                f'<g class="outline" aria-hidden="true">{"".join(outer)}</g><g class="govs">{"".join(out)}</g>'
                f'<g aria-hidden="true">{"".join(labels)}</g>{inset}{north}{scalebar}'
                f'<line class="sweep" x1="0" y1="0" x2="0" y2="{H + 10:.0f}"/></svg>')

    def plan(self):
        counts = self.C.gov_counts()
        with_p = sorted((k for k in counts if counts[k]), key=lambda k: (-counts[k], list(self.C.govs).index(k)))
        chips = [f'<button class="chip" type="button" data-area="all" aria-pressed="true">{self.x("plan.all")}</button>']
        for a in self.C.areas:
            if self.C.area_projects(a["key"]):
                chips.append(f'<button class="chip" type="button" data-area="{a["key"]}" aria-pressed="false"><i class="dot" style="--c:{self.area_color(a["key"])}"></i>{self.i(self.n(a["name"]))}</button>')
        gl = "".join(f'<li><button type="button" class="gl" data-gov="{k}" aria-pressed="false"><span>{self.i(self.gov_name(k))}</span><b>{self.num(counts[k])}</b></button></li>' for k in with_p)
        return f"""<section class="sec plan" id="plan" data-tone="dark">
  <div class="wrap">
    <div class="grid">
      <div class="side">
        <p class="kicker rv">{self.x("plan.kicker")}</p>
        <h2 class="h2 rv">{self.x("plan.h2")}</h2>
        <p class="lede rv">{self.x("plan.p")}</p>
        <div class="count rv"><span class="n num" dir="ltr" data-n="{len(with_p)}">{len(with_p)}</span><span class="of">{self.x("plan.of", total=self.count("governorates", len(self.C.govs)))}</span></div>
        <div class="filters plan-filter"><h3>{self.x("plan.filter_label")}</h3><div class="chips">{"".join(chips)}</div></div>
      </div>
      <div class="mapcol">
        <div class="mapbox rv">{self.map_svg(counts)}<div class="tip" aria-hidden="true"></div></div>
        <div class="govpick"><h3>{self.x("plan.list_label")}</h3><ul class="govlist">{gl}</ul></div>
        <div class="panel" aria-live="polite"><p class="prompt">{self.x("plan.prompt")}</p></div>
        <p class="attr">{self.x("plan.attribution")}</p>
      </div>
    </div>
  </div>
</section>"""

    def split(self):
        return f"""<section class="split" aria-label="{self.a('beneath.kicker')}">
  <div class="above" data-tone="light"><p><span>{self.x("beneath.pull_c")}</span><span>{self.x("beneath.pull_d")}</span></p></div>
  <div class="ln" aria-hidden="true"></div>
  <div class="below" data-tone="dark"><p><span>{self.x("beneath.pull_a")}</span><span>{self.x("beneath.pull_b")}</span></p></div>
</section>"""

    # ── our projects ────────────────────────────────────────────────────────────────────────────────────────────
    def search_text(self, p):
        c = self.C.client_by[p["client"]]
        bits = [p["title"]["en"], p["title"]["ar"], c["name"]["en"], c["name"]["ar"], c.get("as_listed") or "",
                c.get("short") or "", c.get("full") or ""]
        bits += [self.C.govs[g]["name"][l] for g in p["govs"] for l in ("en", "ar")]
        if p.get("region"):
            bits += [p["region"]["en"], p["region"]["ar"]]
        return norm(" ".join(bits))

    def project(self, p):
        govs = self.joined(self.i(self.gov_name(g)) for g in p["govs"])
        if p.get("region"):
            govs += f' <span class="rg">({self.i(self.n(p["region"]))})</span>'
        tags = "".join(f'<span class="atag" style="--c:{self.area_color(a)}">{self.i(self.n(self.C.area_by[a]["name"]))}</span>' for a in p["areas"])
        photo = ""
        if p.get("photo"):
            f = p["photo"]["file"]
            w, h = image_size(os.path.join(SITE, "src", "assets", "projects", f))
            photo = (f'<img class="ph" src="{self.url("assets/projects/" + E(f))}" width="{w}" height="{h}" loading="lazy" decoding="async" '
                     f'alt="{E(self.n(p["photo"]["alt"]))}">')
        return (f'<li class="proj" id="{p["id"]}" data-id="{p["id"]}" data-areas="{" ".join(p["areas"])}" data-client="{p["client"]}" '
                f'data-govs="{" ".join(p["govs"])}" data-year="{year_of(p)}" data-q="{E(self.search_text(p))}">'
                f'{photo}<div class="pm"><h4 class="pt">{self.i(self.n(p["title"]))}</h4><p class="tags">{tags}</p></div>'
                f'<dl><div class="pc"><dt>{self.x("projects.col_client")}</dt><dd>{self.i(self.client_name(p["client"]))}</dd></div>'
                f'<div class="pg"><dt>{self.x("projects.col_gov")}</dt><dd>{govs}</dd></div>'
                f'<div class="pd"><dt>{self.x("projects.col_date")}</dt><dd>{self.dates(p)}</dd></div></dl></li>')

    def home_projects(self):
        """The home page's short section: a fixed number of projects, the areas with their counts, one way to the page.
        Its height does not depend on how many projects there are."""
        C = self.C
        rows = []
        for p in C.home_projects():
            govs = self.joined(self.i(self.gov_name(g)) for g in p["govs"])
            rows.append(f'<li class="hp" data-id="{p["id"]}"><a href="{self.projects_url(anchor="#" + p["id"])}">'
                        f'<span class="hy">{self.dates_short(p)}</span><span class="ht">{self.i(self.n(p["title"]))}</span>'
                        f'<span class="hm">{self.i(self.client_name(p["client"]))} · {govs}</span></a></li>')
        areas = "".join(f'<li><a href="{self.projects_url(f"?area={a["key"]}")}" data-area="{a["key"]}"><i class="dot" style="--c:{self.area_color(a["key"])}"></i>'
                        f'<span>{self.i(self.n(a["name"]))}</span><b>{self.num(len(C.area_projects(a["key"])))}</b></a></li>'
                        for a in C.areas if C.area_projects(a["key"]))
        n = len(C.projects)
        return f"""<section class="sec on-light projects" id="projects" data-tone="light">
  <div class="wrap">
    <div class="head">
      <div><p class="kicker rv">{self.x("projects.kicker")}</p><h2 class="h2 rv">{self.x("projects.h2")}</h2></div>
      <div class="lede rv"><p>{self.x("projects.p")}</p><a class="btn solid" href="{self.projects_url()}">{self.x("projects.all", count=self.count("projects", n))}{ARROW}</a></div>
    </div>
    <ol class="hplist">{"".join(rows)}</ol>
    <div class="hareas"><h3>{self.x("projects.by_area")}</h3><ul>{areas}</ul></div>
  </div>
</section>"""

    def page_projects(self):
        """The projects page: every project in the HTML, newest first in year groups, the filters, twelve at a time."""
        C, P = self.C, self.C.projects
        years = list(dict.fromkeys(year_of(p) for p in P))
        groups = []
        for y in years:
            ps = [p for p in P if year_of(p) == y]
            groups.append(f'<section class="ygroup" data-year="{y}" aria-labelledby="y{y}"><h2 class="yh" id="y{y}"><span class="y">{self.num(y)}</span>'
                          f'<span class="yc">{self.count("projects", len(ps))}</span></h2><ol class="plist">{"".join(self.project(p) for p in ps)}</ol></section>')
        def opt(v, label):
            return f'<option value="{v}">{E(iso_plain(label, self.ar))}</option>'
        areas = "".join(opt(a["key"], self.n(a["name"])) for a in C.areas if C.area_projects(a["key"]))
        cls = sorted((c for c in C.clients if C.client_projects(c["key"])), key=lambda c: (-len(C.client_projects(c["key"])), self.n(c["name"]).lower()))
        clients = "".join(opt(c["key"], self.n(c["name"])) for c in cls)
        counts = C.gov_counts()
        govs = "".join(opt(k, self.gov_name(k)) for k in C.govs if counts[k])
        yrs = "".join(opt(y, str(y)) for y in years)
        sel = lambda name, label, all_, opts: (f'<label class="f"><span>{self.x(label)}</span><select name="{name}"><option value="all">{E(self.t(all_))}</option>{opts}</select></label>')
        head = "".join(f'<span>{self.x("projects." + k)}</span>' for k in ("col_project", "col_client", "col_gov", "col_date"))
        n = len(P)
        figs = [(n, "projects_page.fig_projects"), (len({p["client"] for p in P}), "projects_page.fig_clients"),
                (sum(1 for v in counts.values() if v), "projects_page.fig_govs")]
        fig = "".join(f'<li><span class="n">{self.num(v)}</span><span class="l">{self.x(k)}</span></li>' for v, k in figs)
        return f"""<section class="phero" id="top" data-tone="dark">
  <div class="wrap">
    <p class="kicker">{self.x("projects_page.kicker")}</p>
    <h1>{self.x("projects_page.h1")}</h1>
    <p class="lede">{self.x("projects_page.p")}</p>
    <ul class="pfigs">{fig}</ul>
  </div>
</section>
<section class="sec on-light projects projects-page" id="list" data-tone="light">
  <div class="wrap">
    <div class="pbar">
      <button type="button" class="ftoggle" aria-expanded="false" aria-controls="pfilters">{self.x("projects_page.filter")}<b class="fcount" hidden></b></button>
      <form class="ptools" id="pfilters" role="search" action="" onsubmit="return false">
        <label class="f q"><span>{self.x("projects.search")}</span><input type="search" name="q" placeholder="{self.a('projects.search_ph')}" autocomplete="off" enterkeyhint="search"></label>
        {sel("area", "projects.f_area", "projects.all_areas", areas)}
        {sel("client", "projects.f_client", "projects.all_clients", clients)}
        {sel("gov", "projects.f_gov", "projects.all_govs", govs)}
        {sel("year", "projects.f_year", "projects.all_years", yrs)}
        <button type="reset" class="clear">{self.x("projects.clear")}</button>
      </form>
    </div>
    <p class="pcount" aria-live="polite">{self.count("projects", n)}</p>
    <div class="phead" aria-hidden="true">{head}</div>
    {"".join(groups)}
    <p class="pempty" hidden>{self.x("projects.empty")}</p>
    <div class="pmore"><button type="button" class="more" hidden></button></div>
  </div>
</section>
<section class="pband" data-tone="dark">
  <div class="wrap">
    <p>{self.x("projects_page.band")}</p>
    <div class="ctas"><a class="btn solid" href="{self.home('#contact')}">{self.x("nav.cta")}{ARROW}</a><a class="btn line" href="{self.home()}">{self.x("projects_page.back")}</a></div>
  </div>
</section>"""

    # ── our clients ─────────────────────────────────────────────────────────────────────────────────────────────
    def plaque(self, c):
        name = self.n(c["name"])   # no project count under a client (Samir, 23 Nov 2026)
        if c.get("logo"):
            f = c["logo"]["file"]
            w, h = image_size(os.path.join(SITE, "src", "assets", "clients", f))
            inner = (f'<img src="{self.url("assets/clients/" + E(f))}" width="{w}" height="{h}" alt="{E(name)}" loading="lazy" decoding="async">')
            cls = "logo"
        else:
            latin = re.fullmatch(r"[\x20-\x7E]+", name) is not None
            size = " long" if len(name) > 30 else ""      # every plate one size: a long name is set smaller (B7 holds it)
            inner = f'<span class="pn{size}"{" dir=\"ltr\"" if latin and self.ar else ""}{" lang=\"en\"" if latin and self.ar else ""}>{E(name)}</span>'
            cls = "name"
        return f'<li class="plaque {cls}" data-client="{c["key"]}"><div class="face">{inner}</div></li>'

    def clients(self):
        groups = []
        for kind, label in self.C.kinds.items():
            cs = [c for c in self.C.clients if c["kind"] == kind]
            if not cs:
                continue
            groups.append(f'<div class="kgroup" data-kind="{kind}"><h3 class="kind">{self.i(self.n(label))}</h3><ul class="wall">{"".join(self.plaque(c) for c in cs)}</ul></div>')
        return f"""<section class="sec on-paper clients" id="clients" data-tone="light">
  <div class="wrap">
    <div class="head">
      <div><p class="kicker rv">{self.x("clients.kicker")}</p><h2 class="h2 rv">{self.x("clients.h2")}</h2></div>
      <p class="lede rv breadth">{self.x("clients.p")}</p>
    </div>
    {"".join(groups)}
  </div>
</section>"""

    # ── about ───────────────────────────────────────────────────────────────────────────────────────────────────
    def about(self):
        C, est = self.C, self.C.site["company"]["established"]
        counts = C.gov_counts()
        govs = [k for k in C.govs if counts[k]]
        cols = [(self.x("about.i1_t", areas=self.count("areas", len(C.areas))),
                 self.x("about.i1_p", list=self.joined(self.i(self.in_sentence(self.n(a["name"])) if i else self.n(a["name"])) for i, a in enumerate(C.areas)))),
                (self.x("about.i2_t", governorates=self.count("governorates", len(govs))),
                 self.x("about.i2_p", list=self.joined(self.i(self.gov_name(k)) for k in govs))),
                (self.x("about.i3_t"), self.x("about.i3_p", clients=self.count("clients", len({p["client"] for p in C.projects}))))]
        cl = "".join(f'<div class="col rv"><span class="i num">{self.num(f"0{i + 1}")}</span><h3>{t}</h3><p>{p}</p></div>' for i, (t, p) in enumerate(cols))
        return f"""<section class="sec about on-light" id="about" data-tone="light">
  <div class="wrap">
    <div class="head">
      <div><p class="kicker rv">{self.x("about.kicker")}</p><h2 class="h2 rv">{self.x("about.h2")}</h2></div>
      <div class="lede rv"><p class="est"><span>{self.x("about.est")}</span> <b>{self.num(est)}</b></p><p>{self.x("about.p", established=self.num(est))}</p></div>
    </div>
    <div class="cols">{cl}</div>
    <div class="act"><a class="btn solid" href="#contact">{self.x("about.cta")}{ARROW}</a></div>
  </div>
</section>"""

    # ── contact ─────────────────────────────────────────────────────────────────────────────────────────────────
    def contact(self):
        f, co = self.C.site["contact"], self.C.site["company"]
        local = f["phone_local"]
        shown = f"{local[:4]} {local[4:7]} {local[7:]}" if len(local) == 10 else local
        areas = "".join(f'<label><input type="checkbox" name="area" value="{a["key"]}" data-label="{E(self.n(a["name"]))}"><span>{self.i(self.n(a["name"]))}</span></label>'
                        for a in self.C.areas)
        govs = "".join(f'<option value="{k}">{E(self.gov_name(k))}</option>' for k in self.C.govs)
        return f"""<section class="sec contact" id="contact" data-tone="dark">
  <div class="wrap">
    <div class="head">
      <div><p class="kicker rv">{self.x("contact.kicker")}</p><h2 class="h2 rv">{self.x("contact.h2")}</h2></div>
      <p class="lede rv">{self.x("contact.p")}</p>
    </div>
    <div class="grid">
      <div class="tblock rv">
        <div class="wide brandcell">{self.logo("lk")}</div>
        <div class="wide"><span class="k">{self.x("contact.email")}</span><span class="v"><a href="mailto:{E(f['email'])}">{self.num(f['email'])}</a></span></div>
        <div><span class="k">{self.x("contact.phone")}</span><span class="v"><a href="tel:{E(f['phone_intl'])}">{self.num(shown)}</a></span></div>
        <div><span class="k">{self.x("contact.country")}</span><span class="v">{self.i(self.n(f["country"]))}</span></div>
        <div><span class="k">{self.x("contact.tb_drawing")}</span><span class="v">{self.x("contact.tb_drawing_v")}</span></div>
        <div><span class="k">{self.x("contact.tb_client")}</span><span class="v">{self.i(self.n(co["name"]))}</span></div>
        <div><span class="k">{self.x("contact.tb_scale")}</span><span class="v">{self.x("contact.tb_scale_v")}</span></div>
        <div><span class="k">{self.x("contact.tb_est")}</span><span class="v num">{self.num(co["established"])}</span></div>
      </div>
      <form class="compose rv" action="mailto:{E(f['email'])}" method="get">
        <h3>{self.x("contact.compose")}</h3>
        <fieldset><legend>{self.x("contact.f_areas")}</legend><div class="chips">{areas}</div></fieldset>
        <label><span>{self.x("contact.f_gov")}</span><select name="gov"><option value="">{E(self.t("contact.f_gov_none"))}</option>{govs}</select></label>
        <label><span>{self.x("contact.f_org")}</span><input type="text" name="org" autocomplete="organization"></label>
        <label><span>{self.x("contact.f_msg")}</span><textarea name="msg" rows="4"></textarea></label>
        <a class="btn solid send" href="mailto:{E(f['email'])}">{self.x("contact.send")}</a>
        <p class="note">{self.x("contact.note")}</p>
      </form>
    </div>
  </div>
</section>"""

    def footer(self, year):
        name = self.i(self.n(self.C.site["company"]["name"]))
        return f"""<footer class="ftr" data-tone="dark">
  <div class="wrap">
    {self.logo("lock")}
    <div>
      <p class="ln">{self.x("footer.line")}</p>
      <p>{self.x("footer.illustration")}</p>
      <p>{self.x("plan.attribution")}</p>
      <p>© {self.num(year)} {name}</p>
    </div>
    <a class="up" href="#top">{self.x("footer.top")} ↑</a>
  </div>
</footer>"""

    def data(self):
        alt, C = self.other, self.C
        return {
            "lang": self.lang, "altLang": alt, "rtl": self.ar, "email": C.site["contact"]["email"],
            "govs": {k: {"name": g["name"][self.lang], "alt": g["name"][alt]} for k, g in C.govs.items()},
            "areas": {a["key"]: {"name": self.n(a["name"]), "color": self.area_color(a["key"])} for a in C.areas},
            "projects": [{"id": p["id"], "title": iso_plain(self.n(p["title"]), self.ar), "client": iso_plain(self.client_name(p["client"]), self.ar),
                          "govs": p["govs"], "years": [iso_plain(y, self.ar) for y in dict.fromkeys(d[:4] for d in p["dates"])],
                          "areas": p["areas"]} for p in C.projects],
            "counts": {k: v[self.lang] for k, v in self.c["counts"].items()},
            "page": self.kind, "projectsUrl": self.projects_url(), "otherUrl": self.page_url(self.other), "step": PAGE_STEP,
            "panelItems": PANEL_ITEMS,
            "t": {"count": self.t("plan.count"), "none": self.t("plan.none"), "allIn": self.t("plan.all_in"),
                  "shown": self.t("projects_page.shown"), "more": self.t("projects_page.more"),
                  "mailSubject": self.t("contact.mail_subject"), "mailOrg": self.t("contact.mail_org"),
                  "mailAreas": self.t("contact.mail_areas"), "mailGov": self.t("contact.mail_gov"),
                  "dayNote": self.t("hero.day_note"), "nightNote": self.t("hero.night_note")},
        }

    def render(self, year):
        if self.kind == "projects":
            parts = [self.page_projects()]
        else:
            parts = [self.descent(), self.figures(), self.plan(), self.split(), self.home_projects(), self.clients(), self.about(), self.contact()]
        body = "\n".join([self.header(), '<main id="main">'] + parts + ["</main>", self.footer(year)])
        data = json.dumps(self.data(), ensure_ascii=False).replace("</", "<\\/")
        return (f'<!doctype html>\n<html lang="{self.lang}" dir="{"rtl" if self.ar else "ltr"}" class="no-js boot">\n'
                f'{self.head()}\n<body>\n{body}\n'
                f'<script type="application/json" id="page-data">{data}</script>\n'
                f'<script type="module" src="{self.url("assets/js/" + self.assets["js"] + "/main.js")}"></script>\n</body>\n</html>\n')


def brand_assets(dst, site=SITE):
    """The favicon and the touch icon from the chosen mark (15C3, ص on navy), unaltered, only scaled."""
    from PIL import Image
    src = os.path.join(site, "src", "brand")
    mark = Image.open(os.path.join(src, "mark-on-navy.png")).convert("RGBA")
    for name, size in (("favicon.png", 64), ("touch.png", 180), ("icon-512.png", 512)):
        mark.resize((size, size), Image.LANCZOS).save(os.path.join(dst, name), optimize=True)
    shutil.copy(os.path.join(src, "mark-on-navy.svg"), os.path.join(dst, "favicon.svg"))


def build(base="/alsadq/", out="dist", site=SITE, origin="https://middlewaresy.com", quiet=False):
    C = Content(site)
    root = os.path.abspath(os.path.join(site, out, base.strip("/")))
    if os.path.isdir(root) and os.listdir(root):
        if not os.path.exists(os.path.join(root, MARKER)):
            die(f"{root} is not empty and was not made by build.py; choose an empty folder for --out")
        shutil.rmtree(root)
    os.makedirs(root, exist_ok=True)
    open(os.path.join(root, MARKER), "w").write("made by site/tools/build.py; emptied on every build\n")
    a = os.path.join(root, "assets")
    for sub, src in (("css", "src/css"), ("js", "src/js"), ("fonts", "src/fonts"), ("brand", "src/brand"), ("still", "src/still"),
                     ("clients", "src/assets/clients"), ("projects", "src/assets/projects")):
        s = os.path.join(site, src)
        if os.path.isdir(s):
            shutil.copytree(s, os.path.join(a, sub), ignore=shutil.ignore_patterns("*.json", "_*", ".*"))
    os.makedirs(os.path.join(a, "brand"), exist_ok=True)
    brand_assets(os.path.join(a, "brand"), site)
    h = lambda folder: hashlib.sha256(b"".join(open(os.path.join(folder, f), "rb").read() for f in sorted(os.listdir(folder)))).hexdigest()[:10]
    assets = {"css": h(os.path.join(a, "css")), "js": h(os.path.join(a, "js"))}
    # The scripts sit in a folder named by their content. main.js imports its modules by relative address, so a change to
    # any one of them moves all of them together: a browser that kept an old module can never run it under a new page.
    # (A ?v= on main.js alone does not reach the modules it imports.)
    os.rename(os.path.join(a, "js"), os.path.join(a, "js-" + assets["js"]))
    os.makedirs(os.path.join(a, "js"))
    os.rename(os.path.join(a, "js-" + assets["js"]), os.path.join(a, "js", assets["js"]))
    year = max((year_of(p) for p in C.projects), default=C.site["company"]["established"])
    for lang in ("en", "ar"):
        for kind in ("home", "projects"):
            page = Page(lang, C, base, origin, assets, kind)
            d = os.path.join(root, *(["ar"] if lang == "ar" else []), *(["projects"] if kind == "projects" else []))
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "index.html"), "w", encoding="utf-8") as f:
                f.write(page.render(year))
    files = sum(len(fs) for _, _, fs in os.walk(root))
    size = sum(os.path.getsize(os.path.join(p, f)) for p, _, fs in os.walk(root) for f in fs)
    if not quiet:
        print(f"✓ build: {root} · {len(C.projects)} projects · {len(C.clients)} clients · {len(C.areas)} areas · {files} files · {size // 1024} kB")
    return root


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="/alsadq/", help="the folder the site is served from, starting and ending with /")
    ap.add_argument("--out", default="dist", help="the folder to build into (relative to site/, or absolute)")
    ap.add_argument("--origin", default="https://middlewaresy.com", help="where the pages will be served, for the link card")
    a = ap.parse_args()
    if not a.base.startswith("/") or not a.base.endswith("/"):
        die("--base must start and end with /")
    build(a.base, a.out, origin=a.origin)
